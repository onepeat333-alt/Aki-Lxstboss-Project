﻿#requires -version 5
# ---------------------------------------------------------------
#  Aki Lxst Boss Optimize - PowerShell launcher
#
#  .\AkiBossMap.ps1            start the app and open the UI
#  .\AkiBossMap.ps1 -Admin     restart with Administrator rights
#  .\AkiBossMap.ps1 -Check     verify every file before sharing
#  .\AkiBossMap.ps1 -Stop      stop a server that is still running
#  .\AkiBossMap.ps1 -Port 5190 start on a specific port
#  .\AkiBossMap.ps1 -NoBrowser start the server without opening a tab
#
#  If Windows blocks the script, run:
#  powershell -ExecutionPolicy Bypass -File .\AkiBossMap.ps1
# ---------------------------------------------------------------

[CmdletBinding()]
param(
    [switch]$Admin,
    [switch]$Stop,
    [switch]$Check,
    [switch]$NoBrowser,
    [ValidateRange(1024, 65535)]
    [int]$Port = 5180
)

$ErrorActionPreference = 'Stop'

$root       = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$serverPath = Join-Path $root 'server.ps1'
$appDir     = Join-Path $root 'app'
$stateDir   = Join-Path $env:LOCALAPPDATA 'AkiLxstboss'

$script:checkFail = 0
$script:checkWarn = 0

# ------------------------------ helpers --------------------------------

function Test-Admin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object Security.Principal.WindowsPrincipal($id)
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Get-AppVersion {
    if (-not (Test-Path -LiteralPath $serverPath)) { return '0.0.0' }
    try {
        $line = Get-Content -LiteralPath $serverPath -TotalCount 40 -ErrorAction Stop |
                Where-Object { $_ -match '^\$appVer\s*=' } | Select-Object -First 1
        if ($line -and $line -match "'([^']+)'") { return $matches[1] }
    } catch { }
    return '0.0.0'
}

function Write-Banner([string]$version, [bool]$isAdmin) {
    Write-Host ''
    Write-Host '  ============================================================' -ForegroundColor DarkMagenta
    Write-Host '     A K I   L X S T   B O S S   O P T I M I Z E' -ForegroundColor Magenta
    Write-Host ("     v{0}   FiveM graphics / network / Windows tweaks" -f $version) -ForegroundColor DarkGray
    Write-Host '  ============================================================' -ForegroundColor DarkMagenta
    if ($isAdmin) {
        Write-Host '  [+] Administrator mode - every feature is unlocked.' -ForegroundColor Green
    } else {
        Write-Host '  [i] Normal mode - Home / Graphics / Profiles / Clean Up work fully.' -ForegroundColor Yellow
        Write-Host '      Add -Admin (or use run-admin.bat) for Optimize and Network.' -ForegroundColor DarkGray
    }
    Write-Host ''
}

function Report-Item([string]$state, [string]$text) {
    switch ($state) {
        'ok'   { Write-Host ("  [ OK ] {0}" -f $text) -ForegroundColor Green }
        'warn' { Write-Host ("  [WARN] {0}" -f $text) -ForegroundColor Yellow; $script:checkWarn++ }
        default { Write-Host ("  [FAIL] {0}" -f $text) -ForegroundColor Red; $script:checkFail++ }
    }
}

function Test-Syntax([string]$path) {
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$null, [ref]$errors)
    if ($errors -and $errors.Count -gt 0) {
        return ("line {0}: {1}" -f $errors[0].Extent.StartLineNumber, $errors[0].Message)
    }
    return $null
}

# ------------------------------ checks ---------------------------------

function Invoke-Check {
    $version = Get-AppVersion
    Write-Host ''
    Write-Host ("  Self check - Aki Lxst Boss Optimize v{0}" -f $version) -ForegroundColor Magenta
    Write-Host '  ------------------------------------------------------------' -ForegroundColor DarkMagenta

    $required = @(
        'AkiBossMap.ps1', 'server.ps1', 'run.bat', 'run-admin.bat', 'stop.bat', 'README.md',
        'app\index.html', 'app\css\app.css', 'app\js\main.js', 'app\js\data.js', 'app\js\perf.js',
        'app\assets\aki-logo.png', 'app\assets\aki-orbit.svg'
    )
    foreach ($rel in $required) {
        if (Test-Path -LiteralPath (Join-Path $root $rel)) { Report-Item 'ok' "file: $rel" }
        else { Report-Item 'fail' "missing: $rel" }
    }

    foreach ($rel in @('server.ps1', 'AkiBossMap.ps1')) {
        $p = Join-Path $root $rel
        if (-not (Test-Path -LiteralPath $p)) { continue }
        $problem = Test-Syntax $p
        if ($problem) { Report-Item 'fail' "syntax: $rel - $problem" }
        else { Report-Item 'ok' "syntax: $rel parses cleanly" }
    }

    if (Test-Path -LiteralPath $serverPath) {
        $bytes = [IO.File]::ReadAllBytes($serverPath)
        if ($bytes.Length -gt 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) {
            Report-Item 'ok' 'encoding: server.ps1 keeps its UTF-8 BOM (Thai text safe)'
        } else {
            Report-Item 'fail' 'encoding: server.ps1 lost the UTF-8 BOM'
        }
    }

    # Every image referenced by the UI must actually exist.
    $missing = @()
    if (Test-Path -LiteralPath $appDir) {
        $files = @(Get-ChildItem -LiteralPath $appDir -Recurse -File -ErrorAction SilentlyContinue |
                   Where-Object { $_.Extension -in @('.js', '.css', '.html') })
        foreach ($f in $files) {
            $text = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction SilentlyContinue
            if (-not $text) { continue }
            foreach ($m in [regex]::Matches($text, 'assets/[A-Za-z0-9._\-]+\.(?:png|svg|jpe?g|webp|gif)')) {
                $asset = Join-Path (Join-Path $appDir 'assets') (Split-Path $m.Value -Leaf)
                if (-not (Test-Path -LiteralPath $asset)) { $missing += "$($f.Name) -> $($m.Value)" }
            }
        }
        if ($missing.Count -eq 0) { Report-Item 'ok' 'assets: every image the UI loads exists' }
        else { foreach ($m in $missing) { Report-Item 'fail' "asset: $m" } }
    }

    # Port availability: the app moves to the next free port on its own, so a
    # busy default port is a warning rather than a failure.
    try {
        $probe = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
        $probe.Start()
        $probe.Stop()
        Report-Item 'ok' "port: $Port is free"
    } catch {
        Report-Item 'warn' "port: $Port is busy - the app will use the next free port"
    }

    if (Test-Path -LiteralPath $stateDir) { Report-Item 'ok' "data folder: $stateDir" }
    else { Report-Item 'warn' "data folder: $stateDir will be created on first use" }

    if (Test-Admin) { Report-Item 'ok' 'rights: running as Administrator' }
    else { Report-Item 'warn' 'rights: normal user (Optimize / Network need -Admin)' }

    Write-Host '  ------------------------------------------------------------' -ForegroundColor DarkMagenta
    if ($script:checkFail -eq 0) {
        Write-Host ("  RESULT: ready to share - {0} warning(s)" -f $script:checkWarn) -ForegroundColor Green
        Write-Host ''
        exit 0
    }
    Write-Host ("  RESULT: {0} problem(s) found - fix them before sharing" -f $script:checkFail) -ForegroundColor Red
    Write-Host ''
    exit 1
}

# ------------------------------ stop -----------------------------------

# The process that runs this script and every parent of it must survive, even
# when their command line happens to mention AkiBossMap.ps1 (for example
# "powershell -File .\AkiBossMap.ps1 -Stop" started from another shell).
function Get-ProtectedProcessIds {
    $ids = New-Object 'System.Collections.Generic.HashSet[int]'
    $current = [int]$PID
    for ($i = 0; $i -lt 16 -and $current -gt 0; $i++) {
        if (-not $ids.Add($current)) { break }
        $parent = 0
        try {
            $info = Get-CimInstance Win32_Process -Filter "ProcessId=$current" -ErrorAction Stop
            $parent = [int]$info.ParentProcessId
        } catch { break }
        $current = $parent
    }
    return $ids
}

function Invoke-Stop {
    Write-Host ''
    $stopped = 0
    $procs = @()
    try {
        $protected = Get-ProtectedProcessIds
        $procs = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop |
                   Where-Object {
                       $_.ProcessId -ne $PID -and
                       -not $protected.Contains([int]$_.ProcessId) -and
                       $_.CommandLine -and
                       $_.CommandLine -match '(?i)(server|AkiBossMap)\.ps1'
                   })
    } catch { }
    foreach ($p in $procs) {
        try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; $stopped++ } catch { }
    }
    $portFile = Join-Path $stateDir 'port.txt'
    if (Test-Path -LiteralPath $portFile) { Remove-Item -LiteralPath $portFile -Force -ErrorAction SilentlyContinue }
    if ($stopped -gt 0) { Write-Host ("  Stopped {0} server process(es)." -f $stopped) -ForegroundColor Green }
    else { Write-Host '  No running server was found.' -ForegroundColor DarkGray }
    Write-Host ''
}

# ------------------------------ main -----------------------------------

if ($Stop)  { Invoke-Stop; exit 0 }
if ($Check) { Invoke-Check }

if ($Admin -and -not (Test-Admin)) {
    Write-Host ''
    Write-Host '  Asking Windows for Administrator rights...' -ForegroundColor Yellow
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $MyInvocation.MyCommand.Path), '-Admin')
    if ($NoBrowser) { $argList += '-NoBrowser' }
    if ($Port -ne 5180) { $argList += @('-Port', [string]$Port) }
    try {
        Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs -ErrorAction Stop | Out-Null
        exit 0
    } catch {
        Write-Host '  [!] Administrator permission was refused - starting in normal mode.' -ForegroundColor Yellow
    }
}

# Files that came out of a downloaded ZIP carry a "blocked" mark; clearing it
# here is what lets other people just run the script.
foreach ($f in (Get-ChildItem -LiteralPath $root -Filter *.ps1 -File -ErrorAction SilentlyContinue)) {
    try { Unblock-File -LiteralPath $f.FullName -ErrorAction SilentlyContinue } catch { }
}

$version = Get-AppVersion
Write-Banner $version (Test-Admin)

if (-not (Test-Path -LiteralPath $serverPath)) {
    Write-Host '  [FAIL] server.ps1 is missing next to this file.' -ForegroundColor Red
    Write-Host '         Unzip the whole release folder again and keep the files together.' -ForegroundColor DarkGray
    Write-Host ''
    exit 1
}
if (-not (Test-Path -LiteralPath (Join-Path $appDir 'index.html'))) {
    Write-Host '  [FAIL] the app folder is incomplete (app\index.html not found).' -ForegroundColor Red
    Write-Host ''
    exit 1
}

try {
    & $serverPath -Port $Port -NoBrowser:$NoBrowser
} catch {
    Write-Host ("  Server stopped: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}

Write-Host '  Server stopped. You can close this window.' -ForegroundColor DarkGray
