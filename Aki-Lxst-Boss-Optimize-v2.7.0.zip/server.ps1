﻿#requires -version 5
# ---------------------------------------------------------------
#  Aki Lxst Boss Optimize
#  FiveM settings + system/network tweaks + QoS controller.
#  Local static server + small JSON API. No dependencies, no build.
#  Start with run.bat (right click -> Run as administrator for
#  network / registry actions).
# ---------------------------------------------------------------
param(
    [int]$Port      = 5180,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference    = 'SilentlyContinue'

$appName   = 'Aki Lxst Boss Optimize'
$appVer    = '2.7.0'
$port      = $Port
if ($port -lt 1024 -or $port -gt 65535) { $port = 5180 }
$appRoot   = Join-Path $PSScriptRoot 'app'
$dataRoot  = Join-Path $env:LOCALAPPDATA 'AkiLxstboss'
$backupDir = Join-Path $dataRoot 'backups'
$regDir    = Join-Path $dataRoot 'regbackups'
$iniDir    = Join-Path $dataRoot 'citizenfx-backups'
$qosStateFile = Join-Path $dataRoot 'qos-state.json'
foreach ($d in @($dataRoot, $backupDir, $regDir, $iniDir)) {
    if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

$localApp    = $env:LOCALAPPDATA
$roamingApp  = $env:APPDATA
$fivemHome   = Join-Path $localApp 'FiveM'
$fivemApp    = Join-Path $fivemHome 'FiveM.app'
$citizenIni  = Join-Path $fivemApp 'CitizenFX.ini'
$citizenGta  = Join-Path $roamingApp 'CitizenFX\gta5_settings.xml'
$myDocs      = [Environment]::GetFolderPath('MyDocuments')
$docGta      = Join-Path $myDocs 'Rockstar Games\GTA V'
$docSettings = Join-Path $docGta 'settings.xml'

# ------------------------------ helpers --------------------------------

function Send-Json($ctx, $obj, [int]$status = 200) {
    $json  = $obj | ConvertTo-Json -Depth 12 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.ContentType     = 'application/json; charset=utf-8'
    $ctx.Response.Headers['Cache-Control']          = 'no-store, max-age=0'
    $ctx.Response.Headers['X-Content-Type-Options'] = 'nosniff'
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.StatusCode      = $status
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.Close()
}

function Get-Body($req) {
    $reader = New-Object System.IO.StreamReader($req.InputStream, [System.Text.Encoding]::UTF8)
    $raw    = $reader.ReadToEnd()
    $reader.Close()
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    try { return ($raw | ConvertFrom-Json) } catch { return $null }
}

function Get-FivemExe {
    foreach ($p in @((Join-Path $fivemApp 'FiveM.exe'), (Join-Path $fivemHome 'FiveM.exe'))) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Test-FivemRunning {
    $names = @('FiveM', 'FiveM_GTAProcess', 'GTA5')
    foreach ($n in $names) {
        if (Get-Process -Name $n -ErrorAction SilentlyContinue) { return $true }
    }
    return $false
}

function Get-IniValues([string]$path) {
    $map = @{}
    if (-not (Test-Path -LiteralPath $path)) { return $map }
    $section = ''
    foreach ($line in (Get-Content -LiteralPath $path)) {
        $t = ($line + '').Trim()
        if ($t -match '^\[(.+)\]$') { $section = $matches[1]; continue }
        if ($t -match '^([^=]+)=(.*)$') {
            $k = $matches[1].Trim()
            $v = $matches[2].Trim()
            $map[($section + '|' + $k)] = $v
        }
    }
    return $map
}

function Set-IniKey([string]$path, [string]$section, [string]$key, [string]$value) {
    $lines = @()
    if (Test-Path -LiteralPath $path) { $lines = @(Get-Content -LiteralPath $path) }
    $out         = New-Object System.Collections.Generic.List[string]
    $inSection   = $false
    $sectionSeen = $false
    $keyDone     = $false

    foreach ($line in $lines) {
        $t = ($line + '').Trim()
        if ($t -match '^\[(.+)\]$') {
            if ($inSection -and -not $keyDone) { $out.Add("$key=$value"); $keyDone = $true }
            $inSection = ($matches[1].Trim() -eq $section)
            if ($inSection) { $sectionSeen = $true }
            $out.Add($line)
            continue
        }
        if ($inSection -and $t -match '^([^=]+)=') {
            if ($matches[1].Trim() -eq $key) {
                if (-not $keyDone) { $out.Add("$key=$value"); $keyDone = $true }
                continue
            }
        }
        $out.Add($line)
    }
    if ($inSection -and -not $keyDone) { $out.Add("$key=$value"); $keyDone = $true }
    if (-not $sectionSeen) {
        if ($out.Count -gt 0 -and $out[$out.Count - 1].Trim() -ne '') { $out.Add('') }
        $out.Add("[$section]")
        $out.Add("$key=$value")
    }
    $dir = Split-Path -Parent $path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -LiteralPath $path -Value $out -Encoding ASCII
}

function Remove-IniKey([string]$path, [string]$section, [string]$key) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    $lines     = @(Get-Content -LiteralPath $path)
    $out       = New-Object System.Collections.Generic.List[string]
    $inSection = $false

    foreach ($line in $lines) {
        $t = ($line + '').Trim()
        if ($t -match '^\[(.+)\]$') {
            $inSection = ($matches[1].Trim() -eq $section)
            $out.Add($line)
            continue
        }
        if ($inSection -and $t -match '^([^=]+)=') {
            if ($matches[1].Trim() -eq $key) { continue }
        }
        $out.Add($line)
    }
    Set-Content -LiteralPath $path -Value $out -Encoding ASCII
}

function Backup-Ini([string]$id) {
    if (-not (Test-Path -LiteralPath $citizenIni)) { return $null }
    $base = "$id-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.ini'
    $name = $base
    $i = 1
    while (Test-Path -LiteralPath (Join-Path $iniDir $name)) { $name = "$base.$i"; $i++ }
    Copy-Item -LiteralPath $citizenIni -Destination (Join-Path $iniDir $name) -Force
    return $name
}

function Get-IniBackups {
    $items = @()
    foreach ($f in (Get-ChildItem -LiteralPath $iniDir -Filter *.ini -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
        $items += [ordered]@{
            name = $f.Name
            sizeKB = [math]::Round($f.Length / 1KB, 1)
            date = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
        }
    }
    return [ordered]@{ ok = $true; items = $items }
}

function Get-GtaDir {
    $ini = Get-IniValues $citizenIni
    $p   = $ini['Game|IVPath']
    if ($p -and (Test-Path -LiteralPath $p)) { return $p }

    # Common install locations. Users can always set the path manually on the
    # Settings page, so a miss here is never fatal.
    $candidates = @(
        (Join-Path ${env:ProgramFiles} 'Rockstar Games\Grand Theft Auto V'),
        (Join-Path ${env:ProgramFiles(x86)} 'Rockstar Games\Grand Theft Auto V'),
        (Join-Path ${env:ProgramFiles} 'Steam\steamapps\common\Grand Theft Auto V'),
        (Join-Path ${env:ProgramFiles(x86)} 'Steam\steamapps\common\Grand Theft Auto V'),
        (Join-Path ${env:ProgramFiles} 'Epic Games\GTAV'),
        (Join-Path ${env:ProgramFiles(x86)} 'Epic Games\GTAV')
    )
    foreach ($drive in @('C', 'D', 'E', 'F', 'G')) {
        $candidates += "$drive`:\SteamLibrary\steamapps\common\Grand Theft Auto V"
        $candidates += "$drive`:\Games\Grand Theft Auto V"
        $candidates += "$drive`:\Program Files\Rockstar Games\Grand Theft Auto V"
        $candidates += "$drive`:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V"
    }
    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    return $null
}

# FiveM stores its real graphics settings in %APPDATA%\CitizenFX\gta5_settings.xml.
# Keep the older locations as fallbacks for other setups.
function Get-SettingsPath {
    foreach ($p in @($citizenGta, (Join-Path $fivemApp 'settings.xml'), $docSettings)) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Get-DefaultSettingsPath {
    if (Test-Path -LiteralPath (Join-Path $roamingApp 'CitizenFX')) { return $citizenGta }
    if (Test-Path -LiteralPath $fivemApp) { return (Join-Path $fivemApp 'settings.xml') }
    return $citizenGta
}

function Get-FolderMB([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return 0 }
    try {
        $sum = (Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue |
                Measure-Object -Property Length -Sum).Sum
        if (-not $sum) { return 0 }
        return [math]::Round($sum / 1MB, 1)
    } catch { return 0 }
}

function Clear-Folder([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return 0 }
    $mb = Get-FolderMB $path
    Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    return $mb
}

function New-SettingsDoc {
    $xml  = New-Object System.Xml.XmlDocument
    $decl = $xml.CreateXmlDeclaration('1.0', 'UTF-8', $null)
    $xml.AppendChild($decl) | Out-Null
    $root = $xml.CreateElement('Settings')
    $xml.AppendChild($root) | Out-Null
    foreach ($sec in @('graphics', 'video')) {
        $e = $xml.CreateElement($sec)
        $root.AppendChild($e) | Out-Null
    }
    return $xml
}

function Read-SettingsDoc([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return (New-SettingsDoc) }
    try {
        $d = New-Object System.Xml.XmlDocument
        $d.PreserveWhitespace = $true
        $d.Load($path)
        if (-not $d.DocumentElement) { return (New-SettingsDoc) }
        return $d
    } catch { return (New-SettingsDoc) }
}

function Set-XmlValue($doc, [string]$section, [string]$key, $value) {
    $node = $doc.SelectSingleNode("/Settings/$section/$key")
    if (-not $node) {
        $sec = $doc.SelectSingleNode("/Settings/$section")
        if (-not $sec) {
            $sec = $doc.CreateElement($section)
            $doc.DocumentElement.AppendChild($sec) | Out-Null
        }
        $node = $doc.CreateElement($key)
        $sec.AppendChild($node) | Out-Null
    }
    $node.SetAttribute('value', (To-ValueString $value))
}

function To-ValueString($v) {
    if ($null -eq $v) { return '0' }
    if ($v -is [bool]) { if ($v) { return '1' } else { return '0' } }
    if ($v -is [double] -or $v -is [single] -or $v -is [decimal]) {
        return ([double]$v).ToString('0.######', [System.Globalization.CultureInfo]::InvariantCulture)
    }
    return [string]$v
}

function Backup-Settings([string]$path) {
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return $null }
    $base = 'settings-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
    $name = $base + '.xml'
    $i = 1
    while (Test-Path -LiteralPath (Join-Path $backupDir $name)) {
        $name = "$base-$i.xml"
        $i++
    }
    $dest = Join-Path $backupDir $name
    Copy-Item -LiteralPath $path -Destination $dest -Force
    # Copy-Item keeps the source timestamp; the list should show when the
    # backup was actually taken.
    try { (Get-Item -LiteralPath $dest).LastWriteTime = Get-Date } catch { }
    return $name
}

function Test-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object Security.Principal.WindowsPrincipal($id)
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

# Fast check for "is something listening on this port". Used to keep the
# startup fast: closed ports refuse instantly, so we only send a real HTTP
# request to ports that actually accept connections.
function Test-PortListening([int]$portNumber) {
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $async  = $client.BeginConnect('127.0.0.1', $portNumber, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne(250)) { $client.Close(); return $false }
        $client.EndConnect($async)
        $client.Close()
        return $true
    } catch { return $false }
}

function Get-RegValue([string]$path, [string]$name) {
    try {
        $item = Get-ItemProperty -Path $path -Name $name -ErrorAction Stop
        return $item.$name
    } catch { return $null }
}

function Get-DwordState([string]$path, [string]$name, $expected) {
    $v = Get-RegValue $path $name
    if ($null -eq $v) { return $false }
    if ($v -eq $expected) { return $true }
    # 0xFFFFFFFF is returned as -1 by some PowerShell versions.
    if ($expected -eq 4294967295 -and $v -eq -1) { return $true }
    return $false
}

function Backup-RegKey([string]$id, [string]$regKey) {
    if (-not $regKey) { return $null }
    if (-not $regKey.StartsWith('HKLM\') -and -not $regKey.StartsWith('HKCU\')) { return $null }
    if (-not (Test-Path -LiteralPath ("Registry::" + $regKey))) { return $null }
    $base = "$id-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
    $name = "$base.reg"
    $i = 1
    while (Test-Path -LiteralPath (Join-Path $regDir $name)) { $name = "$base-$i.reg"; $i++ }
    $dst = Join-Path $regDir $name
    & reg.exe export "$regKey" "$dst" /y *>$null
    if (Test-Path -LiteralPath $dst) { return $name }
    return $null
}

# ------------------------------ tweak originals ------------------------
# Some settings (TCP/UDP global) can only be read through netsh, whose labels
# are localized. So the first time such a tweak is switched on we remember the
# exact previous values and write them back when it is switched off. If the
# values cannot be read, the tweak refuses to run instead of leaving a setting
# behind that it cannot undo.
$tweakStateFile = Join-Path $dataRoot 'tweak-originals.json'

function Get-TweakOriginalMap {
    $map = [ordered]@{}
    if (Test-Path -LiteralPath $tweakStateFile) {
        try {
            $raw = Get-Content -LiteralPath $tweakStateFile -Raw
            if ($raw) {
                $obj = $raw | ConvertFrom-Json
                foreach ($p in $obj.PSObject.Properties) { $map[$p.Name] = $p.Value }
            }
        } catch { }
    }
    return $map
}

function Save-TweakOriginal([string]$id, $data) {
    $map = Get-TweakOriginalMap
    $map[$id] = $data
    try { ($map | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $tweakStateFile -Encoding UTF8 } catch { }
}

function Get-TweakOriginal([string]$id) {
    $map = Get-TweakOriginalMap
    return $map[$id]
}

function Remove-TweakOriginal([string]$id) {
    $map = Get-TweakOriginalMap
    if ($map.Contains($id)) { $map.Remove($id) }
    try { ($map | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $tweakStateFile -Encoding UTF8 } catch { }
}

function Get-NetshGlobal([string]$proto, [string]$label) {
    try {
        $out = (& netsh int $proto show global 2>&1) -join "`n"
        $m = [regex]::Match($out, '(?im)^\s*' + [regex]::Escape($label) + '\s*:\s*(\S+)\s*$')
        if ($m.Success) { return $m.Groups[1].Value.ToLower() }
    } catch { }
    return $null
}

function Set-NetshGlobal([string]$proto, [string]$name, [string]$value) {
    & netsh int $proto set global "$name=$value" | Out-Null
    return ($LASTEXITCODE -eq 0)
}

# TCP global settings are also exposed through the NetTCPIP CIM class, which is
# language-independent (netsh labels are translated on non-English Windows).
function Get-TcpSettingSnapshot {
    $snap = [ordered]@{}
    try {
        $c = Get-NetTCPSetting -SettingName 'Internet' -ErrorAction Stop
        $snap.timestamps = [string]$c.Timestamps
        $snap.ecn        = [string]$c.EcnCapability
        $snap.initialrto = [string]$c.InitialRto
        $snap.maxsyn     = [string]$c.MaxSynRetransmissions
    } catch { }
    return $snap
}

# ------------------------------ tweak catalog --------------------------
# Tweaks are grouped by confidence. Only genuinely low-risk, broadly useful
# changes are included in the one-click Safe setup; the rest stay optional.
# state = returns $true when the tweak is currently applied. $null means the
# value cannot be read reliably (driver-specific), the UI shows it as unknown.

$TWEAKS = @(
    @{
        id = 'disableNagle'; cat = 'network'; tier = 'caution'; admin = $true
        label = "ปิด Nagle's Algorithm"
        desc = 'ค่าเก่าสำหรับ TCP บางเกม ผลกับ FiveM ไม่แน่นอน และอาจไม่ช่วย — ใช้เฉพาะเมื่อต้องการทดสอบเอง'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
        enable = {
            Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' -ErrorAction SilentlyContinue | ForEach-Object {
                New-ItemProperty -Path $_.PSPath -Name TcpAckFrequency -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
                New-ItemProperty -Path $_.PSPath -Name TCPNoDelay -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
            }
        }
        disable = {
            Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' -ErrorAction SilentlyContinue | ForEach-Object {
                Remove-ItemProperty -Path $_.PSPath -Name TcpAckFrequency -ErrorAction SilentlyContinue
                Remove-ItemProperty -Path $_.PSPath -Name TCPNoDelay -ErrorAction SilentlyContinue
            }
        }
        state = {
            $on = $false
            Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' -ErrorAction SilentlyContinue | ForEach-Object {
                if ((Get-RegValue $_.PSPath 'TcpAckFrequency') -eq 1) { $on = $true }
            }
            [bool]$on
        }
    }
    @{
        id = 'networkAdapterPowerSaving'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'กันการ์ดเน็ตหลับ'
        desc = 'ห้าม Windows สั่งการ์ดเครือข่ายปิดเพื่อประหยัดไฟ (แก้อาการเน็ตกระตุกเป็นช่วง ๆ)'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}'
        enable = {
            Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
                Set-NetAdapterPowerManagement -Name $_.Name -AllowComputerToTurnOffDevice Disabled -ErrorAction SilentlyContinue
            }
        }
        disable = {
            Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
                Set-NetAdapterPowerManagement -Name $_.Name -AllowComputerToTurnOffDevice Enabled -ErrorAction SilentlyContinue
            }
        }
        state = {
            $r = $null
            try {
                $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue)
                if ($adapters.Count -eq 0) { return $null }
                $pm = @($adapters | ForEach-Object { Get-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue })
                if ($pm.Count -eq 0) { return $null }
                $r = -not ($pm | Where-Object { $_.AllowComputerToTurnOffDevice -ne 'Disabled' })
            } catch { $r = $null }
            $r
        }
    }
    @{
        id = 'nicPowerSavingAdvanced'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'ปิดประหยัดไฟการ์ดเน็ตทั้งหมด'
        desc = 'ปิด Selective Suspend / EEE / idle power gating / wake-on-LAN ของการ์ดเน็ตทุกตัว (การ์ดที่ไม่รองรับจะถูกข้าม)'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}'
        enable = {
            $ErrorActionPreference = 'SilentlyContinue'
            foreach ($a in (Get-NetAdapter -Physical -ErrorAction SilentlyContinue)) {
                Set-NetAdapterPowerManagement -Name $a.Name -SelectiveSuspend Disabled -EnergyEfficientEthernet Disabled -ReduceSpeedOnPowerDown Disabled -DeviceSleepOnDisconnect Disabled -WakeOnMagicPacket Disabled -WakeOnPattern Disabled -ErrorAction SilentlyContinue
                foreach ($p in (Get-NetAdapterAdvancedProperty -Name $a.Name -ErrorAction SilentlyContinue)) {
                    if ($p.DisplayName -match 'Power Sav|Idle|Gating|Power Saver|Standby|Delayed Power|Auto.?Neg|Wake on Link|Link Speed During|Ultra Low Power') {
                        $off = $p.ValidDisplayValues | Where-Object { $_ -match '^Disabled$|^Off$' } | Select-Object -First 1
                        if ($off) { Set-NetAdapterAdvancedProperty -Name $a.Name -DisplayName $p.DisplayName -DisplayValue $off -ErrorAction SilentlyContinue }
                    }
                }
            }
        }
        disable = {
            $ErrorActionPreference = 'SilentlyContinue'
            foreach ($a in (Get-NetAdapter -Physical -ErrorAction SilentlyContinue)) {
                Set-NetAdapterPowerManagement -Name $a.Name -SelectiveSuspend Enabled -EnergyEfficientEthernet Enabled -ReduceSpeedOnPowerDown Enabled -DeviceSleepOnDisconnect Enabled -WakeOnMagicPacket Enabled -WakeOnPattern Enabled -ErrorAction SilentlyContinue
                foreach ($p in (Get-NetAdapterAdvancedProperty -Name $a.Name -ErrorAction SilentlyContinue)) {
                    if ($p.DisplayName -match 'Power Sav|Idle|Gating|Power Saver|Standby|Delayed Power|Auto.?Neg|Wake on Link|Link Speed During|Ultra Low Power') {
                        $on = $p.ValidDisplayValues | Where-Object { $_ -match '^Enabled$|^On$|Maximum Power Sav' } | Select-Object -First 1
                        if ($on) { Set-NetAdapterAdvancedProperty -Name $a.Name -DisplayName $p.DisplayName -DisplayValue $on -ErrorAction SilentlyContinue }
                    }
                }
            }
        }
        state = {
            $r = $null
            try {
                $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue)
                if ($adapters.Count -eq 0) { return $null }
                $pm = @($adapters | ForEach-Object { Get-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue })
                if ($pm.Count -eq 0) { return $null }
                $r = -not ($pm | Where-Object { $_.SelectiveSuspend -ne 'Disabled' })
            } catch { $r = $null }
            $r
        }
    }
    @{
        id = 'disableAutoDisconnect'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'ปิดการตัดเซสชันอัตโนมัติ'
        desc = 'กัน Windows ตัดการเชื่อมต่อเครือข่ายที่ไม่มีการใช้งานอัตโนมัติ (autodisconnect = -1)'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
        enable  = { New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name autodisconnect -PropertyType DWord -Value 4294967295 -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name autodisconnect -PropertyType DWord -Value 15 -Force | Out-Null }
        state   = { Get-DwordState 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'autodisconnect' 4294967295 }
    }
    @{
        id = 'disableDeliveryOptimization'; cat = 'network'; tier = 'safe'; admin = $true
        label = 'ปิด Delivery Optimization (P2P)'
        desc = 'หยุด Windows ใช้แบนด์วิดท์ของคุณอัปโหลดอัปเดตให้เครื่องอื่นแบบ P2P'
        regKey = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'
        enable  = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' -Name DODownloadMode -PropertyType DWord -Value 0 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' -Name DODownloadMode -ErrorAction SilentlyContinue }
        state   = { Get-DwordState 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' 'DODownloadMode' 0 }
    }
    @{
        id = 'disableIPv6'; cat = 'network'; tier = 'caution'; admin = $true; reboot = $true
        label = 'ปิด IPv6'
        desc = 'ไม่แนะนำสำหรับการเล่นปกติ — IPv6 ไม่ได้ทำให้ FiveM ช้า และการปิดอาจทำให้บางเครือข่ายมีปัญหา'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'
        enable  = { New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' -Name DisabledComponents -PropertyType DWord -Value 255 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' -Name DisabledComponents -ErrorAction SilentlyContinue }
        state   = { $null -ne (Get-RegValue 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' 'DisabledComponents') }
    }
    @{
        id = 'optimizeNetworkPriorities'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'QoS policy limit tweak'
        desc = 'แก้ NonBestEffortLimit = 0 แต่ Windows ไม่ได้กันเน็ตไว้ 20% แบบตายตัว — ไม่ใช่ FPS/ping boost'
        regKey = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched'
        enable  = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' -Name NonBestEffortLimit -PropertyType DWord -Value 0 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' -Name NonBestEffortLimit -ErrorAction SilentlyContinue }
        state   = { $null -ne (Get-RegValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' 'NonBestEffortLimit') }
    }
    @{
        id = 'disableInterruptModeration'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'ปิด Interrupt Moderation'
        desc = 'ให้ CPU ประมวลผลทุกแพ็กเก็ตทันที — การ์ดที่ไม่รองรับจะถูกข้ามไปเงียบ ๆ'
        enable = {
            Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
                $p = Get-NetAdapterAdvancedProperty -Name $_.Name -ErrorAction SilentlyContinue | Where-Object { $_.RegistryKeyword -match 'InterruptModeration' -or $_.DisplayName -match 'Interrupt Moderation' }
                if ($p) { Set-NetAdapterAdvancedProperty -Name $_.Name -DisplayName $p.DisplayName -DisplayValue 'Disabled' -ErrorAction SilentlyContinue }
            }
        }
        disable = {
            Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
                $p = Get-NetAdapterAdvancedProperty -Name $_.Name -ErrorAction SilentlyContinue | Where-Object { $_.RegistryKeyword -match 'InterruptModeration' -or $_.DisplayName -match 'Interrupt Moderation' }
                if ($p) { Set-NetAdapterAdvancedProperty -Name $_.Name -DisplayName $p.DisplayName -DisplayValue 'Enabled' -ErrorAction SilentlyContinue }
            }
        }
        state = { $null }
    }
    @{
        id = 'disableAdapterNotifications'; cat = 'network'; tier = 'caution'
        label = 'ปิดการแจ้งเตือนเน็ตต่อ/หลุด'
        desc = 'ปิด toast ทั้งหมดของ Windows (ไม่ใช่แค่เครือข่าย — ไม่มีการตั้งค่าที่เจาะจงกว่านี้)'
        regKey = 'HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications'
        enable  = { New-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications' -Name ToastEnabled -PropertyType DWord -Value 0 -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications' -Name ToastEnabled -PropertyType DWord -Value 1 -Force | Out-Null }
        state   = { Get-DwordState 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications' 'ToastEnabled' 0 }
    }
    @{
        id = 'networkThrottlingIndex'; cat = 'system'; tier = 'caution'; admin = $true
        label = 'Network throttling registry tweak'
        desc = 'ค่า registry เก่าสำหรับ MMCSS; ผลกับ Windows/FiveM รุ่นใหม่ไม่แน่นอน จึงไม่รวมใน Safe setup'
        regKey = 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
        enable  = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name NetworkThrottlingIndex -PropertyType DWord -Value 4294967295 -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name NetworkThrottlingIndex -PropertyType DWord -Value 10 -Force | Out-Null }
        state   = { Get-DwordState 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' 'NetworkThrottlingIndex' 4294967295 }
    }
    @{
        id = 'systemResponsiveness'; cat = 'system'; tier = 'caution'; admin = $true
        label = 'ลด CPU ที่กันไว้ให้งานเบื้องหลัง'
        desc = 'ตั้ง MMCSS = 0 แต่ไม่ได้รับประกัน FPS และอาจกระทบเสียง/งานเบื้องหลัง — ไม่รวมใน Safe setup'
        regKey = 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
        enable  = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name SystemResponsiveness -PropertyType DWord -Value 0 -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name SystemResponsiveness -PropertyType DWord -Value 20 -Force | Out-Null }
        state   = { Get-DwordState 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' 'SystemResponsiveness' 0 }
    }
    @{
        id = 'optimizeMmcss'; cat = 'system'; tier = 'caution'; admin = $true
        label = 'Optimize MMCSS'
        desc = 'ตั้งค่า Games task ของ Multimedia Class Scheduler (ผลจริงกับเกมส่วนใหญ่มีจำกัด)'
        regKey = 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
        enable = {
            $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
            New-ItemProperty -Path $k -Name 'GPU Priority' -PropertyType DWord -Value 8 -Force | Out-Null
            New-ItemProperty -Path $k -Name 'Priority' -PropertyType DWord -Value 6 -Force | Out-Null
            New-ItemProperty -Path $k -Name 'Scheduling Category' -PropertyType String -Value 'High' -Force | Out-Null
            New-ItemProperty -Path $k -Name 'SFIO Priority' -PropertyType String -Value 'High' -Force | Out-Null
        }
        disable = {
            $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
            New-ItemProperty -Path $k -Name 'GPU Priority' -PropertyType DWord -Value 8 -Force | Out-Null
            New-ItemProperty -Path $k -Name 'Priority' -PropertyType DWord -Value 2 -Force | Out-Null
            New-ItemProperty -Path $k -Name 'Scheduling Category' -PropertyType String -Value 'Medium' -Force | Out-Null
            New-ItemProperty -Path $k -Name 'SFIO Priority' -PropertyType String -Value 'Normal' -Force | Out-Null
        }
        state = { (Get-RegValue 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games' 'Priority') -eq 6 }
    }
    @{
        id = 'disablePowerThrottling'; cat = 'system'; tier = 'caution'; admin = $true; reboot = $true
        label = 'ปิด Power Throttling'
        desc = 'กัน Windows หรี่ความเร็ว CPU ให้โปรแกรมเบื้องหลัง — ต้องรีสตาร์ทเครื่อง'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling'
        enable  = { New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name PowerThrottlingOff -PropertyType DWord -Value 1 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name PowerThrottlingOff -ErrorAction SilentlyContinue }
        state   = { Get-DwordState 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 1 }
    }
    @{
        id = 'gameModeAndBar'; cat = 'system'; tier = 'safe'
        label = 'Game Mode ON + Capture OFF'
        desc = 'เปิด Game Mode และปิดการบันทึก Xbox Game Bar เบื้องหลัง เพื่อลด overhead ระหว่างเล่น'
        regKey = 'HKCU\Software\Microsoft\GameBar'
        enable  = { New-ItemProperty -Path 'HKCU:\Software\Microsoft\GameBar' -Name AllowAutoGameMode -PropertyType DWord -Value 1 -Force | Out-Null; New-ItemProperty -Path 'HKCU:\System\GameConfigStore' -Name GameDVR_Enabled -PropertyType DWord -Value 0 -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Software\Microsoft\GameBar' -Name AllowAutoGameMode -PropertyType DWord -Value 0 -Force | Out-Null }
        state   = { ((Get-RegValue 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode') -eq 1) -and ((Get-RegValue 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled') -eq 0) }
    }
    @{
        id = 'fivemDefenderExclusion'; cat = 'system'; tier = 'caution'; admin = $true
        label = 'ยกเว้น FiveM จาก Defender'
        desc = 'ยกเว้นโฟลเดอร์ FiveM จากการสแกนของ Windows Defender (ลด CPU overhead แต่ลดการป้องกัน)'
        regKey = 'HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths'
        enable  = { Add-MpPreference -ExclusionPath "$env:LOCALAPPDATA\FiveM" -ErrorAction Stop }
        disable = { Remove-MpPreference -ExclusionPath "$env:LOCALAPPDATA\FiveM" -ErrorAction SilentlyContinue }
        state = {
            $r = $null
            try {
                $paths = @((Get-MpPreference -ErrorAction Stop).ExclusionPath)
                $r = [bool]($paths | Where-Object { $_ -and ($_ -replace '\\$','') -ieq (("$env:LOCALAPPDATA\FiveM") -replace '\\$','') })
            } catch { $r = $null }
            $r
        }
    }
    @{
        id = 'mouseAccelCurveLinear'; cat = 'input'; tier = 'caution'
        label = 'ปิด Mouse Acceleration'
        desc = 'ปิด Enhance Pointer Precision ให้เมาส์เป็นเส้นตรง 1:1 (MouseSpeed/Threshold = 0, Sensitivity = 10)'
        regKey = 'HKCU\Control Panel\Mouse'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseSpeed -PropertyType String -Value '0' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseThreshold1 -PropertyType String -Value '0' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseThreshold2 -PropertyType String -Value '0' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseSensitivity -PropertyType String -Value '10' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseSpeed -PropertyType String -Value '1' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseThreshold1 -PropertyType String -Value '6' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseThreshold2 -PropertyType String -Value '10' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name MouseSensitivity -PropertyType String -Value '10' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU:\Control Panel\Mouse' 'MouseSpeed') -eq '0' }
    }
    @{
        id = 'fivemProcessPriority'; cat = 'input'; tier = 'caution'; admin = $true
        label = 'FiveM Process Priority: High'
        desc = 'บังคับ priority สูงทุกครั้ง; อาจแย่ง CPU จาก Discord/driver จึงไม่รวมใน Safe setup'
        regKey = 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\FiveM_GTAProcess.exe'
        enable  = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\FiveM_GTAProcess.exe\PerfOptions' -Name CpuPriorityClass -PropertyType DWord -Value 3 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\FiveM_GTAProcess.exe\PerfOptions' -Name CpuPriorityClass -ErrorAction SilentlyContinue }
        state   = { Get-DwordState 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\FiveM_GTAProcess.exe\PerfOptions' 'CpuPriorityClass' 3 }
    }
    @{
        id = 'filterKeysTimingReset'; cat = 'input'; tier = 'caution'
        label = 'Reset Filter Keys Timing'
        desc = 'รีเซ็ตเวลาของ Filter Keys กันดีเลย์ค้างถ้าถูกเผลอเปิด'
        regKey = 'HKCU\Control Panel\Accessibility\Keyboard Response'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name AutoRepeatDelay -PropertyType String -Value '200' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name AutoRepeatRate -PropertyType String -Value '15' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name DelayBeforeAcceptance -PropertyType String -Value '0' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name AutoRepeatDelay -PropertyType String -Value '1000' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name AutoRepeatRate -PropertyType String -Value '500' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name DelayBeforeAcceptance -PropertyType String -Value '1000' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU:\Control Panel\Accessibility\Keyboard Response' 'DelayBeforeAcceptance') -eq '0' }
    }
    @{
        id = 'disableFilterKeysFeature'; cat = 'input'; tier = 'caution'
        label = 'ปิด Filter Keys'
        desc = 'ปิดฟีเจอร์ช่วยการเข้าถึง Filter Keys ทั้งหมด'
        regKey = 'HKCU\Control Panel\Accessibility\Keyboard Response'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name Flags -PropertyType String -Value '122' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\Keyboard Response' -Name Flags -PropertyType String -Value '126' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU:\Control Panel\Accessibility\Keyboard Response' 'Flags') -eq '122' }
    }
    @{
        id = 'disableStickyKeysFeature'; cat = 'input'; tier = 'caution'
        label = 'ปิด Sticky Keys'
        desc = 'ปิดทางลัด Sticky Keys (กด Shift 5 ครั้ง) และเซอร์วิสที่เกี่ยวข้อง'
        regKey = 'HKCU\Control Panel\Accessibility\StickyKeys'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\StickyKeys' -Name Flags -PropertyType String -Value '506' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\StickyKeys' -Name Flags -PropertyType String -Value '510' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU:\Control Panel\Accessibility\StickyKeys' 'Flags') -eq '506' }
    }
    @{
        id = 'disableToggleKeysFeature'; cat = 'input'; tier = 'caution'
        label = 'ปิด Toggle Keys'
        desc = 'ปิดเสียงเตือนตอนกด Caps Lock / Num Lock / Scroll Lock'
        regKey = 'HKCU\Control Panel\Accessibility\ToggleKeys'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\ToggleKeys' -Name Flags -PropertyType String -Value '58' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\ToggleKeys' -Name Flags -PropertyType String -Value '62' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU:\Control Panel\Accessibility\ToggleKeys' 'Flags') -eq '58' }
    }
    @{
        id = 'keyboardRepeatDelay'; cat = 'input'; tier = 'caution'
        label = 'ลดดีเลย์การกดปุ่มค้าง'
        desc = 'ลดเวลารอก่อนที่ปุ่มที่กดค้างจะเริ่มรัวซ้ำ (KeyboardDelay = 0)'
        regKey = 'HKCU\Control Panel\Keyboard'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name KeyboardDelay -PropertyType String -Value '0' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name KeyboardDelay -PropertyType String -Value '1' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU:\Control Panel\Keyboard' 'KeyboardDelay') -eq '0' }
    }
    @{
        id = 'keyboardRepeatRate'; cat = 'input'; tier = 'caution'
        label = 'เพิ่มความเร็วการรัวปุ่ม'
        desc = 'เพิ่มความเร็วการรัวซ้ำของปุ่มที่กดค้างไว้ (KeyboardSpeed = 31)'
        regKey = 'HKCU\Control Panel\Keyboard'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name KeyboardSpeed -PropertyType String -Value '31' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name KeyboardSpeed -PropertyType String -Value '20' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU:\Control Panel\Keyboard' 'KeyboardSpeed') -eq '31' }
    }
    # ---- Selected from the SETTING / X3D INTEL / ALL-NET audits ----
    # Only values that are real, reversible and plausibly useful made it in.
    # Everything risky (bcdedit, Defender removal, service disabling,
    # IPv6 removal, NLA tweaks, junk DPC/IRQ tweaks) was left out.
    @{
        id = 'hags'; cat = 'system'; tier = 'caution'; admin = $true; reboot = $true
        label = 'Hardware GPU Scheduling (HAGS)'
        desc = 'GraphicsDrivers HwSchMode = 2 — ใช้ตัวจัดคิวงานของการ์ดจอโดยตรง ลด overhead ต้องใช้การ์ด/driver รองรับ และรีบูตเครื่อง'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'
        enable  = { New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -PropertyType DWord -Value 2 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -ErrorAction SilentlyContinue }
        state   = { Get-DwordState 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2 }
    }
    @{
        id = 'win32PrioritySeparation'; cat = 'system'; tier = 'caution'; admin = $true
        label = 'Win32PrioritySeparation = 0x26'
        desc = 'PriorityControl — ให้ foreground (เกม) ได้ CPU quantum ยาวขึ้นเล็กน้อย ผลจริงจำกัด ไม่ใช่การเพิ่มความเร็ว'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl'
        enable  = { New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -Name Win32PrioritySeparation -PropertyType DWord -Value 38 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -Name Win32PrioritySeparation -ErrorAction SilentlyContinue }
        state   = { Get-DwordState 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 38 }
    }
    @{
        id = 'disablePagingExecutive'; cat = 'system'; tier = 'caution'; admin = $true; reboot = $true
        label = 'Disable Paging Executive'
        desc = 'Memory Management DisablePagingExecutive = 1 — เก็บเคอร์เนล Windows ไว้ใน RAM เสมอ ถ้าแรมน้อยกว่า 16GB ไม่แนะนำ'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
        enable  = { New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name DisablePagingExecutive -PropertyType DWord -Value 1 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name DisablePagingExecutive -ErrorAction SilentlyContinue }
        state   = { Get-DwordState 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' 'DisablePagingExecutive' 1 }
    }
    @{
        id = 'ultimatePowerPlan'; cat = 'system'; tier = 'caution'; admin = $true
        label = 'Ultimate Performance Power Plan'
        desc = 'เปิด power plan Ultimate Performance ของ Windows เพื่อลด CPU wake latency — เหมาะกับเดสก์ท็อป โน้ตบุ๊กเปลืองแบต'
        enable = {
            $out = ''
            try { $out = (powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>&1) -join "`n" } catch { }
            if ($out -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
                powercfg -setactive $matches[1] | Out-Null
            }
        }
        disable = { powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e | Out-Null }
        state   = { $null }
    }
    @{
        id = 'xboxGameDvrPolicy'; cat = 'system'; tier = 'caution'; admin = $true
        label = 'Xbox Game DVR (policy): ปิดจับภาพ'
        desc = 'HKLM Policies\Microsoft\Windows\GameDVR AllowGameDVR = 0 — ปิดการจับภาพ Xbox ระดับ policy ชัดกว่าค่า HKCU ที่ปุ่ม Game Mode / Capture OFF ตั้งไว้'
        regKey = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR'
        enable  = { New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' -Name AllowGameDVR -PropertyType DWord -Value 0 -Force | Out-Null }
        disable = { Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' -Name AllowGameDVR -ErrorAction SilentlyContinue }
        state   = { Get-DwordState 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' 'AllowGameDVR' 0 }
    }
    @{
        id = 'mouseKeyboardQueue'; cat = 'input'; tier = 'caution'; admin = $true
        label = 'ลด Input Queue (Mouse/Keyboard)'
        desc = 'mouclass/kbdclass QueueSize = 16 — ลดคิวป้อนข้อมูล ช่วยเวลา mouse polling สูงมาก กลับค่า 100 ได้ด้วยปุ่มเดียว'
        regKey = 'HKLM\SYSTEM\CurrentControlSet\Services\mouclass\Parameters'
        enable = {
            New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\mouclass\Parameters' -Name MouseDataQueueSize -PropertyType DWord -Value 16 -Force | Out-Null
            New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\kbdclass\Parameters' -Name KeyboardDataQueueSize -PropertyType DWord -Value 16 -Force | Out-Null
        }
        disable = {
            New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\mouclass\Parameters' -Name MouseDataQueueSize -PropertyType DWord -Value 100 -Force | Out-Null
            New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\kbdclass\Parameters' -Name KeyboardDataQueueSize -PropertyType DWord -Value 100 -Force | Out-Null
        }
        state = {
            (Get-DwordState 'HKLM:\SYSTEM\CurrentControlSet\Services\mouclass\Parameters' 'MouseDataQueueSize' 16) -and
            (Get-DwordState 'HKLM:\SYSTEM\CurrentControlSet\Services\kbdclass\Parameters' 'KeyboardDataQueueSize' 16)
        }
    }
    @{
        id = 'uiResponsiveness'; cat = 'input'; tier = 'caution'
        label = 'UI: Foreground Lock / Menu Delay = 0'
        desc = 'HKCU Desktop ForegroundLockTimeout = 0 และ MenuShowDelay = 0 — แอปเบื้องหลังไม่บังคับขอโฟกัส และเมนูเด้งทันที เป็นเรื่องความรู้สึก ไม่ใช่ FPS'
        regKey = 'HKCU\Control Panel\Desktop'
        enable  = { New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name ForegroundLockTimeout -PropertyType DWord -Value 0 -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name MenuShowDelay -PropertyType String -Value '0' -Force | Out-Null }
        disable = { New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name ForegroundLockTimeout -PropertyType DWord -Value 200000 -Force | Out-Null; New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name MenuShowDelay -PropertyType String -Value '400' -Force | Out-Null }
        state   = { (Get-RegValue 'HKCU\Control Panel\Desktop' 'ForegroundLockTimeout') -eq 0 }
    }
    @{
        id = 'fivemDscpQoS'; cat = 'network'; tier = 'caution'; admin = $true; reboot = $true
        label = 'DSCP 46 Priority Marking (FiveM)'
        desc = 'เครื่องหมายแพ็กเก็ต FiveM/GTA5 เป็น EF (DSCP 46) ให้ router ที่รองรับ QoS จัดคิวก่อน — ไม่จำกัด bandwidth และ home router ส่วนใหญ่เมินค่านี้อยู่ดี'
        regKey = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\QoS'
        enable = {
            $apps = @('FiveM.exe', 'FiveM_GTAProcess.exe', 'GTA5.exe')
            foreach ($a in $apps) {
                $name = 'AkiBoss_' + ($a -replace '[^a-zA-Z0-9_]', '_')
                $k = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\' + $name
                New-Item -Path $k -Force | Out-Null
                foreach ($pair in @(
                    @('Version', '1.0'), @('Application Name', $a), @('Protocol', '*'),
                    @('Local IP', '*'), @('Local IP Prefix Length', '*'),
                    @('Remote IP', '*'), @('Remote IP Prefix Length', '*'),
                    @('Local Port', '*'), @('Remote Port', '*'),
                    @('DSCP Value', '46'), @('Throttle Rate', '-1'))) {
                    New-ItemProperty -Path $k -Name $pair[0] -PropertyType String -Value $pair[1] -Force | Out-Null
                }
            }
        }
        disable = {
            foreach ($name in @('AkiBoss_FiveM_exe', 'AkiBoss_FiveM_GTAProcess_exe', 'AkiBoss_GTA5_exe')) {
                Remove-Item -LiteralPath ('Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\QoS\' + $name) -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
        state = {
            $hits = 0
            foreach ($name in @('AkiBoss_FiveM_exe', 'AkiBoss_FiveM_GTAProcess_exe', 'AkiBoss_GTA5_exe')) {
                if (Test-Path -LiteralPath ('HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\' + $name)) { $hits++ }
            }
            $hits -eq 3
        }
    }
    # ---- CitizenFX.ini engine flags — only ones with a real, documented
    # effect made it in. Close FiveM before applying; reopen after. ----
    @{
        id = 'fivemWaitableSwapchain'; cat = 'fivem'; tier = 'caution'; ini = $true
        label = 'Waitable SwapChain (ลด input lag)'
        desc = 'CitizenFX.ini [Renderer] SwapChainUseWaitableSwapChain=true — render queue แบบ waitable ช่วยลด latency ใน D3D11 ถ้าเกมหยุดชะงักให้ปิดกลับ'
        enable  = { Set-IniKey $citizenIni 'Renderer' 'SwapChainUseWaitableSwapChain' 'true' }
        disable = { Remove-IniKey $citizenIni 'Renderer' 'SwapChainUseWaitableSwapChain' }
        state   = { (Get-IniValues $citizenIni)['Renderer|SwapChainUseWaitableSwapChain'] -eq 'true' }
    }
    @{
        id = 'fivemForceRenderAhead'; cat = 'fivem'; tier = 'caution'; ini = $true
        label = 'Render Ahead Limit = 1'
        desc = 'CitizenFX.ini [Renderer] ForceRenderAheadLimit=1 — ลดเฟรมที่ค้างในคิว render แลกด้วยภาระ CPU สวิง ถ้ากระตุกให้ลบค่าออก'
        enable  = { Set-IniKey $citizenIni 'Renderer' 'ForceRenderAheadLimit' '1' }
        disable = { Remove-IniKey $citizenIni 'Renderer' 'ForceRenderAheadLimit' }
        state   = { (Get-IniValues $citizenIni)['Renderer|ForceRenderAheadLimit'] -eq '1' }
    }
    @{
        id = 'fivemDisableNagle'; cat = 'fivem'; tier = 'caution'; ini = $true
        label = 'FiveM: ปิด Nagle ในเกม'
        desc = 'CitizenFX.ini [Game] DisableNagleAlgorithm=1 — ตัวเลือกในตัว FiveM เอง กระทบเฉพาะ packet ของเกม ต่างจากการไปแก้ TCP ทั้งเครื่อง'
        enable  = { Set-IniKey $citizenIni 'Game' 'DisableNagleAlgorithm' '1' }
        disable = { Remove-IniKey $citizenIni 'Game' 'DisableNagleAlgorithm' }
        state   = { (Get-IniValues $citizenIni)['Game|DisableNagleAlgorithm'] -eq '1' }
    }
    @{
        id = 'fivemHighPriority'; cat = 'fivem'; tier = 'caution'; ini = $true
        label = 'FiveM: High Priority ในตัวเกม'
        desc = 'CitizenFX.ini [Game] HighPriority=1 — ให้ FiveM ตั้ง priority สูงให้ตัวเอง ซ้ำซ้อนกับการตั้ง IFEO priority ได้ เลือกทางใดทางหนึ่ง'
        enable  = { Set-IniKey $citizenIni 'Game' 'HighPriority' '1' }
        disable = { Remove-IniKey $citizenIni 'Game' 'HighPriority' }
        state   = { (Get-IniValues $citizenIni)['Game|HighPriority'] -eq '1' }
    }
    @{
        id = 'fivemUseDirectInput'; cat = 'fivem'; tier = 'caution'; ini = $true
        label = 'Use DirectInput (จอยรุ่นเก่า)'
        desc = 'CitizenFX.ini [Game] UseDirectInput=1 — ดีกับ joystick/พวงมาลัยรุ่นเก่า จอย XInput/DualShock รุ่นใหม่ไม่ต้องเปิด'
        enable  = { Set-IniKey $citizenIni 'Game' 'UseDirectInput' '1' }
        disable = { Remove-IniKey $citizenIni 'Game' 'UseDirectInput' }
        state   = { (Get-IniValues $citizenIni)['Game|UseDirectInput'] -eq '1' }
    }
    # ---- Added from the bundled FiveM_Apply_Gpedit.bat / CitizenFX.txt ----
    @{
        id = 'fivemPresentationOptimizations'; cat = 'fivem'; tier = 'caution'; ini = $true
        label = 'Presentation Optimizations'
        desc = 'CitizenFX.ini [Renderer] EnablePresentationOptimizations=true — ให้ renderer จัดการ present frame ตรงขึ้น ลด overhead เล็กน้อย ถ้าภาพกระตุกให้ปิดกลับ'
        enable  = { Set-IniKey $citizenIni 'Renderer' 'EnablePresentationOptimizations' 'true' }
        disable = { Remove-IniKey $citizenIni 'Renderer' 'EnablePresentationOptimizations' }
        state   = { (Get-IniValues $citizenIni)['Renderer|EnablePresentationOptimizations'] -eq 'true' }
    }
    @{
        id = 'fivemNvThreadOptimization'; cat = 'fivem'; tier = 'caution'; ini = $true
        label = 'ปิด NVIDIA Thread Optimization (FiveM)'
        desc = 'CitizenFX.ini [Game] DisableNvThreadOptimization=1 — สำหรับการ์ด NVIDIA: ลด worker thread ที่แย่ง CPU กับ main thread ถ้าเฟรมแย่ลงให้ปิดกลับ'
        enable  = { Set-IniKey $citizenIni 'Game' 'DisableNvThreadOptimization' '1' }
        disable = { Remove-IniKey $citizenIni 'Game' 'DisableNvThreadOptimization' }
        state   = { (Get-IniValues $citizenIni)['Game|DisableNvThreadOptimization'] -eq '1' }
    }
    @{
        id = 'tcpFastOpen'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'TCP Fast Open'
        desc = 'netsh int tcp fastopen=enabled + fastopenfallback=enabled — ลด round-trip ตอนเปิด connection ใหม่ ช่วยตอนกด join เซิร์ฟเวอร์ (จำค่าเดิมไว้และคืนให้ตรงตัวเมื่อปิด)'
        enable  = {
            $snap = [ordered]@{
                fastopen         = (Get-NetshGlobal 'tcp' 'Fast Open')
                fastopenfallback = (Get-NetshGlobal 'tcp' 'Fast Open Fallback')
            }
            if (-not $snap.fastopen -or -not $snap.fastopenfallback) {
                throw 'อ่านค่า Fast Open เดิมของ Windows นี้ไม่ได้ (ภาษาของระบบ) — ยกเลิกเพื่อไม่ให้ค้างค่าไว้'
            }
            Save-TweakOriginal 'tcpFastOpen' $snap
            [void](Set-NetshGlobal 'tcp' 'fastopen' 'enabled')
            [void](Set-NetshGlobal 'tcp' 'fastopenfallback' 'enabled')
        }
        disable = {
            $snap = Get-TweakOriginal 'tcpFastOpen'
            if ($snap) {
                [void](Set-NetshGlobal 'tcp' 'fastopen' ([string]$snap.fastopen))
                [void](Set-NetshGlobal 'tcp' 'fastopenfallback' ([string]$snap.fastopenfallback))
                Remove-TweakOriginal 'tcpFastOpen'
            } else {
                [void](Set-NetshGlobal 'tcp' 'fastopen' 'default')
                [void](Set-NetshGlobal 'tcp' 'fastopenfallback' 'disabled')
            }
        }
        state   = {
            $v = Get-NetshGlobal 'tcp' 'Fast Open'
            if ($null -eq $v) { $null } else { $v -eq 'enabled' }
        }
    }
    @{
        id = 'tcpLowLatencyProfile'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'TCP Low-Latency Profile'
        desc = 'ปิด timestamps/ECN, initialRto 1500ms, syn retry 2 ครั้ง — ลดเวลารอเมื่อแพ็กเก็ตหลุดบนเน็ตไม่เสถียร (อ่าน/คืนค่าผ่าน NetTCPIP จึงใช้ได้ทุกภาษาของ Windows; ไม่แตะ pacing เพราะคืนค่าไม่ได้)'
        enable  = {
            $snap = Get-TcpSettingSnapshot
            if (-not $snap.timestamps -or -not $snap.initialrto) {
                throw 'อ่านค่า TCP เดิมของ Windows นี้ไม่ได้ — ยกเลิกเพื่อไม่ให้ค้างค่าไว้'
            }
            Save-TweakOriginal 'tcpLowLatencyProfile' $snap
            Set-NetTCPSetting -SettingName 'Internet' -Timestamps Disabled -EcnCapability Disabled -InitialRtoMs 1500 -MaxSynRetransmissions 2 -ErrorAction Stop
        }
        disable = {
            $snap = Get-TweakOriginal 'tcpLowLatencyProfile'
            if (-not $snap) {
                throw 'ไม่พบค่าที่บันทึกไว้ก่อนเปิด tweak นี้ — ตรวจ/ตั้งค่าเองที่ netsh int tcp show global'
            }
            Set-NetTCPSetting -SettingName 'Internet' -Timestamps ([string]$snap.timestamps) -EcnCapability ([string]$snap.ecn) -InitialRtoMs ([int]$snap.initialrto) -MaxSynRetransmissions ([int]$snap.maxsyn) -ErrorAction Stop
            Remove-TweakOriginal 'tcpLowLatencyProfile'
        }
        state   = {
            $snap = Get-TcpSettingSnapshot
            if (-not $snap.timestamps) { $null } else { ($snap.timestamps -eq 'Disabled') -and ($snap.initialrto -eq '1500') }
        }
    }
    @{
        id = 'udpReceiveOffload'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'UDP Receive Offload (URO)'
        desc = 'netsh int udp set global uro=enabled — ให้การ์ดเน็ตรวมแพ็กเก็ต UDP ก่อนส่งให้ CPU เหมาะกับเครื่องที่ CPU วิ่งสูงตอนเล่น'
        enable  = {
            $snap = [ordered]@{ uro = (Get-NetshGlobal 'udp' 'Receive Offload State') }
            if (-not $snap.uro) {
                throw 'อ่านค่า UDP Receive Offload เดิมของ Windows นี้ไม่ได้ — ยกเลิกเพื่อไม่ให้ค้างค่าไว้'
            }
            Save-TweakOriginal 'udpReceiveOffload' $snap
            [void](Set-NetshGlobal 'udp' 'uro' 'enabled')
        }
        disable = {
            $snap = Get-TweakOriginal 'udpReceiveOffload'
            if ($snap) {
                [void](Set-NetshGlobal 'udp' 'uro' ([string]$snap.uro))
                Remove-TweakOriginal 'udpReceiveOffload'
            } else {
                [void](Set-NetshGlobal 'udp' 'uro' 'default')
            }
        }
        state   = {
            $v = Get-NetshGlobal 'udp' 'Receive Offload State'
            if ($null -eq $v) { $null } else { $v -eq 'enabled' }
        }
    }
    @{
        id = 'qosReservedBandwidth'; cat = 'network'; tier = 'caution'; admin = $true
        label = 'ปลดล็อก Reserved Bandwidth 20%'
        desc = 'HKLM Policies\Microsoft\Windows\Psched NonBestEffortLimit = 0 — ปลดล็อก 20% ที่ Windows สงวนไว้ ผลกับเกมจริงแทบไม่มี แต่ปิดกลับได้ด้วยปุ่มเดียว'
        regKey = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched'
        enable  = {
            $snap = [ordered]@{ exists = $false; value = $null }
            try {
                $cur = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' -Name NonBestEffortLimit -ErrorAction Stop
                $snap.exists = $true
                $snap.value = [string]$cur.NonBestEffortLimit
            } catch { }
            Save-TweakOriginal 'qosReservedBandwidth' $snap
            New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' -Name NonBestEffortLimit -PropertyType DWord -Value 0 -Force | Out-Null
        }
        disable = {
            $snap = Get-TweakOriginal 'qosReservedBandwidth'
            if ($snap -and $snap.exists) {
                New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' -Name NonBestEffortLimit -PropertyType DWord -Value ([int]$snap.value) -Force | Out-Null
            } else {
                Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' -Name NonBestEffortLimit -ErrorAction SilentlyContinue
            }
            Remove-TweakOriginal 'qosReservedBandwidth'
        }
        state   = { Get-DwordState 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' 'NonBestEffortLimit' 0 }
    }
    # fivemPoolSizes intentionally NOT included — this machine's
    # CitizenFX.ini already contains a richer PoolSizesIncrease block;
    # the app must never shrink or overwrite it.
)

# ------------------------------ endpoints ------------------------------

function Get-Status {
    $exe     = Get-FivemExe
    $gta     = Get-GtaDir
    $setPath = Get-SettingsPath

    $cache    = Get-FolderMB (Join-Path $fivemApp 'data\cache')
    $server   = Get-FolderMB (Join-Path $fivemApp 'data\server-cache')
    $nui      = Get-FolderMB (Join-Path $fivemApp 'data\nui-views')
    $logs     = Get-FolderMB (Join-Path $fivemApp 'data\logs')
    $crashes  = Get-FolderMB (Join-Path $fivemApp 'crashes')

    return [ordered]@{
        ok      = $true
        demo    = $false
        app     = $appName
        version = $appVer
        port    = $port
        os      = [System.Environment]::OSVersion.VersionString
        machine = $env:COMPUTERNAME
        user    = $env:USERNAME
        admin   = (Test-IsAdmin)
        fivemRunning = (Test-FivemRunning)
        paths   = [ordered]@{
            fivemHome  = $fivemHome
            fivemApp   = $fivemApp
            citizenIni = $citizenIni
            gta        = $gta
            settings   = $setPath
            backups    = $backupDir
            regbackups = $regDir
            iniBackups = $iniDir
        }
        fivem   = [ordered]@{
            installed = [bool]$exe
            dir       = $(if (Test-Path -LiteralPath $fivemApp) { $fivemApp } else { $fivemHome })
            exists    = (Test-Path -LiteralPath $fivemApp)
            exe       = $exe
        }
        gta     = [ordered]@{
            found  = [bool]$gta
            dir    = $gta
            settings = $setPath
        }
        cache   = [ordered]@{
            cacheMB       = $cache
            serverCacheMB = $server
            nuiMB         = $nui
            logsMB        = [math]::Round(($logs + $crashes), 1)
            totalMB       = [math]::Round(($cache + $server + $nui + $logs + $crashes), 1)
        }
    }
}

function Get-Specs {
    $cpu = Get-RegValue 'HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0' 'ProcessorNameString'
    if (-not $cpu) { $cpu = $env:PROCESSOR_IDENTIFIER }
    $gpu = '—'
    $ram = '—'
    $osName = '—'
    try {
        $g = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue |
             Where-Object { $_.Name -and $_.Name -notmatch 'Basic Display|Remote Desktop|Virtual' } |
             Select-Object -First 1
        if (-not $g) { $g = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Select-Object -First 1 }
        if ($g -and $g.Name) { $gpu = ($g.Name -replace '\s+', ' ').Trim() }
    } catch { }
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
        if ($cs -and $cs.TotalPhysicalMemory) { $ram = "$([math]::Round($cs.TotalPhysicalMemory / 1GB)) GB" }
    } catch { }
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        if ($os -and $os.Caption) { $osName = ($os.Caption -replace '^Microsoft\s+', '').Trim() }
    } catch { }
    return [ordered]@{
        ok  = $true
        cpu = [string]$cpu
        gpu = [string]$gpu
        ram = [string]$ram
        os  = [string]$osName
    }
}

function Get-SettingsData {
    $setPath = Get-SettingsPath
    $doc     = Read-SettingsDoc $setPath
    $sections = [ordered]@{}
    if ($doc.DocumentElement) {
        foreach ($sec in $doc.DocumentElement.ChildNodes) {
            if ($sec.NodeType -ne 'Element') { continue }
            $hasValues = $false
            $bag = [ordered]@{}
            foreach ($n in $sec.ChildNodes) {
                if ($n.NodeType -ne 'Element') { continue }
                $v = $n.GetAttribute('value')
                if ($v -ne '') { $bag[$n.Name] = $v; $hasValues = $true }
            }
            if ($hasValues) { $sections[$sec.Name] = $bag }
        }
    }
    return [ordered]@{
        ok       = $true
        path     = $setPath
        exists   = [bool]$setPath
        sections = $sections
    }
}

function Save-SettingsData($body, [bool]$force) {
    if ((Test-FivemRunning) -and -not $force) {
        return [ordered]@{
            ok = $false
            fivemRunning = $true
            message = 'FiveM กำลังทำงานอยู่ — ปิดเกมก่อนบันทึก ไม่งั้นเกมจะเขียนทับค่าที่ตั้งไว้'
        }
    }

    $setPath = Get-SettingsPath
    if (-not $setPath) { $setPath = Get-DefaultSettingsPath }

    $dir = Split-Path -Parent $setPath
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    $backup = Backup-Settings $setPath
    $doc    = Read-SettingsDoc $setPath
    if (-not $doc.DocumentElement) { $doc = New-SettingsDoc }

    $count = 0
    $sections = $body.sections
    if ($sections) {
        foreach ($sectionProp in $sections.PSObject.Properties) {
            $section = $sectionProp.Name
            if ($section -notmatch '^[A-Za-z0-9_]+$') { continue }
            $bag = $sectionProp.Value
            if (-not $bag) { continue }
            foreach ($prop in $bag.PSObject.Properties) {
                if ($prop.Name -notmatch '^[A-Za-z0-9_]+$') { continue }
                Set-XmlValue $doc $section $prop.Name $prop.Value
                $count++
            }
        }
    }

    # Write without a BOM and without touching line endings so the file stays
    # byte-compatible with the game.
    $writerSettings = New-Object System.Xml.XmlWriterSettings
    $writerSettings.Encoding = New-Object System.Text.UTF8Encoding($false)
    $writerSettings.Indent = $false
    $writerSettings.NewLineHandling = [System.Xml.NewLineHandling]::None
    $writer = [System.Xml.XmlWriter]::Create($setPath, $writerSettings)
    try { $doc.Save($writer) } finally { $writer.Close() }

    $gtaDir = $body.paths.gtaDir
    if (-not $gtaDir) { $gtaDir = Get-GtaDir }
    if ($gtaDir -and (Test-Path -LiteralPath $gtaDir)) {
        if (-not (Test-Path -LiteralPath $fivemApp)) { New-Item -ItemType Directory -Path $fivemApp -Force | Out-Null }
        Set-IniKey $citizenIni 'Game' 'IVPath' $gtaDir
    }

    return [ordered]@{
        ok      = $true
        message = "บันทึก $count ค่า ลง settings.xml แล้ว"
        path    = $setPath
        backup  = $backup
    }
}

function Get-TweakStates {
    $admin = Test-IsAdmin
    $items = @()
    foreach ($t in $TWEAKS) {
        $state = $null
        try {
            $raw = & $t.state
            if ($null -ne $raw) { $state = [bool]$raw }
        } catch { $state = $null }
        $items += [ordered]@{
            id      = $t.id
            cat     = $t.cat
            tier    = $t.tier
            label   = $t.label
            desc    = $t.desc
            admin   = [bool]$t.admin
            reboot  = [bool]$t.reboot
            enabled = $state
            usable  = (-not $t.admin) -or $admin
        }
    }
    return [ordered]@{ ok = $true; admin = $admin; items = $items }
}

function Set-Tweak($body) {
    $id = [string]$body.id
    $enable = [bool]$body.enabled
    $t = $TWEAKS | Where-Object { $_.id -eq $id } | Select-Object -First 1
    if (-not $t) { return [ordered]@{ ok = $false; message = "ไม่รู้จัก tweak: $id" } }
    if ($t.admin -and -not (Test-IsAdmin)) {
        return [ordered]@{ ok = $false; message = 'ต้องรันแอปแบบ Run as administrator ก่อน' }
    }
    if ($t.ini -and (Test-FivemRunning)) {
        return [ordered]@{
            ok = $false
            fivemRunning = $true
            message = 'FiveM กำลังทำงานอยู่ — ปิดเกมก่อน แล้วเปิดใหม่หลังตั้งค่า เพื่อให้ค่ามีผลและเกมไม่เขียนทับไฟล์'
        }
    }

    $backup = $null
    if ($t.regKey -and (Test-Path -LiteralPath ("Registry::" + $t.regKey))) {
        $backup = Backup-RegKey $t.id $t.regKey
    }
    if ($t.ini -and (Test-Path -LiteralPath $citizenIni)) {
        $backup = Backup-Ini $t.id
    }

    try {
        if ($enable) { & $t.enable } else { & $t.disable }
    } catch {
        return [ordered]@{ ok = $false; message = ($_.Exception.Message); backup = $backup }
    }

    $state = $null
    try {
        $raw = & $t.state
        if ($null -ne $raw) { $state = [bool]$raw }
    } catch { $state = $null }

    $verb = if ($enable) { 'เปิด' } else { 'ปิด' }
    return [ordered]@{
        ok      = $true
        id      = $id
        enabled = $state
        backup  = $backup
        message = "$verb $($t.label) แล้ว"
    }
}

function Apply-SafeTweaks {
    if (-not (Test-IsAdmin)) {
        return [ordered]@{ ok = $false; message = 'ต้องรันแอปแบบ Run as administrator ก่อน' }
    }
    $results = @()
    foreach ($t in ($TWEAKS | Where-Object { $_.tier -eq 'safe' })) {
        $state = $null
        try {
            $raw = & $t.state
            if ($null -ne $raw) { $state = [bool]$raw }
        } catch { $state = $null }
        if ($state -eq $true) { continue }
        $backup = $null
        if ($t.regKey -and (Test-Path -LiteralPath ("Registry::" + $t.regKey))) { $backup = Backup-RegKey $t.id $t.regKey }
        try {
            & $t.enable
            $results += [ordered]@{ id = $t.id; ok = $true; backup = $backup }
        } catch {
            $results += [ordered]@{ id = $t.id; ok = $false; message = $_.Exception.Message; backup = $backup }
        }
    }
    $failed = @($results | Where-Object { -not $_.ok }).Count
    return [ordered]@{
        ok = ($failed -eq 0)
        applied = $results.Count
        failed = $failed
        items = $results
        message = "เปิด tweak ระดับปลอดภัย $($results.Count) รายการ" + $(if ($failed) { " (พลาด $failed)" } else { '' })
    }
}

function Get-RegBackups {
    $items = @()
    foreach ($f in (Get-ChildItem -LiteralPath $regDir -Filter *.reg -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
        $items += [ordered]@{
            name = $f.Name
            sizeKB = [math]::Round($f.Length / 1KB, 1)
            date = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
        }
    }
    return [ordered]@{ ok = $true; items = $items }
}

function Restore-RegBackup([string]$name) {
    if ($name -notmatch '^[A-Za-z0-9\-\.]+\.reg$') { return [ordered]@{ ok = $false; message = 'ชื่อไฟล์ไม่ถูกต้อง' } }
    $src = Join-Path $regDir $name
    if (-not (Test-Path -LiteralPath $src)) { return [ordered]@{ ok = $false; message = 'ไม่พบไฟล์สำรอง' } }
    if (-not (Test-IsAdmin)) { return [ordered]@{ ok = $false; message = 'ต้องรันแอปแบบ Run as administrator ก่อน' } }
    & reg.exe import "$src" *>$null
    if ($LASTEXITCODE -ne 0) { return [ordered]@{ ok = $false; message = 'นำเข้า registry ไม่สำเร็จ' } }
    return [ordered]@{ ok = $true; message = "คืนค่า registry จาก $name แล้ว" }
}

$GameOptProcesses = @(
    'FiveM.exe',
    'FiveM_GTAProcess.exe',
    'GTA5.exe',
    'FiveM_ChromeBrowser.exe',
    'FiveM_b2060_GTAProcess.exe',
    'FiveM_b2189_GTAProcess.exe',
    'FiveM_b2372_GTAProcess.exe',
    'FiveM_b2545_GTAProcess.exe',
    'FiveM_b2612_GTAProcess.exe',
    'FiveM_b2699_GTAProcess.exe',
    'FiveM_b2802_GTAProcess.exe',
    'FiveM_b2944_GTAProcess.exe',
    'FiveM_b3095_GTAProcess.exe',
    'FiveM_b3258_GTAProcess.exe',
    'FiveM_b3337_GTAProcess.exe',
    'FiveM_b3407_GTAProcess.exe'
)

function Get-QosState {
    $policies = @()
    try {
        $policies = @(Get-NetQosPolicy -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'GameOpt_*' })
    } catch { $policies = @() }
    $rate = $null
    foreach ($p in $policies) {
        $r = $null
        try { $r = $p.ThrottleRateActionBitsPerSecond } catch { }
        if (-not $r) { try { $r = $p.ThrottleRateAction } catch { } }
        if ($r) { $rate = [double]$r; break }
    }
    return [ordered]@{
        ok         = $true
        admin      = (Test-IsAdmin)
        active     = ($policies.Count -gt 0)
        count      = $policies.Count
        rateBps    = $rate
        rateMbps   = $(if ($rate) { [math]::Round($rate / 1000000, 2) } else { $null })
        policies   = @($policies | ForEach-Object { [ordered]@{ name = $_.Name } })
    }
}

function Set-Qos($body) {
    $action = [string]$body.action
    if (-not (Test-IsAdmin)) {
        return [ordered]@{ ok = $false; message = 'ต้องรันแอปแบบ Run as administrator ก่อน' }
    }

    if ($action -eq 'reset') {
        $removed = 0
        try {
            foreach ($p in @(Get-NetQosPolicy -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'GameOpt_*' })) {
                Remove-NetQosPolicy -Name $p.Name -Confirm:$false -ErrorAction SilentlyContinue
                $removed++
            }
        } catch { }

        # Old versions wrote an unrelated NLA registry value. Clear only our
        # saved state file; current QoS uses policies only.
        Remove-Item -LiteralPath $qosStateFile -Force -ErrorAction SilentlyContinue
        return [ordered]@{ ok = $true; message = "ลบ bandwidth cap แล้ว ($removed policy)" }
    }

    if ($action -ne 'apply') { return [ordered]@{ ok = $false; message = 'action ไม่ถูกต้อง' } }

    $rateMbps = 0.0
    try { $rateMbps = [double]$body.rateMbps } catch { $rateMbps = 0 }
    if ($rateMbps -lt 0.25) { $rateMbps = 0.25 }
    if ($rateMbps -gt 100)  { $rateMbps = 100 }
    $rateBps = [UInt64][math]::Round($rateMbps * 1000000)

    $targets = New-Object System.Collections.Generic.List[string]
    foreach ($n in $GameOptProcesses) { if (-not $targets.Contains($n)) { $targets.Add($n) } }
    try {
        Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like '*FiveM*' -or $_.ProcessName -like '*GTA*' } | ForEach-Object {
            $n = $_.ProcessName + '.exe'
            if (-not $targets.Contains($n)) { $targets.Add($n) }
        }
    } catch { }

    # Replace our own policies only (never touch other apps' QoS rules).
    try {
        foreach ($p in @(Get-NetQosPolicy -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'GameOpt_*' })) {
            Remove-NetQosPolicy -Name $p.Name -Confirm:$false -ErrorAction SilentlyContinue
        }
    } catch { }

    $created = 0
    $errors = @()
    foreach ($target in $targets) {
        $pName = 'GameOpt_' + ($target -replace '[^a-zA-Z0-9_]', '_')
        try {
            New-NetQosPolicy -Name $pName -NetworkProfile All -AppPathNameMatchCondition $target -ThrottleRateActionBitsPerSecond $rateBps -ErrorAction Stop | Out-Null
            $created++
        } catch { $errors += "$target : $($_.Exception.Message)" }
    }
    try {
        New-NetQosPolicy -Name 'GameOpt_Port_30120' -NetworkProfile All -IPPortMatchCondition 30120 -ThrottleRateActionBitsPerSecond $rateBps -ErrorAction Stop | Out-Null
        $created++
    } catch { $errors += "port 30120 : $($_.Exception.Message)" }

    if ($created -eq 0) {
        return [ordered]@{
            ok = $false
            message = 'สร้าง QoS policy ไม่สำเร็จ' + $(if ($errors.Count) { ' — ' + ($errors[0]) } else { '' })
            errors = $errors
        }
    }

    return [ordered]@{
        ok       = $true
        message  = "เปิด bandwidth cap ของ FiveM ที่ $rateMbps Mbps ($created policy)"
        created  = $created
        rateMbps = $rateMbps
        errors   = $errors
    }
}

function Invoke-Action($body) {
    $action = [string]$body.action
    $freed  = 0.0
    $msg    = 'Action completed'

    switch ($action) {
        'clean-cache' {
            $freed += (Clear-Folder (Join-Path $fivemApp 'data\cache'))
            $freed += (Clear-Folder (Join-Path $fivemApp 'data\server-cache'))
            $freed += (Clear-Folder (Join-Path $fivemApp 'data\nui-views'))
            $msg = 'ล้างแคช FiveM แล้ว'
        }
        'clean-browser-cache' {
            $freed += (Clear-Folder (Join-Path $fivemApp 'data\cache\browser'))
            $freed += (Clear-Folder (Join-Path $fivemApp 'data\cache\subprocess'))
            $msg = 'ล้างแคช browser/subprocess แล้ว (ปลอดภัยกว่า — เกมสร้างใหม่เอง)'
        }
        'clean-logs' {
            $freed += (Clear-Folder (Join-Path $fivemApp 'data\logs'))
            $freed += (Clear-Folder (Join-Path $fivemApp 'crashes'))
            $msg = 'ล้าง log และ crash dump แล้ว'
        }
        'flush-dns' {
            & ipconfig /flushdns *>$null
            $msg = 'ล้าง DNS cache แล้ว'
        }
        'set-dns' {
            $pri = [string]$body.primary
            $sec = [string]$body.secondary
            if (-not $pri) { return [ordered]@{ ok = $false; message = 'No DNS address supplied' } }
            if (-not (Test-IsAdmin)) {
                return [ordered]@{ ok = $false; message = 'ต้องรันแอปแบบ Run as administrator ก่อน' }
            }
            $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' }
            foreach ($a in $adapters) {
                if ($sec) {
                    Set-DnsClientServerAddress -InterfaceIndex $a.InterfaceIndex -ServerAddresses @($pri, $sec) -ErrorAction SilentlyContinue
                } else {
                    Set-DnsClientServerAddress -InterfaceIndex $a.InterfaceIndex -ServerAddresses @($pri) -ErrorAction SilentlyContinue
                }
            }
            $msg = "ตั้ง DNS เป็น $pri แล้ว"
        }
        'launch' {
            $exe = Get-FivemExe
            if (-not $exe) {
                return [ordered]@{ ok = $false; message = 'ไม่พบ FiveM.exe' }
            }
            Start-Process -FilePath $exe -WorkingDirectory (Split-Path -Parent $exe)
            $msg = 'กำลังเปิด FiveM'
        }
        'connect' {
            $url = [string]$body.url
            if ($url -notmatch '^[A-Za-z0-9\.\-_:/]+$') {
                return [ordered]@{ ok = $false; message = 'ที่อยู่เซิร์ฟเวอร์ไม่ถูกต้อง' }
            }
            Start-Process "fivem://connect/$url"
            $msg = "กำลังเชื่อมต่อ $url"
        }
        'backup' {
            $setPath = Get-SettingsPath
            $name = Backup-Settings $setPath
            if (-not $name) { return [ordered]@{ ok = $false; message = 'ยังไม่มีไฟล์ให้สำรอง' } }
            $msg = "สร้างไฟล์สำรองแล้ว: $name"
        }
        'restore' {
            if (Test-FivemRunning) {
                return [ordered]@{
                    ok = $false
                    fivemRunning = $true
                    message = 'FiveM กำลังทำงานอยู่ — ปิดเกมก่อนกู้คืนไฟล์ เพื่อไม่ให้เกมเขียนทับค่าที่กู้คืน'
                }
            }
            $name = [string]$body.name
            if ($name -notmatch '^[A-Za-z0-9\-\.]+\.xml$') {
                return [ordered]@{ ok = $false; message = 'ชื่อไฟล์สำรองไม่ถูกต้อง' }
            }
            $src = Join-Path $backupDir $name
            if (-not (Test-Path -LiteralPath $src)) {
                return [ordered]@{ ok = $false; message = 'ไม่พบไฟล์สำรอง' }
            }
            $setPath = Get-SettingsPath
            if (-not $setPath) { $setPath = Get-DefaultSettingsPath }
            Backup-Settings $setPath | Out-Null
            Copy-Item -LiteralPath $src -Destination $setPath -Force
            $msg = "กู้คืน $name แล้ว"
        }
        'set-gta-dir' {
            $gtaDir = [string]$body.gtaDir
            if ([string]::IsNullOrWhiteSpace($gtaDir) -or -not (Test-Path -LiteralPath $gtaDir -PathType Container)) {
                return [ordered]@{ ok = $false; message = 'ไม่พบโฟลเดอร์ GTA V ที่ระบุ' }
            }
            if (-not (Test-Path -LiteralPath $fivemApp)) { New-Item -ItemType Directory -Path $fivemApp -Force | Out-Null }
            Set-IniKey $citizenIni 'Game' 'IVPath' $gtaDir
            $msg = 'บันทึกพาธ GTA V ใน CitizenFX.ini แล้ว'
        }
        'reg-restore' {
            return (Restore-RegBackup ([string]$body.name))
        }
        'ini-restore' {
            if (Test-FivemRunning) {
                return [ordered]@{
                    ok = $false
                    fivemRunning = $true
                    message = 'FiveM กำลังทำงานอยู่ — ปิดเกมก่อนกู้คืน CitizenFX.ini เพื่อไม่ให้เกมเขียนทับค่า'
                }
            }
            $name = [string]$body.name
            if ($name -notmatch '^[A-Za-z0-9\-\.]+\.ini$') { return [ordered]@{ ok = $false; message = 'ชื่อไฟล์ไม่ถูกต้อง' } }
            $src = Join-Path $iniDir $name
            if (-not (Test-Path -LiteralPath $src)) { return [ordered]@{ ok = $false; message = 'ไม่พบไฟล์สำรอง' } }
            if (-not (Test-Path -LiteralPath $citizenIni)) { return [ordered]@{ ok = $false; message = 'ไม่พบ CitizenFX.ini' } }
            Backup-Ini 'pre-restore' | Out-Null
            Copy-Item -LiteralPath $src -Destination $citizenIni -Force
            $msg = "กู้คืน CitizenFX.ini จาก $name แล้ว"
        }
        'open' {
            $target = [string]$body.target
            switch ($target) {
                'fivem'   { if (Test-Path -LiteralPath $fivemApp) { Start-Process $fivemApp } else { Start-Process $fivemHome } }
                'gta'     { $g = Get-GtaDir; if ($g) { Start-Process $g } else { return [ordered]@{ ok = $false; message = 'ไม่พบโฟลเดอร์ GTA V' } } }
                'settings' {
                    $s = Get-SettingsPath
                    if ($s) { Start-Process (Split-Path -Parent $s) }
                    elseif (Test-Path -LiteralPath $docGta) { Start-Process $docGta }
                    else { return [ordered]@{ ok = $false; message = 'ไม่พบ settings.xml' } }
                }
                'backups' { Start-Process $backupDir }
                'regbackups' { Start-Process $regDir }
                'iniBackups' { Start-Process $iniDir }
                'app'     { Start-Process $appRoot }
                default   { return [ordered]@{ ok = $false; message = 'Unknown folder' } }
            }
            $msg = 'เปิดโฟลเดอร์แล้ว'
        }
        default {
            return [ordered]@{ ok = $false; message = "Unknown action: $action" }
        }
    }

    return [ordered]@{
        ok      = $true
        message = $msg
        action  = $action
        freedMB = [math]::Round($freed, 1)
    }
}

function Handle-Api($ctx, [string]$path) {
    $req = $ctx.Request

    if ($path -eq '/api/ping') {
        Send-Json $ctx ([ordered]@{ ok = $true; app = $appName; version = $appVer })
        return
    }
    if ($path -eq '/api/status') {
        Send-Json $ctx (Get-Status)
        return
    }
    if ($path -eq '/api/specs') {
        Send-Json $ctx (Get-Specs)
        return
    }
    if ($path -eq '/api/settings' -and $req.HttpMethod -eq 'GET') {
        Send-Json $ctx (Get-SettingsData)
        return
    }
    if ($path -eq '/api/settings' -and $req.HttpMethod -eq 'POST') {
        $body = Get-Body $req
        if (-not $body) { Send-Json $ctx ([ordered]@{ ok = $false; message = 'Empty request body' }) 400; return }
        Send-Json $ctx (Save-SettingsData $body ([bool]$body.force))
        return
    }
    if ($path -eq '/api/backups') {
        $files = @()
        foreach ($f in (Get-ChildItem -LiteralPath $backupDir -Filter *.xml -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
            $files += [ordered]@{
                name = $f.Name
                sizeKB = [math]::Round($f.Length / 1KB, 1)
                date = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
            }
        }
        Send-Json $ctx ([ordered]@{ ok = $true; items = $files })
        return
    }
    if ($path -eq '/api/regbackups') {
        Send-Json $ctx (Get-RegBackups)
        return
    }
    if ($path -eq '/api/inibackups') {
        Send-Json $ctx (Get-IniBackups)
        return
    }
    if ($path -eq '/api/tweaks' -and $req.HttpMethod -eq 'GET') {
        Send-Json $ctx (Get-TweakStates)
        return
    }
    if ($path -eq '/api/tweak' -and $req.HttpMethod -eq 'POST') {
        $body = Get-Body $req
        if (-not $body) { Send-Json $ctx ([ordered]@{ ok = $false; message = 'Empty request body' }) 400; return }
        Send-Json $ctx (Set-Tweak $body)
        return
    }
    if ($path -eq '/api/tweaks/apply-safe' -and $req.HttpMethod -eq 'POST') {
        Send-Json $ctx (Apply-SafeTweaks)
        return
    }
    if ($path -eq '/api/qos' -and $req.HttpMethod -eq 'GET') {
        Send-Json $ctx (Get-QosState)
        return
    }
    if ($path -eq '/api/qos' -and $req.HttpMethod -eq 'POST') {
        $body = Get-Body $req
        if (-not $body) { Send-Json $ctx ([ordered]@{ ok = $false; message = 'Empty request body' }) 400; return }
        Send-Json $ctx (Set-Qos $body)
        return
    }
    if ($path -eq '/api/action' -and $req.HttpMethod -eq 'POST') {
        $body = Get-Body $req
        if (-not $body) { Send-Json $ctx ([ordered]@{ ok = $false; message = 'Empty request body' }) 400; return }
        Send-Json $ctx (Invoke-Action $body)
        return
    }

    Send-Json $ctx ([ordered]@{ ok = $false; message = 'Unknown endpoint' }) 404
}

# ------------------------------ server ---------------------------------

$candidatePorts = @($port) + (5180..5199 | Where-Object { $_ -ne $port })

# If a copy of this app is already running on any candidate port, just open
# that window instead of starting a second server.
$runningUrl = $null
# The port we bound last time is remembered, so a second launch finds the
# running instance instantly instead of scanning every candidate.
$probePorts = @()
$statePort = 0
$portFile = Join-Path $dataRoot 'port.txt'
if (Test-Path -LiteralPath $portFile) {
    try { $statePort = [int]((Get-Content -LiteralPath $portFile -Raw).Trim()) } catch { $statePort = 0 }
}
if ($statePort -gt 0) { $probePorts += $statePort }
$probePorts += ($candidatePorts | Where-Object { $probePorts -notcontains $_ } | Select-Object -First 5)

foreach ($p in $probePorts) {
    if (-not (Test-PortListening $p)) { continue }
    try {
        $probe = Invoke-WebRequest -Uri "http://localhost:$p/api/ping" -UseBasicParsing -TimeoutSec 2
        if ($probe.StatusCode -eq 200 -and $probe.Content -like "*$appName*") {
            $runningUrl = "http://localhost:$p/"
            break
        }
    } catch { }
}
if ($runningUrl) {
    Write-Host ''
    Write-Host "  $appName is already running on $runningUrl" -ForegroundColor Yellow
    if (-not $NoBrowser) { Start-Process $runningUrl }
    Start-Sleep -Milliseconds 900
    exit
}

# Pick the first free port so the app still starts when another program is
# using 5180. The UI talks to the backend over relative URLs, so it does
# not care which port we end up on.
# Each attempt uses a fresh listener: once HttpListener.Start() fails the
# instance cannot be restarted, so reusing it would kill every fallback.
$listener = $null
$started  = $false
foreach ($p in $candidatePorts) {
    $l = New-Object System.Net.HttpListener
    $l.IgnoreWriteExceptions = $true
    foreach ($prefix in @("http://localhost:$p/", "http://127.0.0.1:$p/")) {
        try {
            $l.Prefixes.Clear()
            $l.Prefixes.Add($prefix)
            $l.Start()
            $listener = $l
            $started  = $true
            $port     = $p
            break
        } catch { $started = $false }
    }
    if ($started) { break }
    try { $l.Stop() }  catch { }
    try { $l.Close() } catch { }
}

if (-not $started) {
    Write-Host ''
    Write-Host "  Cannot start a web server on ports 5180-5199." -ForegroundColor Red
    Write-Host "  Close other apps that use those ports and run this file again." -ForegroundColor Red
    Start-Sleep -Seconds 5
    exit 1
}

Write-Host ''
Write-Host "  $appName" -ForegroundColor Magenta
Write-Host "  http://localhost:$port" -ForegroundColor Green
Write-Host "  Close this window to stop the app." -ForegroundColor DarkGray
Write-Host ''

# Remember the port so a second launch can detect this instance quickly.
try { Set-Content -LiteralPath $portFile -Value ([string]$port) -Encoding ASCII } catch { }

if (-not $NoBrowser) { Start-Process "http://localhost:$port/" }

$mime = @{
    '.html' = 'text/html; charset=utf-8'
    '.js'   = 'application/javascript; charset=utf-8'
    '.mjs'  = 'application/javascript; charset=utf-8'
    '.css'  = 'text/css; charset=utf-8'
    '.json' = 'application/json; charset=utf-8'
    '.svg'  = 'image/svg+xml'
    '.png'  = 'image/png'
    '.jpg'  = 'image/jpeg'
    '.ico'  = 'image/x-icon'
    '.woff2'= 'font/woff2'
}

$rootFull = [System.IO.Path]::GetFullPath($appRoot)

try {
    while ($listener.IsListening) {
        $ctx = $null
        try {
            $ctx = $listener.GetContext()
        } catch {
            # Browsers routinely abort requests on navigation/reload. That
            # raises from GetContext() and must not kill the whole server.
            if (-not $listener.IsListening) { break }
            Start-Sleep -Milliseconds 50
            continue
        }
        try {
            $path = $ctx.Request.Url.LocalPath

            if ($path -like '/api/*') {
                Handle-Api $ctx $path
                continue
            }

            $rel = $path.TrimStart('/')
            if ([string]::IsNullOrEmpty($rel)) { $rel = 'index.html' }
            $full = [System.IO.Path]::GetFullPath((Join-Path $appRoot ($rel -replace '/', '\')))

            if (-not $full.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                $ctx.Response.StatusCode = 403
                $ctx.Response.Close()
                continue
            }

            if (Test-Path -LiteralPath $full -PathType Leaf) {
                $bytes = [System.IO.File]::ReadAllBytes($full)
                $ext   = [System.IO.Path]::GetExtension($full).ToLower()
                $type  = $mime[$ext]
                if (-not $type) { $type = 'application/octet-stream' }
                $ctx.Response.ContentType     = $type
                # Always re-read on reload: a rebuilt app must never be served
                # from a stale browser cache after an upgrade.
                $ctx.Response.Headers['Cache-Control']          = 'no-store, max-age=0'
                $ctx.Response.Headers['X-Content-Type-Options'] = 'nosniff'
                $ctx.Response.ContentLength64 = $bytes.Length
                $ctx.Response.StatusCode      = 200
                $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
                $ctx.Response.Close()
            } else {
                $notFound = [System.Text.Encoding]::UTF8.GetBytes('404 Not Found')
                $ctx.Response.StatusCode      = 404
                $ctx.Response.ContentType     = 'text/plain; charset=utf-8'
                $ctx.Response.ContentLength64 = $notFound.Length
                $ctx.Response.OutputStream.Write($notFound, 0, $notFound.Length)
                $ctx.Response.Close()
            }
        } catch {
            try {
                if ($ctx) { $ctx.Response.StatusCode = 500; $ctx.Response.Close() }
            } catch { }
        }
    }
} finally {
    if ($listener.IsListening) { $listener.Stop() }
}
