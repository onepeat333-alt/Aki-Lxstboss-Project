import { getBackups, getIniBackups, getRegBackups, saveSettings, setTweak } from '../api.js';
import { PRESETS } from '../data.js';
import { icon } from '../icons.js';
import { getPerfPref, getPerfResolved, perfLabel, setPerfPref } from '../perf.js';
import { doAction } from '../actions.js';
import {
  currentPresetId, payloadFrom, pushActivity, savePaths, setState, state,
} from '../store.js';
import { confirmDialog, escapeHtml, shortPath, spinner, toast } from '../ui.js';

function pathRow(label, path, target) {
  return `<div class="kv">
    <span class="kv-label">${escapeHtml(label)}</span>
    <span class="kv-path">
      <code title="${escapeHtml(path || '')}">${escapeHtml(shortPath(path || '—', 50))}</code>
      <button class="icon-btn" data-open="${target}" title="เปิด">${icon('folder')}</button>
    </span>
  </div>`;
}

function settingsBackupRow(item) {
  return `<div class="list-row">
    <span class="act-ico info">${icon('save')}</span>
    <span class="fav-main">
      <span class="fav-name mono">${escapeHtml(item.name)}</span>
      <span class="fav-url">${escapeHtml(item.date)} · ${item.sizeKB} KB</span>
    </span>
    <button class="btn btn-sm btn-outline" data-restore="${escapeHtml(item.name)}">${icon('rotate')} กู้คืน</button>
  </div>`;
}

function regBackupRow(item) {
  return `<div class="list-row">
    <span class="act-ico warn">${icon('key')}</span>
    <span class="fav-main">
      <span class="fav-name mono">${escapeHtml(item.name)}</span>
      <span class="fav-url">${escapeHtml(item.date)} · ${item.sizeKB} KB</span>
    </span>
    <button class="btn btn-sm btn-outline" data-reg-restore="${escapeHtml(item.name)}">${icon('rotate')} กู้คืน</button>
  </div>`;
}

function iniBackupRow(item) {
  return `<div class="list-row">
    <span class="act-ico info">${icon('terminal')}</span>
    <span class="fav-main">
      <span class="fav-name mono">${escapeHtml(item.name)}</span>
      <span class="fav-url">${escapeHtml(item.date)} · ${item.sizeKB} KB</span>
    </span>
    <button class="btn btn-sm btn-outline" data-ini-restore="${escapeHtml(item.name)}">${icon('rotate')} กู้คืน</button>
  </div>`;
}

export default function mount(root, ctx) {
  const s = state.status || {};
  const paths = s.paths || {};

  root.innerHTML = `
    <div class="grid-2">
      <div class="stack">
        <section class="card setup-card">
          <div class="setup-hero">
            <img class="setup-banner" src="./assets/lxstboss-banner.svg" alt="" />
            <span class="setup-sheen" aria-hidden="true"></span>
            <div class="setup-hero-text">
              <span class="eyebrow">Quick Setup</span>
              <h2>ติดตั้งชุดค่าทั้งหมดในคลิกเดียว</h2>
              <p>เลือกโปรไฟล์กราฟิก แล้วให้ระบบเขียนค่าลง gta5_settings.xml พร้อมเปิด Optimize ตามโหมดที่เลือก</p>
            </div>
          </div>
          <div class="card-body">
            <div class="setup-profiles" id="setup-profiles">
              ${PRESETS.map((p) => `<button class="setup-profile ${p.id === currentPresetId() ? 'active' : ''}"
                data-setup-preset="${p.id}">
                <span class="sp-name">${escapeHtml(p.name)}</span>
                <span class="sp-tag">${escapeHtml(p.tagline)}</span>
              </button>`).join('')}
            </div>
            <div class="setup-actions">
              <button class="btn btn-primary" data-setup-run="all">${icon('zap')} เปิดทั้งหมด (Lxst สุด)</button>
              <button class="btn btn-outline" data-setup-run="step">${icon('sliders')} ไล่ทีละตัว</button>
            </div>
            <div class="setup-progress" id="setup-progress" hidden>
              <div class="setup-bar"><span id="setup-fill"></span></div>
              <div class="setup-status">
                <span id="setup-step">กำลังเริ่ม…</span>
                <span><b id="setup-count">0/0</b></span>
              </div>
            </div>
            <p class="hint mt8">โหมด Lxst เปิดทุก tweak ที่กดได้ (รวม advanced) — อยากปิดกลับไปปิดทีละตัวได้ที่หน้า
            <a href="#/tweaks">Optimize</a></p>
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('folder')}</span>
              <div>
                <h2 class="card-title">ตำแหน่งติดตั้ง</h2>
                <p class="card-desc">ใช้ระบุโฟลเดอร์เกม หากระบบตรวจหาไม่พบอัตโนมัติ</p>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="kv">
              <span class="kv-label">โฟลเดอร์ FiveM</span>
              <span class="kv-path">
                <code title="${escapeHtml(paths.fivemApp || '')}">${escapeHtml(shortPath(paths.fivemApp || 'ไม่พบ', 50))}</code>
                <button class="icon-btn" data-open="fivem" title="เปิด">${icon('folder')}</button>
              </span>
            </div>

            <div class="form-block">
              <label class="input-label" for="gta-dir">โฟลเดอร์ Grand Theft Auto V</label>
              <div class="input-row">
                <input class="input" id="gta-dir" type="text"
                  placeholder="C:\\Program Files\\Rockstar Games\\Grand Theft Auto V"
                  value="${escapeHtml(state.paths.gtaDir || paths.gta || '')}" />
                <button class="btn btn-primary" data-save-paths>${icon('save')} บันทึก</button>
              </div>
              <p class="hint">ค่านี้จะถูกเขียนลง <code>CitizenFX.ini</code> (IVPath) ให้ FiveM เปิดเกมถูกโฟลเดอร์</p>
            </div>

            <div class="divider"></div>
            ${pathRow('ไฟล์ตั้งค่า gta5_settings.xml', paths.settings, 'settings')}
            ${pathRow('โฟลเดอร์ไฟล์สำรองค่า', paths.backups, 'backups')}
            ${pathRow('โฟลเดอร์สำรอง registry', paths.regbackups, 'regbackups')}
            ${paths.iniBackups ? pathRow('โฟลเดอร์สำรอง CitizenFX.ini', paths.iniBackups, 'iniBackups') : ''}
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('save')}</span>
              <div>
                <h2 class="card-title">ไฟล์สำรองค่า</h2>
                <p class="card-desc">ทุกครั้งที่บันทึก ระบบจะเก็บ gta5_settings.xml เดิมไว้ที่นี่</p>
              </div>
            </div>
            <button class="btn btn-sm btn-outline" data-backup>${icon('plus')} สำรองตอนนี้</button>
          </div>
          <div class="card-body" id="backup-list">${spinner('กำลังโหลดไฟล์สำรอง…')}</div>
        </section>

        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('key')}</span>
              <div>
                <h2 class="card-title">สำรอง registry</h2>
                <p class="card-desc">ค่าเดิมจะถูก export เป็นไฟล์ .reg ก่อนทุกครั้งที่เปิด/ปิด tweak</p>
              </div>
            </div>
            <button class="btn btn-sm btn-outline" data-open="regbackups">${icon('folder')} เปิดโฟลเดอร์</button>
          </div>
          <div class="card-body" id="reg-list">${spinner('กำลังโหลด registry backup…')}</div>
        </section>

        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('terminal')}</span>
              <div>
                <h2 class="card-title">สำรอง CitizenFX.ini</h2>
                <p class="card-desc">ไฟล์นี้เก็บค่าเปิดเกม + engine flags — ระบบสำรองก่อนแตะทุกครั้ง</p>
              </div>
            </div>
            <button class="btn btn-sm btn-outline" data-open="iniBackups">${icon('folder')} เปิดโฟลเดอร์</button>
          </div>
          <div class="card-body" id="ini-list">${spinner('กำลังโหลด CitizenFX.ini backup…')}</div>
        </section>
      </div>

      <aside class="stack">
        <section class="card">
          <div class="card-head">
            <div>
              <h2 class="card-title">เกี่ยวกับแอป</h2>
              <p class="card-desc">Aki Lxst Boss Optimize</p>
            </div>
            <span class="chip info">v${escapeHtml(s.version || '2.0.0')}</span>
          </div>
          <div class="card-body">
            <div class="about-brand">
              <img class="about-logo" src="./assets/aki-logo.png" alt="Lxstboss" />
              <div>
                <div class="about-name">Aki Lxst Boss <b>Optimize</b></div>
                <div class="about-tag">King of Weapon — FiveM Edition</div>
              </div>
            </div>
            <div class="kv"><span class="kv-label">เวอร์ชัน</span><span class="kv-value">${escapeHtml(s.version || '2.0.0')}</span></div>
            <div class="kv"><span class="kv-label">โหมดการทำงาน</span><span class="kv-value">${state.demo ? 'โหมดตัวอย่าง' : 'เชื่อมต่อ backend แล้ว'}</span></div>
            <div class="kv"><span class="kv-label">พอร์ต</span><span class="kv-value mono">${escapeHtml(String(s.port || 5180))}</span></div>
            <div class="kv"><span class="kv-label">สิทธิ์ผู้ดูแล</span><span class="kv-value ${s.admin ? 'ok' : 'warn'}">${s.admin ? 'มี' : 'ไม่มี'}</span></div>
            <div class="divider"></div>
            <button class="btn btn-outline btn-block" data-open="app">${icon('terminal')} เปิดโฟลเดอร์แอป</button>
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('monitor')}</span>
              <div>
                <h2 class="card-title">ประสิทธิภาพหน้าจอ</h2>
                <p class="card-desc">ปรับความลื่นของการเลื่อนและเปลี่ยนหน้า</p>
              </div>
            </div>
            <span class="chip info" id="perf-now">${perfLabel()}</span>
          </div>
          <div class="card-body">
            <div class="perf-choices" id="perf-choices">
              <button class="perf-choice" data-perf-set="auto" type="button">อัตโนมัติ</button>
              <button class="perf-choice" data-perf-set="smooth" type="button">ลื่นไหล</button>
              <button class="perf-choice" data-perf-set="full" type="button">เอฟเฟกต์เต็ม</button>
            </div>
            <p class="hint mt8" id="perf-hint">กำลังตรวจสอบเครื่อง…</p>
          </div>
        </section>

        <section class="card card-pad">
          <div class="tip">
            ${icon('info')}
            <div><strong>ข้อมูลอยู่ที่ไหน</strong><br />
            ค่าและ registry backup ถูกเก็บใน <code>%LOCALAPPDATA%\\AkiLxstboss</code>
            (<code>backups</code> / <code>regbackups</code> / <code>citizenfx-backups</code>)
            — ลบโฟลเดอร์นี้ได้เมื่อต้องการรีเซ็ตประวัติทั้งหมด</div>
          </div>
        </section>

        <section class="card card-pad">
          <div class="tip">
            ${icon('shield')}
            <div>หากต้องการเปลี่ยนพอร์ต ให้แก้ตัวแปร <code>$port</code> ใน <code>server.ps1</code>
            แล้วรีสตาร์ทผ่าน <code>run.bat</code></div>
          </div>
        </section>
      </aside>
    </div>`;

  async function loadBackups() {
    const listEl = root.querySelector('#backup-list');
    if (!listEl) return;
    listEl.innerHTML = spinner('กำลังโหลดไฟล์สำรอง…');
    try {
      const data = await getBackups();
      const items = data.items || [];
      listEl.innerHTML = items.length
        ? `<div class="list">${items.map(settingsBackupRow).join('')}</div>`
        : `<div class="empty">${icon('save', 'empty-ico')}
            <div class="empty-title">ยังไม่มีไฟล์สำรอง</div>
            <div class="empty-text">ไฟล์จะถูกสร้างอัตโนมัติเมื่อบันทึกค่าครั้งแรก</div></div>`;
    } catch {
      listEl.innerHTML = `<div class="empty">${icon('alert', 'empty-ico')}
        <div class="empty-title">โหลดรายการไม่สำเร็จ</div></div>`;
    }
  }

  async function loadRegBackups() {
    const listEl = root.querySelector('#reg-list');
    if (!listEl) return;
    listEl.innerHTML = spinner('กำลังโหลด registry backup…');
    try {
      const data = await getRegBackups();
      const items = data.items || [];
      listEl.innerHTML = items.length
        ? `<div class="list">${items.map(regBackupRow).join('')}</div>`
        : `<div class="empty">${icon('key', 'empty-ico')}
            <div class="empty-title">ยังไม่มี registry backup</div>
            <div class="empty-text">ระบบจะ export ค่าเดิมก่อนแก้ registry ทุกครั้ง</div></div>`;
    } catch {
      listEl.innerHTML = `<div class="empty">${icon('alert', 'empty-ico')}
        <div class="empty-title">โหลดรายการไม่สำเร็จ</div></div>`;
    }
  }

  root.querySelector('[data-save-paths]')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const value = root.querySelector('#gta-dir').value.trim();
    btn.disabled = true;
    const res = await doAction('set-gta-dir', {
      silent: true,
      icon: 'folder',
      extra: { gtaDir: value },
    });
    if (res.ok) {
      savePaths({ gtaDir: value });
      toast('บันทึกพาธ GTA V เรียบร้อย', 'success');
    } else {
      toast(res.message || 'บันทึกพาธไม่สำเร็จ', 'error');
    }
    btn.disabled = false;
  });

  root.querySelector('[data-backup]')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    const res = await doAction('backup', { label: 'สร้างไฟล์สำรองแล้ว', icon: 'save' });
    btn.disabled = false;
    if (res.ok) loadBackups();
  });

  async function loadIniBackups() {
    const listEl = root.querySelector('#ini-list');
    if (!listEl) return;
    listEl.innerHTML = spinner('กำลังโหลด CitizenFX.ini backup…');
    try {
      const data = await getIniBackups();
      const items = data.items || [];
      listEl.innerHTML = items.length
        ? `<div class="list">${items.map(iniBackupRow).join('')}</div>`
        : `<div class="empty">${icon('terminal', 'empty-ico')}
            <div class="empty-title">ยังไม่มี CitizenFX.ini backup</div>
            <div class="empty-text">ระบบจะสำรอง CitizenFX.ini ก่อนแก้ทุกครั้ง (กลุ่ม FiveM / GTA Engine)</div></div>`;
    } catch {
      listEl.innerHTML = `<div class="empty">${icon('alert', 'empty-ico')}
        <div class="empty-title">โหลดรายการไม่สำเร็จ</div></div>`;
    }
  }

  root.querySelectorAll('[data-open]').forEach((btn) => {
    btn.addEventListener('click', () => {
      doAction('open', { silent: true, extra: { target: btn.dataset.open }, icon: 'folder' });
    });
  });

  /* ------------------------------ performance ------------------------------ */

  const perfBox = root.querySelector('#perf-choices');
  const perfNow = root.querySelector('#perf-now');
  const perfHint = root.querySelector('#perf-hint');
  const hints = {
    auto: 'ระบบเลือกตามสเปกเครื่องให้ — ถ้าเฟรมตกจะลดเอฟเฟกต์ให้เองในรอบนั้น',
    smooth: 'ปิดเบลอและเงาที่ขยับตลอดเวลา — ค่าแนะนำสำหรับเล่นเกม',
    full: 'เปิดครบทุกอนิเมชัน — สวยที่สุดแต่ใช้การ์ดจอมากกว่า',
  };

  function paintPerf() {
    const pref = getPerfPref();
    if (perfBox) {
      perfBox.querySelectorAll('[data-perf-set]').forEach((b) => {
        b.classList.toggle('active', b.dataset.perfSet === pref);
      });
    }
    if (perfNow) perfNow.textContent = perfLabel();
    if (perfHint) {
      const resolved = getPerfResolved();
      perfHint.textContent = pref === 'auto' && resolved === 'lite'
        ? 'เครื่องนี้ใช้โหมดประหยัดเป็นค่าเริ่มต้น — เลือก "เอฟเฟกต์เต็ม" ได้ถ้าต้องการ'
        : hints[pref] || hints.auto;
    }
  }

  perfBox?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-perf-set]');
    if (!btn) return;
    setPerfPref(btn.dataset.perfSet);
    paintPerf();
    toast('ปรับประสิทธิภาพหน้าจอแล้ว', 'success', 1800);
  });

  const onPerf = () => {
    if (!root.isConnected) {
      document.removeEventListener('aki:perf', onPerf);
      return;
    }
    paintPerf();
  };
  document.addEventListener('aki:perf', onPerf);
  paintPerf();

  root.querySelector('#backup-list')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-restore]');
    if (!btn) return;
    const name = btn.dataset.restore;
    const ok = await confirmDialog({
      title: 'กู้คืนไฟล์สำรองนี้?',
      text: `ระบบจะเขียนทับ gta5_settings.xml ปัจจุบันด้วย ${name} (ไฟล์ปัจจุบันจะถูกสำรองไว้ก่อน)`,
      confirmText: 'กู้คืน',
    });
    if (!ok) return;
    btn.disabled = true;
    const res = await doAction('restore', { silent: true, extra: { name }, icon: 'rotate' });
    toast(res.ok ? `กู้คืน ${name} แล้ว` : res.message || 'กู้คืนไม่สำเร็จ', res.ok ? 'success' : 'error');
    btn.disabled = false;
    if (res.ok) {
      ctx.refresh();
      loadBackups();
    }
  });

  root.querySelector('#reg-list')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-reg-restore]');
    if (!btn) return;
    const name = btn.dataset.regRestore;
    const ok = await confirmDialog({
      title: 'นำเข้า registry backup นี้?',
      text: `ระบบจะ import ${name} กลับเข้า registry — ต้องรันแอปแบบ administrator`,
      confirmText: 'นำเข้า',
    });
    if (!ok) return;
    btn.disabled = true;
    const res = await doAction('reg-restore', { silent: true, extra: { name }, icon: 'rotate' });
    toast(res.ok ? `นำเข้า ${name} แล้ว` : res.message || 'นำเข้าไม่สำเร็จ', res.ok ? 'success' : 'error');
    btn.disabled = false;
  });

  root.querySelector('#ini-list')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-ini-restore]');
    if (!btn) return;
    const name = btn.dataset.iniRestore;
    const ok = await confirmDialog({
      title: 'กู้คืน CitizenFX.ini นี้?',
      text: `ระบบจะเขียนทับ CitizenFX.ini ปัจจุบันด้วย ${name} (ระบบจะสำรองไฟล์ปัจจุบันไว้ก่อน) — ปิด FiveM ก่อนเสมอ`,
      confirmText: 'กู้คืน',
    });
    if (!ok) return;
    btn.disabled = true;
    const res = await doAction('ini-restore', { silent: true, extra: { name }, icon: 'rotate' });
    toast(res.ok ? `กู้คืน ${name} แล้ว` : res.message || 'กู้คืนไม่สำเร็จ', res.ok ? 'success' : 'error');
    btn.disabled = false;
    if (res.ok) loadIniBackups();
  });

  /* ------------------------------ quick setup ------------------------------ */

  const profilesEl = root.querySelector('#setup-profiles');
  const progressEl = root.querySelector('#setup-progress');
  const fillEl = root.querySelector('#setup-fill');
  const stepEl = root.querySelector('#setup-step');
  const countEl = root.querySelector('#setup-count');
  let chosen = currentPresetId();

  profilesEl?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-setup-preset]');
    if (!btn) return;
    chosen = btn.dataset.setupPreset;
    profilesEl.querySelectorAll('.setup-profile').forEach((b) => {
      b.classList.toggle('active', b === btn);
    });
  });

  async function applyChosenPreset(preset) {
    const values = { ...state.values, ...preset.values };
    let res = await saveSettings(payloadFrom(values));
    if (!res.ok && res.fivemRunning) {
      const force = await confirmDialog({
        title: 'FiveM กำลังทำงานอยู่',
        text: 'เกมจะเขียนทับไฟล์นี้เมื่อปิด แนะนำให้ปิดเกมก่อนจะกด Quick Setup',
        confirmText: 'เขียนทับเลย',
        danger: true,
      });
      if (!force) return { ok: false, cancelled: true };
      res = await saveSettings({ ...payloadFrom(values), force: true });
    }
    if (res.ok) {
      setState({ values, saved: { ...values } });
      pushActivity(`Quick Setup: ${preset.name}`, 'success', 'zap');
    }
    return res;
  }

  async function runSetup(mode) {
    const preset = PRESETS.find((p) => p.id === chosen) || PRESETS[0];
    const targets = (state.tweaks || []).filter((t) => t.usable !== false);
    const buttons = [...root.querySelectorAll('[data-setup-run]')];

    if (mode === 'all') {
      const ok = await confirmDialog({
        title: `เปิดทุกอย่างด้วยโปรไฟล์ ${preset.name}?`,
        text: `ระบบจะเขียนค่ากราฟิกและเปิด tweak ทั้งหมด ${targets.length} รายการ (รวม advanced) — ปิดกลับได้ทีละตัวที่หน้า Optimize`,
        confirmText: 'เปิดทั้งหมด',
        danger: true,
      });
      if (!ok) return;
    }

    buttons.forEach((b) => { b.disabled = true; });
    progressEl.hidden = false;

    const total = targets.length + 1;
    let done = 0;
    let failed = 0;
    const tick = () => {
      fillEl.style.transform = `scaleX(${total ? done / total : 0})`;
      countEl.textContent = `${done}/${total}`;
    };
    tick();

    stepEl.textContent = `กำลังใช้โปรไฟล์ ${preset.name}…`;
    const pres = await applyChosenPreset(preset);
    if (pres.cancelled) {
      buttons.forEach((b) => { b.disabled = false; });
      progressEl.hidden = true;
      return;
    }
    if (!pres.ok) failed++;
    done++;
    tick();

    for (const t of targets) {
      stepEl.textContent = `กำลังเปิด: ${t.label}`;
      // a timer keeps the loop alive even when the window is minimised
      // (requestAnimationFrame stops firing in a hidden tab and would stall it)
      await new Promise((r) => setTimeout(r, 0));
      try {
        const res = await setTweak(t.id, true);
        if (!res.ok) failed++;
      } catch {
        failed++;
      }
      done++;
      tick();
      if (mode === 'step') await new Promise((r) => setTimeout(r, 240));
    }

    stepEl.textContent = failed
      ? `เสร็จแล้ว — ${failed} รายการเปิดไม่ได้`
      : 'เสร็จแล้ว — เปิดครบทุกตัว';
    buttons.forEach((b) => { b.disabled = false; });
    toast(
      failed ? `Quick Setup เสร็จ — ${failed} รายการเปิดไม่ได้` : 'Quick Setup เปิดทุกอย่างเรียบร้อย',
      failed ? 'warn' : 'success',
    );
    ctx.refresh();
  }

  root.querySelectorAll('[data-setup-run]').forEach((btn) => {
    btn.addEventListener('click', () => runSetup(btn.dataset.setupRun));
  });

  loadBackups();
  loadRegBackups();
  loadIniBackups();
}
