// ---------------------------------------------------------------
//  Runtime performance profile.
//
//  The UI used to blur every panel with backdrop-filter and animate
//  drop-shadows / box-shadows on top of a moving background. That is
//  what made scrolling and page changes stutter on laptops.
//
//  auto   - pick smooth on a capable machine, lite on a weak one
//  smooth - no blur, no shadow animation, only cheap transform loops
//  full   - every decorative effect (opt-in)
//
//  The choice lives in localStorage under "aki.perf". A short FPS
//  watchdog can still push the current session down to lite when the
//  machine cannot keep up, and animations pause while the window is
//  hidden.
// ---------------------------------------------------------------

const KEY = 'aki.perf';
const PREFS = ['auto', 'smooth', 'full'];
const root = document.documentElement;

let pref = readPref();
let resolved = 'smooth';
let watchdogStarted = false;
let watchdogDone = false;

function readPref() {
  try {
    const raw = localStorage.getItem(KEY);
    return PREFS.includes(raw) ? raw : 'auto';
  } catch {
    return 'auto';
  }
}

function weakDevice() {
  const cores = Number(navigator.hardwareConcurrency) || 8;
  const memory = Number(navigator.deviceMemory) || 8;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const saveData = !!(navigator.connection && navigator.connection.saveData);
  return reduced || saveData || cores <= 4 || memory <= 4;
}

function resolve() {
  if (pref === 'full') return 'full';
  if (pref === 'smooth') return 'smooth';
  return weakDevice() ? 'lite' : 'smooth';
}

function publish() {
  root.dataset.perf = resolved;
  root.dataset.perfPref = pref;
  document.dispatchEvent(new CustomEvent('aki:perf', { detail: { pref, resolved } }));
}

export function getPerfPref() {
  return pref;
}

export function getPerfResolved() {
  return resolved;
}

// mode: auto | smooth | full
export function setPerfPref(mode) {
  pref = PREFS.includes(mode) ? mode : 'auto';
  try {
    localStorage.setItem(KEY, pref);
  } catch {
    /* private mode - the session still works */
  }
  resolved = resolve();
  publish();
  return resolved;
}

export function perfLabel(mode = pref) {
  if (mode === 'full') return 'เอฟเฟกต์เต็ม';
  if (mode === 'auto') {
    if (resolved === 'lite') return 'อัตโนมัติ · ประหยัด';
    if (resolved === 'full') return 'อัตโนมัติ · เต็ม';
    return 'อัตโนมัติ · ลื่นไหล';
  }
  return 'ลื่นไหล';
}

// Watch the first few seconds of real use. A machine that cannot hold
// ~45fps drops to lite for this session; the stored preference stays.
function startWatchdog() {
  if (watchdogStarted || watchdogDone) return;
  if (pref !== 'auto' || resolved === 'lite') return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (!window.requestAnimationFrame || !window.performance) return;
  watchdogStarted = true;

  let frames = 0;
  let last = performance.now();
  const samples = [];

  const tick = (now) => {
    if (document.hidden) {
      // hidden windows are throttled by the browser - do not judge them
      frames = 0;
      last = now;
      requestAnimationFrame(tick);
      return;
    }

    frames++;
    if (now - last >= 1000) {
      samples.push((frames * 1000) / (now - last));
      frames = 0;
      last = now;

      if (samples.length >= 3) {
        watchdogDone = true;
        const sorted = samples.slice().sort((a, b) => a - b);
        const median = sorted[Math.floor(sorted.length / 2)];
        if (median < 45) {
          resolved = 'lite';
          publish();
        }
        return;
      }
    }
    requestAnimationFrame(tick);
  };

  // let the splash and the first page settle before measuring
  setTimeout(() => requestAnimationFrame(tick), 1600);
}

function onVisibility() {
  if (document.hidden) root.dataset.paused = '';
  else delete root.dataset.paused;
}

export function initPerf() {
  resolved = resolve();
  publish();

  document.addEventListener('visibilitychange', onVisibility);
  if (document.hidden) root.dataset.paused = '';

  // follow the OS "reduce motion" switch while the preference is auto
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const onMotion = () => {
    if (pref !== 'auto') return;
    resolved = resolve();
    publish();
  };
  if (motion.addEventListener) motion.addEventListener('change', onMotion);
  else if (motion.addListener) motion.addListener(onMotion);

  startWatchdog();
}
