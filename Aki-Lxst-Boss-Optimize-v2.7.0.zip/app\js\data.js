// Setting definitions, presets and demo data.
// Targets the file FiveM actually reads:
//   %APPDATA%\CitizenFX\gta5_settings.xml
// Keys are the real ones stored by the game — no invented options.

export const SECTIONS = ['graphics', 'video', 'audio', 'system'];

// Strips a value coming from the XML into the type the controls expect.
export function fromXml(field, raw) {
  if (field.valueType === 'bool') return ['true', '1'].includes(String(raw).toLowerCase()) ? 'true' : 'false';
  if (field.valueType === 'text') return String(raw);
  const n = Number(raw);
  return Number.isFinite(n) ? n : raw;
}

export const GROUPS = [
  {
    id: 'display',
    title: 'การแสดงผล',
    desc: 'ความละเอียด รีเฟรชเรต และโหมดหน้าต่าง',
    icon: 'monitor',
    fields: [
      { key: 'resolution', type: 'resolution', section: 'video', label: 'ความละเอียด', hint: 'เลือกให้ตรงกับสเปกจอ — ค่าเริ่มต้นที่แนะนำคือ 1920×1080' },
      { key: 'RefreshRate', type: 'number', section: 'video', valueType: 'num', min: 30, max: 360, step: 1, label: 'รีเฟรชเรต (Hz)', hint: 'ตั้งให้ตรงกับ Hz จริงของจอ เช่น 144' },
      { key: 'Windowed', type: 'select', section: 'video', valueType: 'num', label: 'โหมดหน้าต่าง', hint: 'Fullscreen ให้ FPS/input lag ดีที่สุด', options: [
        { value: 0, label: 'เต็มจอ (Fullscreen)' },
        { value: 1, label: 'หน้าต่าง (Windowed)' },
        { value: 2, label: 'ไร้ขอบ (Borderless)' },
      ] },
      { key: 'VSync', type: 'switch', section: 'video', valueType: 'num', label: 'VSync', hint: 'เปิดเพื่อลดภาพฉีก แต่เพิ่ม input lag' },
    ],
  },
  {
    id: 'quality',
    title: 'คุณภาพภาพ',
    desc: 'ตัวเลือกที่กินสเปกมากที่สุด ปรับแล้วเห็นผลกับ FPS ทันที',
    icon: 'sparkles',
    fields: [
      { key: 'ShadowQuality', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 3, step: 1, label: 'เงา (Shadows)', hint: 'กิน FPS อันดับต้น ๆ โดยเฉพาะในเมือง', labels: ['ปิด', 'ต่ำ', 'กลาง', 'สูง'] },
      { key: 'Shadow_SoftShadows', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'ความนุ่มของเงา', labels: ['คม', 'กลาง', 'นุ่ม'] },
      { key: 'ReflectionQuality', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 3, step: 1, label: 'เงาสะท้อน', labels: ['ปิด', 'ต่ำ', 'กลาง', 'สูง'] },
      { key: 'ReflectionMSAA', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'Reflection MSAA', labels: ['ปิด', 'กลาง', 'สูง'] },
      { key: 'SSAO', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'Ambient Occlusion (SSAO)', hint: 'เงาในมุมอับของวัตถุ', labels: ['ปิด', 'ปกติ', 'สูง'] },
      { key: 'PostFX', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 3, step: 1, label: 'Post FX', labels: ['ปิด', 'ต่ำ', 'กลาง', 'สูง'] },
      { key: 'MSAA', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 3, step: 1, label: 'MSAA', hint: 'Anti-aliasing — กิน VRAM', labels: ['ปิด', '2x', '4x', '8x'] },
      { key: 'AnisotropicFiltering', type: 'select', section: 'graphics', valueType: 'num', label: 'Anisotropic Filtering', hint: 'x16 แทบไม่กระทบ FPS แต่ภาพพื้นถนนคมขึ้นมาก', options: [
        { value: 0, label: 'ปิด' }, { value: 4, label: 'x4' }, { value: 8, label: 'x8' }, { value: 16, label: 'x16' },
      ] },
      { key: 'TextureQuality', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'คุณภาพพื้นผิว', hint: 'ใช้ VRAM — การ์ดจอ 6GB ขึ้นไปเล่นสูงได้', labels: ['ต่ำ', 'กลาง', 'สูง'] },
      { key: 'ParticleQuality', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'เอฟเฟกต์อนุภาค', labels: ['ต่ำ', 'กลาง', 'สูง'] },
      { key: 'WaterQuality', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'คุณภาพน้ำ', labels: ['ต่ำ', 'กลาง', 'สูง'] },
      { key: 'GrassQuality', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 3, step: 1, label: 'คุณภาพหญ้า', labels: ['ปิด', 'ต่ำ', 'กลาง', 'สูง'] },
      { key: 'Tessellation', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'Tessellation', labels: ['ปิด', 'กลาง', 'สูง'] },
      { key: 'ShaderQuality', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 2, step: 1, label: 'Shader Quality', labels: ['ต่ำ', 'กลาง', 'สูง'] },
    ],
  },
  {
    id: 'world',
    title: 'ระยะมองเห็นและความหนาแน่น',
    desc: 'ลดจำนวนคน/รถบนถนนและระยะโหลดวัตถุ',
    icon: 'cpu',
    fields: [
      { key: 'CityDensity', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'ความหนาแน่นเมือง', hint: 'คน/รถบนถนน — ลดช่วยได้มากตอนอยู่ในเมือง', percent: true },
      { key: 'PedVarietyMultiplier', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'ความหลากหลายของคน', percent: true },
      { key: 'VehicleVarietyMultiplier', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'ความหลากหลายของรถ', percent: true },
      { key: 'PedLodBias', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'รายละเอียดตัวละครระยะไกล', percent: true },
      { key: 'VehicleLodBias', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'รายละเอียดรถระยะไกล', percent: true },
      { key: 'LodScale', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'ระยะโหลดวัตถุ (LOD Scale)', hint: 'ต่ำ = ไกลน้อยลง แต่วัตถุโผล่ช้า (pop-in)', percent: true },
      { key: 'MotionBlurStrength', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'Motion Blur', percent: true },
    ],
  },
  {
    id: 'effects',
    title: 'เอฟเฟกต์',
    desc: 'เปิด/ปิดเอฟเฟกต์ภาพที่ไม่จำเป็น',
    icon: 'layers',
    fields: [
      { key: 'Lighting_FogVolumes', type: 'switch', section: 'graphics', valueType: 'bool', label: 'หมอกเชิงปริมาตร', hint: 'ปิดเพื่อเพิ่ม FPS ในพื้นที่หมอกหนา' },
      { key: 'DoF', type: 'switch', section: 'graphics', valueType: 'bool', label: 'Depth of Field', hint: 'เปิดแล้วภาพเบลอตามระยะโฟกัส' },
      { key: 'FXAA_Enabled', type: 'switch', section: 'graphics', valueType: 'bool', label: 'FXAA', hint: 'Anti-aliasing แบบเบา เกือบไม่กิน FPS' },
      { key: 'TXAA_Enabled', type: 'switch', section: 'graphics', valueType: 'bool', label: 'TXAA', hint: 'ภาพเนียนขึ้นแต่เบลอเล็กน้อย' },
      { key: 'Shadow_ParticleShadows', type: 'switch', section: 'graphics', valueType: 'bool', label: 'เงาของอนุภาค' },
      { key: 'Shadow_LongShadows', type: 'switch', section: 'graphics', valueType: 'bool', label: 'เงายาว (Long Shadows)' },
      { key: 'UltraShadows_Enabled', type: 'switch', section: 'graphics', valueType: 'bool', label: 'Ultra Shadows', hint: 'กินสเปกมาก เปิดเฉพาะเครื่องแรง' },
      { key: 'Reflection_MipBlur', type: 'switch', section: 'graphics', valueType: 'bool', label: 'Reflection Mip Blur' },
      { key: 'Shader_SSA', type: 'switch', section: 'graphics', valueType: 'bool', label: 'Shader SSA' },
      { key: 'HdStreamingInFlight', type: 'switch', section: 'graphics', valueType: 'bool', label: 'HD Streaming In Flight', hint: 'สตรีมพื้นผิวละเอียดระหว่างบิน (กินแบนด์วิดท์)' },
    ],
  },
  {
    id: 'advanced',
    title: 'ขั้นสูง (Advanced)',
    desc: 'คีย์ที่มีอยู่จริงใน gta5_settings.xml แต่ไม่ค่อยมีใครแตะ — ค่า 0 ในช่อง % มักหมายถึง "ให้เกมคำนวณเอง"',
    icon: 'sliders',
    fields: [
      { key: 'Shadow_Distance', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'ระยะเงา (Shadow Distance)', hint: 'ระยะที่เกมยังวาดเงา 1 = เต็ม ลดลงช่วยตอนอยู่ในเมืองหนาแน่น', percent: true },
      { key: 'Shadow_SplitZStart', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'จุดแบ่งเงา 1 (SplitZ Start)', hint: '0 = ให้เกมคำนวณอัตโนมัติ (ค่าที่เกมเขียนไว้เอง)', percent: true },
      { key: 'Shadow_SplitZEnd', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'จุดแบ่งเงา 2 (SplitZ End)', hint: 'ใช้คู่กับ SplitZ Start — ปล่อย 0 ถ้าไม่มั่นใจ', percent: true },
      { key: 'MaxLodScale', type: 'range', section: 'graphics', valueType: 'num', min: 0, max: 1, step: 0.05, label: 'เพดานระยะโหลด (Max LOD Scale)', hint: '0 = อัตโนมัติ ใช้เมื่ออยากจำกัดระยะโหลดสูงสุดเอง', percent: true },
      { key: 'MSAAFragments', type: 'select', section: 'graphics', valueType: 'num', label: 'MSAA Fragments', hint: 'จำนวน sample ต่อพิกเซล มีผลเมื่อ MSAA เปิดอยู่', options: [
        { value: 0, label: '0 (ปิด)' }, { value: 2, label: '2' }, { value: 4, label: '4' }, { value: 8, label: '8' },
      ] },
      { key: 'MSAAQuality', type: 'select', section: 'graphics', valueType: 'num', label: 'MSAA Quality', hint: 'คุณภาพของ MSAA — สูงขึ้นกิน VRAM มากขึ้น', options: [
        { value: 0, label: '0' }, { value: 1, label: '1' }, { value: 2, label: '2' },
      ] },
      { key: 'PauseOnFocusLoss', type: 'switch', section: 'video', valueType: 'num', label: 'หยุดเกมเมื่อสลับหน้าต่าง', hint: 'ปิดไว้ (0) = เกมเล่นต่อเบื้องหลัง เหมาะกับสลับไปดู Discord' },
      { key: 'Audio3d', type: 'switch', section: 'audio', valueType: 'bool', label: 'เสียง 3 มิติ (3D Audio)', hint: 'เปิดเพื่อได้ยินทิศทางเสียงรอบตัว' },
    ],
  },
];

export const ALL_FIELDS = GROUPS.flatMap((g) => g.fields);
export const FIELD_BY_KEY = Object.fromEntries(ALL_FIELDS.map((f) => [f.key, f]));

// Video defaults are intentionally excluded from presets — a preset should
// never change the player's resolution or monitor refresh rate.
const FULL = { Windowed: 2, VSync: 0 };

export const PRESETS = [
  {
    id: 'midas',
    name: 'Boss Boost',
    tagline: 'แนะนำ • ลื่นสุด',
    desc: 'ค่าที่แนะนำสำหรับ FiveM: ลดตัวกิน FPS แต่คง Texture สูงและ AF x16 ให้ภาพยังคม',
    icon: 'zap',
    featured: true,
    values: {
      ...FULL,
      ShadowQuality: 0, Shadow_SoftShadows: 0, ReflectionQuality: 0, ReflectionMSAA: 0,
      SSAO: 0, PostFX: 0, MSAA: 0, AnisotropicFiltering: 16, TextureQuality: 2,
      ParticleQuality: 0, WaterQuality: 0, GrassQuality: 0, Tessellation: 0, ShaderQuality: 2,
      CityDensity: 0, PedVarietyMultiplier: 0, VehicleVarietyMultiplier: 0,
      PedLodBias: 0.2, VehicleLodBias: 0, LodScale: 0.3, MotionBlurStrength: 0,
      Lighting_FogVolumes: 'false', DoF: 'false', FXAA_Enabled: 'false', TXAA_Enabled: 'false',
      Shadow_ParticleShadows: 'false', Shadow_LongShadows: 'false', UltraShadows_Enabled: 'false',
      Reflection_MipBlur: 'true', Shader_SSA: 'false', HdStreamingInFlight: 'false',
      Shadow_Distance: 1, Shadow_SplitZStart: 0, Shadow_SplitZEnd: 0, MaxLodScale: 0,
      MSAAFragments: 0, MSAAQuality: 0, PauseOnFocusLoss: 0, Audio3d: 'false',
    },
    bullets: ['ปิดเงา / เงาสะท้อน / หญ้า / อนุภาค', 'คงพื้นผิวสูง + AF x16 (ฟรี)', 'ลดคน/รถในเมือง 100%'],
  },
  {
    id: 'performance',
    name: 'Max FPS',
    tagline: 'FPS สูงสุด',
    desc: 'ลดทุกอย่างลงต่ำสุด เหมาะกับเครื่องสเปกกลางและ PvP',
    icon: 'power',
    values: {
      ...FULL,
      ShadowQuality: 0, Shadow_SoftShadows: 0, ReflectionQuality: 0, ReflectionMSAA: 0,
      SSAO: 0, PostFX: 0, MSAA: 0, AnisotropicFiltering: 0, TextureQuality: 1,
      ParticleQuality: 0, WaterQuality: 0, GrassQuality: 0, Tessellation: 0, ShaderQuality: 0,
      CityDensity: 0, PedVarietyMultiplier: 0.2, VehicleVarietyMultiplier: 0.2,
      PedLodBias: 0, VehicleLodBias: 0, LodScale: 0, MotionBlurStrength: 0,
      Lighting_FogVolumes: 'false', DoF: 'false', FXAA_Enabled: 'false', TXAA_Enabled: 'false',
      Shadow_ParticleShadows: 'false', Shadow_LongShadows: 'false', UltraShadows_Enabled: 'false',
      Reflection_MipBlur: 'false', Shader_SSA: 'false', HdStreamingInFlight: 'false',
      Shadow_Distance: 1, Shadow_SplitZStart: 0, Shadow_SplitZEnd: 0, MaxLodScale: 0,
      MSAAFragments: 0, MSAAQuality: 0, PauseOnFocusLoss: 0, Audio3d: 'false',
    },
    bullets: ['ปิดเอฟเฟกต์ทั้งหมด', 'พื้นผิวระดับกลาง (ประหยัด VRAM)', 'ระยะโหลดวัตถุต่ำสุด'],
  },
  {
    id: 'balanced',
    name: 'Daily Smooth',
    tagline: 'ลื่น • ภาพสวย',
    desc: 'ภาพยังสวย เล่นลื่น เหมาะกับการเล่น RP ทั่วไป',
    icon: 'shield',
    values: {
      ...FULL,
      ShadowQuality: 2, Shadow_SoftShadows: 1, ReflectionQuality: 1, ReflectionMSAA: 1,
      SSAO: 1, PostFX: 1, MSAA: 0, AnisotropicFiltering: 16, TextureQuality: 2,
      ParticleQuality: 1, WaterQuality: 1, GrassQuality: 1, Tessellation: 1, ShaderQuality: 2,
      CityDensity: 0.6, PedVarietyMultiplier: 0.6, VehicleVarietyMultiplier: 0.6,
      PedLodBias: 0.5, VehicleLodBias: 0.5, LodScale: 0.7, MotionBlurStrength: 0,
      Lighting_FogVolumes: 'true', DoF: 'false', FXAA_Enabled: 'true', TXAA_Enabled: 'false',
      Shadow_ParticleShadows: 'true', Shadow_LongShadows: 'false', UltraShadows_Enabled: 'false',
      Reflection_MipBlur: 'true', Shader_SSA: 'true', HdStreamingInFlight: 'false',
      Shadow_Distance: 1, Shadow_SplitZStart: 0, Shadow_SplitZEnd: 0, MaxLodScale: 0,
      MSAAFragments: 0, MSAAQuality: 0, PauseOnFocusLoss: 0, Audio3d: 'true',
    },
    bullets: ['เงาระดับกลาง', 'พื้นผิวสูง + AF x16', 'ปิด Motion Blur / DoF'],
  },
  {
    id: 'cinematic',
    name: 'Ultra Visual',
    tagline: 'ภาพสวยสุด',
    desc: 'เปิดทุกเอฟเฟกต์ เหมาะกับเล่นคนเดียวหรือถ่ายคลิป',
    icon: 'sparkles',
    values: {
      ...FULL,
      ShadowQuality: 3, Shadow_SoftShadows: 2, ReflectionQuality: 3, ReflectionMSAA: 2,
      SSAO: 2, PostFX: 3, MSAA: 2, AnisotropicFiltering: 16, TextureQuality: 2,
      ParticleQuality: 2, WaterQuality: 2, GrassQuality: 3, Tessellation: 2, ShaderQuality: 2,
      CityDensity: 1, PedVarietyMultiplier: 1, VehicleVarietyMultiplier: 1,
      PedLodBias: 1, VehicleLodBias: 1, LodScale: 1, MotionBlurStrength: 0.3,
      Lighting_FogVolumes: 'true', DoF: 'true', FXAA_Enabled: 'true', TXAA_Enabled: 'false',
      Shadow_ParticleShadows: 'true', Shadow_LongShadows: 'true', UltraShadows_Enabled: 'true',
      Reflection_MipBlur: 'true', Shader_SSA: 'true', HdStreamingInFlight: 'true',
      Shadow_Distance: 1, Shadow_SplitZStart: 0, Shadow_SplitZEnd: 0, MaxLodScale: 0,
      MSAAFragments: 4, MSAAQuality: 2, PauseOnFocusLoss: 0, Audio3d: 'true',
    },
    bullets: ['เงาและพื้นผิวสูงสุด', 'เปิด DOF + Motion Blur', 'ระยะมองเห็นเต็ม 100%'],
  },
];

export const DEFAULT_VALUES = {
  ...PRESETS[2].values,
  // Used only when FiveM has not created a settings file yet. Live values
  // always replace these through valuesFromSettings().
  ScreenWidth: 1920,
  ScreenHeight: 1080,
  RefreshRate: 60,
};

export const RESOLUTIONS = ['1280x720', '1366x768', '1600x900', '1920x1080', '2560x1440', '3440x1440', '3840x2160'];

export function resolutionOf(values) {
  return `${values.ScreenWidth || 1920}x${values.ScreenHeight || 1080}`;
}

export function parseResolution(text) {
  const [w, h] = String(text || '1920x1080').split('x').map((n) => parseInt(n, 10) || 0);
  return { ScreenWidth: w || 1920, ScreenHeight: h || 1080 };
}

// Shown in demo mode (or merged with the live /api/tweaks response) so the
// page can render even when the backend is unreachable.
export const TWEAK_CATALOG = [
  { id: 'disableNagle', cat: 'network', tier: 'caution', admin: true, label: "ปิด Nagle's Algorithm", desc: 'ค่าเก่าสำหรับ TCP ผลกับ FiveM ไม่แน่นอน — ใช้เพื่อทดสอบเองเท่านั้น' },
  { id: 'networkAdapterPowerSaving', cat: 'network', tier: 'caution', admin: true, label: 'กันการ์ดเน็ตหลับ', desc: 'ห้าม Windows สั่งการ์ดเครือข่ายปิดเพื่อประหยัดไฟ' },
  { id: 'nicPowerSavingAdvanced', cat: 'network', tier: 'caution', admin: true, label: 'ปิดประหยัดไฟการ์ดเน็ตทั้งหมด', desc: 'ปิด Selective Suspend / EEE / idle gating / wake-on-LAN ทั้งหมด' },
  { id: 'disableAutoDisconnect', cat: 'network', tier: 'caution', admin: true, label: 'ปิดการตัดเซสชันอัตโนมัติ', desc: 'เกี่ยวกับ Windows file sharing ไม่ใช่ ping ของ FiveM' },
  { id: 'disableDeliveryOptimization', cat: 'network', tier: 'safe', admin: true, label: 'ปิด Delivery Optimization', desc: 'หยุด Windows ใช้แบนด์วิดท์อัปโหลดอัปเดตให้เครื่องอื่นแบบ P2P' },
  { id: 'disableIPv6', cat: 'network', tier: 'caution', admin: true, reboot: true, label: 'ปิด IPv6', desc: 'ไม่แนะนำ — IPv6 ไม่ได้ทำให้ FiveM ช้า' },
  { id: 'optimizeNetworkPriorities', cat: 'network', tier: 'caution', admin: true, label: 'QoS policy limit tweak', desc: 'ไม่ได้เป็น FPS/ping boost ใน Windows รุ่นใหม่' },
  { id: 'disableInterruptModeration', cat: 'network', tier: 'caution', admin: true, label: 'ปิด Interrupt Moderation', desc: 'ให้ CPU ประมวลผลทุกแพ็กเก็ตทันที (การ์ดที่ไม่รองรับจะถูกข้าม)' },
  { id: 'disableAdapterNotifications', cat: 'network', tier: 'caution', label: 'ปิดการแจ้งเตือนเน็ตต่อ/หลุด', desc: 'ปิด toast ทั้งหมดของ Windows' },
  { id: 'networkThrottlingIndex', cat: 'system', tier: 'caution', admin: true, label: 'Network throttling registry tweak', desc: 'ค่าเก่าที่ผลกับ Windows/FiveM รุ่นใหม่ไม่แน่นอน' },
  { id: 'systemResponsiveness', cat: 'system', tier: 'caution', admin: true, label: 'MMCSS CPU registry tweak', desc: 'ไม่รับประกัน FPS และอาจกระทบงานเบื้องหลัง' },
  { id: 'optimizeMmcss', cat: 'system', tier: 'caution', admin: true, label: 'MMCSS Games priority', desc: 'ค่าขั้นสูง ผลจริงกับเกมส่วนใหญ่มีจำกัด' },
  { id: 'disablePowerThrottling', cat: 'system', tier: 'caution', admin: true, reboot: true, label: 'ปิด Power Throttling', desc: 'กระทบการใช้พลังงานของระบบ ต้องรีสตาร์ท' },
  { id: 'gameModeAndBar', cat: 'system', tier: 'safe', label: 'Game Mode ON + Capture OFF', desc: 'เปิด Game Mode และปิดการบันทึก Xbox Game Bar เบื้องหลัง' },
  { id: 'fivemDefenderExclusion', cat: 'system', tier: 'caution', admin: true, label: 'ยกเว้น FiveM จาก Defender', desc: 'ยกเว้นโฟลเดอร์ FiveM จากการสแกนของ Windows Defender' },
  { id: 'mouseAccelCurveLinear', cat: 'input', tier: 'caution', label: 'ปิด Mouse Acceleration', desc: 'ตั้งค่าเมาส์ตามความชอบ ไม่ได้เพิ่ม FPS' },
  { id: 'fivemProcessPriority', cat: 'input', tier: 'caution', admin: true, label: 'FiveM Process Priority: High', desc: 'อาจแย่ง CPU จาก Discord/driver' },
  { id: 'filterKeysTimingReset', cat: 'input', tier: 'caution', label: 'Reset Filter Keys Timing', desc: 'ตั้งค่าการเข้าถึงของ Windows ไม่ใช่ FPS tweak' },
  { id: 'disableFilterKeysFeature', cat: 'input', tier: 'caution', label: 'ปิด Filter Keys', desc: 'ปิดฟีเจอร์ช่วยการเข้าถึง Filter Keys' },
  { id: 'disableStickyKeysFeature', cat: 'input', tier: 'caution', label: 'ปิด Sticky Keys', desc: 'ปิดทางลัด Sticky Keys (Shift 5 ครั้ง)' },
  { id: 'disableToggleKeysFeature', cat: 'input', tier: 'caution', label: 'ปิด Toggle Keys', desc: 'ปิดเสียงเตือน Caps / Num / Scroll Lock' },
  { id: 'keyboardRepeatDelay', cat: 'input', tier: 'caution', label: 'ลดดีเลย์การกดปุ่มค้าง', desc: 'เปลี่ยนพฤติกรรมการพิมพ์ ไม่ใช่ FPS tweak' },
  { id: 'keyboardRepeatRate', cat: 'input', tier: 'caution', label: 'เพิ่มความเร็วการรัวปุ่ม', desc: 'เปลี่ยนพฤติกรรมการพิมพ์ ไม่ใช่ FPS tweak' },
  { id: 'hags', cat: 'system', tier: 'caution', admin: true, reboot: true, label: 'Hardware GPU Scheduling (HAGS)', desc: 'HwSchMode = 2 — ใช้ตัวจัดคิวงานของการ์ดจอ ต้องรีบูต' },
  { id: 'win32PrioritySeparation', cat: 'system', tier: 'caution', admin: true, label: 'Win32PrioritySeparation = 0x26', desc: 'foreground (เกม) ได้ CPU quantum ยาวขึ้น ผลจริงจำกัด' },
  { id: 'disablePagingExecutive', cat: 'system', tier: 'caution', admin: true, reboot: true, label: 'Disable Paging Executive', desc: 'เคอร์เนลอยู่ใน RAM เสมอ — แรมน้อยกว่า 16GB อย่าเปิด' },
  { id: 'ultimatePowerPlan', cat: 'system', tier: 'caution', admin: true, label: 'Ultimate Performance Power Plan', desc: 'ลด CPU wake latency — เหมาะกับเดสก์ท็อป โน้ตบุ๊กเปลืองแบต' },
  { id: 'xboxGameDvrPolicy', cat: 'system', tier: 'caution', admin: true, label: 'Xbox Game DVR (policy): ปิดจับภาพ', desc: 'AllowGameDVR = 0 ระดับ policy ชัดกว่าค่า HKCU' },
  { id: 'mouseKeyboardQueue', cat: 'input', tier: 'caution', admin: true, label: 'ลด Input Queue (Mouse/Keyboard)', desc: 'QueueSize = 16 ช่วยตอน mouse polling สูง กลับเป็น 100 ได้' },
  { id: 'uiResponsiveness', cat: 'input', tier: 'caution', label: 'UI: Foreground Lock / Menu Delay = 0', desc: 'ไม่บังคับขอโฟกัส เมนูเด้งทันที — เรื่องความรู้สึก' },
  { id: 'fivemDscpQoS', cat: 'network', tier: 'caution', admin: true, reboot: true, label: 'DSCP 46 Priority Marking (FiveM)', desc: 'mark แพ็กเก็ต EF ให้ router ที่รองรับ — ไม่เพิ่มความเร็ว' },
  { id: 'fivemWaitableSwapchain', cat: 'fivem', tier: 'caution', label: 'Waitable SwapChain (ลด input lag)', desc: 'CitizenFX.ini [Renderer] SwapChainUseWaitableSwapChain=true' },
  { id: 'fivemForceRenderAhead', cat: 'fivem', tier: 'caution', label: 'Render Ahead Limit = 1', desc: 'CitizenFX.ini [Renderer] ForceRenderAheadLimit=1 — ถ้ากระตุกให้ลบออก' },
  { id: 'fivemDisableNagle', cat: 'fivem', tier: 'caution', label: 'FiveM: ปิด Nagle ในเกม', desc: 'CitizenFX.ini [Game] DisableNagleAlgorithm=1 — เฉพาะ traffic เกม' },
  { id: 'fivemHighPriority', cat: 'fivem', tier: 'caution', label: 'FiveM: High Priority ในตัวเกม', desc: 'CitizenFX.ini [Game] HighPriority=1 — ซ้ำซ้อนกับ IFEO priority' },
  { id: 'fivemUseDirectInput', cat: 'fivem', tier: 'caution', label: 'Use DirectInput (จอยรุ่นเก่า)', desc: 'CitizenFX.ini [Game] UseDirectInput=1 — จอย XInput ไม่ต้องเปิด' },
  { id: 'fivemPresentationOptimizations', cat: 'fivem', tier: 'caution', label: 'Presentation Optimizations', desc: 'CitizenFX.ini [Renderer] EnablePresentationOptimizations=true — ลด overhead ของ renderer' },
  { id: 'fivemNvThreadOptimization', cat: 'fivem', tier: 'caution', label: 'ปิด NVIDIA Thread Optimization', desc: 'CitizenFX.ini [Game] DisableNvThreadOptimization=1 — เฉพาะการ์ด NVIDIA' },
  { id: 'tcpFastOpen', cat: 'network', tier: 'caution', admin: true, label: 'TCP Fast Open', desc: 'netsh tcp fastopen=enabled + fallback — ลด RTT ตอนเปิด connection ใหม่' },
  { id: 'tcpLowLatencyProfile', cat: 'network', tier: 'caution', admin: true, label: 'TCP Low-Latency Profile', desc: 'ปิด timestamps/ECN, initialRto 1500, syn retry 2 — ลดเวลารอเมื่อเน็ตหลุด' },
  { id: 'udpReceiveOffload', cat: 'network', tier: 'caution', admin: true, label: 'UDP Receive Offload (URO)', desc: 'netsh int udp uro=enabled — ให้การ์ดรวมแพ็กเก็ต UDP ก่อนส่งให้ CPU' },
  { id: 'qosReservedBandwidth', cat: 'network', tier: 'caution', admin: true, label: 'ปลดล็อก Reserved Bandwidth 20%', desc: 'Psched NonBestEffortLimit = 0 — ผลกับเกมแทบไม่มี แต่ปิดกลับได้' },
];

export const MOCK_STATUS = {
  ok: true,
  demo: true,
  app: 'Aki Lxst Boss Optimize',
  version: '2.7.0',
  port: 5180,
  os: 'Windows 11 (demo mode)',
  machine: 'AKI-DESKTOP',
  user: 'aki',
  admin: true,
  fivemRunning: false,
  paths: {
    fivemHome: 'C:\\Users\\aki\\AppData\\Local\\FiveM',
    fivemApp: 'C:\\Users\\aki\\AppData\\Local\\FiveM\\FiveM.app',
    citizenIni: 'C:\\Users\\aki\\AppData\\Local\\FiveM\\FiveM.app\\CitizenFX.ini',
    gta: 'C:\\Program Files\\Rockstar Games\\Grand Theft Auto V',
    settings: 'C:\\Users\\aki\\AppData\\Roaming\\CitizenFX\\gta5_settings.xml',
    backups: 'C:\\Users\\aki\\AppData\\Local\\AkiLxstboss\\backups',
    regbackups: 'C:\\Users\\aki\\AppData\\Local\\AkiLxstboss\\regbackups',
    iniBackups: 'C:\\Users\\aki\\AppData\\Local\\AkiLxstboss\\citizenfx-backups',
  },
  fivem: {
    installed: true,
    exists: true,
    dir: 'C:\\Users\\aki\\AppData\\Local\\FiveM\\FiveM.app',
    exe: 'C:\\Users\\aki\\AppData\\Local\\FiveM\\FiveM.exe',
  },
  gta: {
    found: true,
    dir: 'C:\\Program Files\\Rockstar Games\\Grand Theft Auto V',
    settings: 'C:\\Users\\aki\\AppData\\Roaming\\CitizenFX\\gta5_settings.xml',
  },
  cache: { cacheMB: 842.6, serverCacheMB: 365.2, nuiMB: 48.9, logsMB: 18.4, totalMB: 1275.1 },
};

export const MOCK_SPECS = {
  ok: true,
  cpu: 'AMD Ryzen 7 9800X3D',
  gpu: 'NVIDIA GeForce RTX 3060',
  ram: '32 GB',
  os: 'Windows 11 Pro',
};

export const MOCK_BACKUPS = [
  { name: 'settings-20261112-214512-441.xml', sizeKB: 2.4, date: '2026-11-12 21:45:12' },
  { name: 'settings-20261108-190233-118.xml', sizeKB: 2.4, date: '2026-11-08 19:02:33' },
];

export const MOCK_REG_BACKUPS = [
  { name: 'disableNagle-20261112-215502-010.reg', sizeKB: 0.4, date: '2026-11-12 21:55:02' },
];

export const MOCK_INI_BACKUPS = [
  { name: 'fivemWaitableSwapchain-20261112-220102-310.ini', sizeKB: 0.2, date: '2026-11-12 22:01:02' },
];

export const MOCK_QOS = {
  ok: true,
  admin: true,
  active: true,
  count: 17,
  rateBps: 2000000,
  rateMbps: 2,
  nlaEnabled: true,
  policies: [{ name: 'GameOpt_FiveM_exe' }, { name: 'GameOpt_Port_30120' }],
};

export const QOS_RATES = [
  { value: 0.4, label: '0.4 Mbps' },
  { value: 0.5, label: '0.5 Mbps' },
  { value: 1, label: '1 Mbps' },
  { value: 2, label: '2 Mbps' },
  { value: 5, label: '5 Mbps' },
  { value: 10, label: '10 Mbps' },
];
