import { getQos, getSettings, getSpecs, getStatus, getTweaks, isDemo } from './api.js';
import { icon } from './icons.js';
import { initPerf } from './perf.js';
import { setState, state, valuesFromSettings } from './store.js';
import { spinner, toast } from './ui.js';

import dashboard from './pages/dashboard.js';
import graphics from './pages/graphics.js';
import profiles from './pages/profiles.js';
import tweaks from './pages/tweaks.js';
import performance from './pages/performance.js';
import network from './pages/network.js';
import settings from './pages/settings.js';

const ROUTES = [
  { id: 'dashboard', label: 'Home', sub: 'ภาพรวมระบบและทางลัด', icon: 'grid' },
  { id: 'graphics', label: 'Graphics', sub: 'ปรับภาพ FiveM ใน gta5_settings.xml', icon: 'sliders' },
  { id: 'profiles', label: 'Profiles', sub: 'เลือกชุดค่าพร้อมใช้ตามสเปกเครื่อง', icon: 'layers' },
  { id: 'tweaks', label: 'Optimize', sub: 'ปรับ Windows, เน็ต และการตอบสนองของเกม', icon: 'zap' },
  { id: 'performance', label: 'Clean Up', sub: 'ล้างแคชและคืนพื้นที่ดิสก์', icon: 'broom' },
  { id: 'network', label: 'Network', sub: 'Bandwidth Cap, DNS และเชื่อมต่อเซิร์ฟเวอร์', icon: 'globe' },
  { id: 'settings', label: 'Settings', sub: 'พาธ ไฟล์สำรอง และข้อมูลแอป', icon: 'settings' },
];

const PAGES = { dashboard, graphics, profiles, tweaks, performance, network, settings };

const app = document.getElementById('app');
let currentRoute = 'dashboard';

// Pick the render profile before the shell is injected so the first paint
// already uses the right amount of effects.
initPerf();

/* ------------------------------ splash ------------------------------ */

const splash = document.getElementById('splash');
const splashAt = Date.now();
const SPLASH_MIN_MS = 900;

function hideSplash() {
  if (!splash || splash.classList.contains('is-out')) return;
  const wait = Math.max(0, SPLASH_MIN_MS - (Date.now() - splashAt));
  setTimeout(() => {
    splash.classList.add('is-out');
    setTimeout(() => splash.remove(), 560);
  }, wait);
}

// if a request hangs the splash still lifts instead of trapping the user
setTimeout(hideSplash, 6000);

app.innerHTML = `
  <div class="bg-fx" aria-hidden="true">
    <div class="bg-fx-art"></div>
    <div class="bg-fx-orbit"></div>
    <div class="bg-fx-grid"></div>
    <div class="bg-fx-scan"></div>
    <div class="bg-fx-glow"></div>
  </div>

  <aside class="sidebar">
    <a class="brand-mark" href="#/dashboard" title="Aki Lxst Boss Optimize">
      <img class="brand-logo" src="./assets/aki-logo.png" alt="" />
    </a>
    <nav class="nav" id="nav"></nav>
    <div class="sb-spacer"></div>
    <div class="sb-vertical">AKI LXSTBOSS</div>
    <div class="sb-foot">
      <span class="status-dot" id="side-dot"></span>
      <span class="sb-foot-text" id="side-status">ตรวจสอบ…</span>
    </div>
  </aside>

  <main class="main">
    <header class="topbar">
      <div class="topbar-left">
        <h1 class="page-title" id="page-title">แดชบอร์ด</h1>
        <p class="page-sub" id="page-sub">ภาพรวมระบบและทางลัด</p>
      </div>
      <div class="topbar-actions">
        <span class="status-pill" id="mode-chip"><span class="dot"></span>กำลังโหลด</span>
        <button class="icon-btn" id="btn-refresh" type="button" title="รีเฟรชข้อมูล">
          ${icon('refresh')}
        </button>
      </div>
    </header>
    <div class="content" id="view"></div>
  </main>`;

const nav = document.getElementById('nav');
const view = document.getElementById('view');
const titleEl = document.getElementById('page-title');
const subEl = document.getElementById('page-sub');
const modeChip = document.getElementById('mode-chip');
const sideStatus = document.getElementById('side-status');
const sideDot = document.getElementById('side-dot');

nav.innerHTML = ROUTES.map((route) => `
  <a class="nav-item" data-route="${route.id}" href="#/${route.id}" title="${route.label}">
    ${icon(route.icon)}<span class="nav-tip">${route.label}</span>
  </a>`).join('');

function readRoute() {
  const raw = (location.hash || '').replace(/^#\/?/, '').split('?')[0];
  return PAGES[raw] ? raw : 'dashboard';
}

function updateChrome() {
  const s = state.status;
  const demo = isDemo();

  if (!s) {
    modeChip.className = 'status-pill';
    modeChip.innerHTML = `<span class="dot"></span>กำลังโหลด`;
    return;
  }

  if (demo) {
    modeChip.className = 'status-pill warn';
    modeChip.innerHTML = `<span class="dot"></span>โหมดตัวอย่าง`;
    sideDot.className = 'status-dot warn';
    sideStatus.textContent = 'ไม่ต่อ backend';
    return;
  }

  if (s.fivemRunning) {
    modeChip.className = 'status-pill warn';
    modeChip.innerHTML = `<span class="dot"></span>FiveM กำลังรัน`;
    sideDot.className = 'status-dot warn';
    sideStatus.textContent = 'เกมเปิดอยู่';
    return;
  }

  const ok = !!(s.fivem && s.fivem.installed);
  modeChip.className = `status-pill ${ok ? 'ok' : 'warn'}`;
  modeChip.innerHTML = `<span class="dot"></span>${ok ? 'SYSTEM READY' : 'ไม่พบ FiveM'}`;
  sideDot.className = `status-dot ${ok ? 'ok' : 'warn'}`;
  sideStatus.textContent = ok ? 'พร้อมใช้งาน' : 'ไม่พบ FiveM';
}

function paint() {
  currentRoute = readRoute();
  const meta = ROUTES.find((r) => r.id === currentRoute) || ROUTES[0];
  titleEl.textContent = meta.label;
  subEl.textContent = meta.sub;

  nav.querySelectorAll('.nav-item').forEach((a) => {
    a.classList.toggle('active', a.dataset.route === currentRoute);
  });

  // restart the entry animation without a forced synchronous reflow:
  // the class comes off now and goes back on in the next frame
  view.classList.remove('page-enter');
  PAGES[currentRoute](view, { rerender: render, refresh: boot, navigate: go });
  requestAnimationFrame(() => view.classList.add('page-enter'));
}

// Batch route changes and rerender requests into one browser frame so a
// burst of events cannot mount the same page several times.
let renderQueued = false;

function render() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => {
    renderQueued = false;
    paint();
  });
}

export function go(route) {
  if (readRoute() === route) {
    render();
  } else {
    location.hash = `#/${route}`;
  }
}

let refreshing = false;

async function boot() {
  const refreshBtn = document.getElementById('btn-refresh');
  if (refreshing) return;
  refreshing = true;
  refreshBtn.disabled = true;

  if (!state.ready) {
    view.innerHTML = spinner('กำลังตรวจสอบระบบ…');
  }

  try {
    const [status, settingsData, specs, tweaksData, qos] = await Promise.all([
      getStatus(),
      getSettings(),
      getSpecs(),
      getTweaks(),
      getQos(),
    ]);

    const values = valuesFromSettings(settingsData);
    setState({
      status,
      specs,
      values,
      saved: { ...values },
      settingsPath: settingsData.path || (status.paths && status.paths.settings) || '',
      tweaks: tweaksData.items || [],
      tweaksAdmin: !!tweaksData.admin,
      qos,
      demo: isDemo(),
      ready: true,
    });
    updateChrome();
    render();
    const splashStatus = document.getElementById('splash-status');
    if (splashStatus) splashStatus.textContent = 'พร้อมใช้งาน';
  } catch (err) {
    toast('โหลดข้อมูลไม่สำเร็จ: ' + (err.message || err), 'error');
    const splashStatus = document.getElementById('splash-status');
    if (splashStatus) splashStatus.textContent = 'โหมดจำกัด — ข้อมูลบางส่วนไม่พร้อม';
  } finally {
    refreshing = false;
    refreshBtn.disabled = false;
    hideSplash();
  }
}

document.getElementById('btn-refresh').addEventListener('click', () => {
  toast('กำลังรีเฟรชข้อมูลระบบ…', 'info', 1500);
  boot();
});

window.addEventListener('hashchange', render);

boot();
