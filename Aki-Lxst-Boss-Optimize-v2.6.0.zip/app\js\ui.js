// Small UI helpers: DOM building, toasts, confirm modal, formatting.
import { icon } from './icons.js';

const toastRoot = () => document.getElementById('toasts');

export function toast(message, kind = 'info', duration = 3600) {
  const root = toastRoot();
  if (!root) return;
  const map = { success: 'check', error: 'alert', info: 'info', warn: 'alert' };
  const node = document.createElement('div');
  node.className = `toast toast-${kind}`;
  node.innerHTML = `<span class="toast-ico">${icon(map[kind] || 'info')}</span><span>${escapeHtml(message)}</span>`;
  root.appendChild(node);
  setTimeout(() => {
    node.classList.add('toast-out');
    setTimeout(() => node.remove(), 220);
  }, duration);
}

export function confirmDialog({ title, text, confirmText = 'ยืนยัน', cancelText = 'ยกเลิก', danger = false }) {
  return new Promise((resolve) => {
    const root = document.getElementById('modal-root');
    root.innerHTML = `
      <div class="modal-backdrop">
        <div class="modal" role="dialog" aria-modal="true">
          <div class="modal-head">
            <h3>${escapeHtml(title)}</h3>
            <p>${escapeHtml(text || '')}</p>
          </div>
          <div class="modal-foot">
            <button class="btn btn-outline" data-act="cancel">${escapeHtml(cancelText)}</button>
            <button class="btn ${danger ? 'btn-danger-solid' : 'btn-primary'}" data-act="ok">${escapeHtml(confirmText)}</button>
          </div>
        </div>
      </div>`;
    const close = (value) => {
      root.innerHTML = '';
      document.removeEventListener('keydown', onKey);
      resolve(value);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') close(false);
      if (e.key === 'Enter') close(true);
    };
    document.addEventListener('keydown', onKey);
    root.querySelector('.modal-backdrop').addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-backdrop')) close(false);
    });
    root.querySelector('[data-act="cancel"]').addEventListener('click', () => close(false));
    root.querySelector('[data-act="ok"]').addEventListener('click', () => close(true));
  });
}

export function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function fmtMB(mb) {
  const n = Number(mb) || 0;
  if (n >= 1024) return `${(n / 1024).toFixed(2)} GB`;
  if (n >= 100) return `${Math.round(n)} MB`;
  return `${n.toFixed(n < 10 ? 1 : 0)} MB`;
}

export function shortPath(p, max = 46) {
  if (!p) return '—';
  return p.length > max ? `${p.slice(0, 14)}…${p.slice(-(max - 15))}` : p;
}

export function rangeFill(input) {
  const min = Number(input.min) || 0;
  const max = Number(input.max) || 100;
  const val = Number(input.value) || 0;
  const pct = ((val - min) / (max - min)) * 100;
  input.style.setProperty('--fill', `${Math.max(0, Math.min(100, pct))}%`);
}

export function spinner(label = 'กำลังโหลด…') {
  return `<div class="loading"><span class="spinner"></span><span>${escapeHtml(label)}</span></div>`;
}

export function emptyState(iconName, title, text) {
  return `<div class="empty">${icon(iconName, 'empty-ico')}<div class="empty-title">${escapeHtml(title)}</div><div class="empty-text">${escapeHtml(text)}</div></div>`;
}
