@echo off
title Aki Lxst Boss Optimize - stop server
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0AkiBossMap.ps1" -Stop
echo.
timeout /t 2 >nul
