@echo off
title Aki Lxst Boss Optimize
cd /d "%~dp0"

echo.
echo   ============================================================
echo     Aki Lxst Boss Optimize  -  FiveM settings and tweaks
echo   ============================================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo   [i] Running WITHOUT Administrator.
  echo       Home / Graphics / Profiles / Clean Up work normally.
  echo       For Optimize and Network features, right-click
  echo       "run-admin.bat" and choose "Run as administrator".
  echo.
) else (
  echo   [+] Administrator mode - every feature is unlocked.
  echo.
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"

echo.
echo   Server stopped. You can close this window.
pause
