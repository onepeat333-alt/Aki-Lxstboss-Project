import { icon } from '../icons.js';
import { doAction } from '../actions.js';
import { currentPresetId, state, timeAgo, clearActivity } from '../store.js';
import { PRESETS } from '../data.js';
import { escapeHtml, fmtMB, shortPath } from '../ui.js';

function kv(label, value, tone = '') {
  return `<div class="kv"><span class="kv-label">${escapeHtml(label)}</span>
    <span class="kv-value ${tone}">${escapeHtml(value || '—')}</span></div>`;
}

function pathRow(label, path, target) {
  return `<div class="kv">
    <span class="kv-label">${escapeHtml(label)}</span>
    <span class="kv-path">
      <code title="${escapeHtml(path || '')}">${escapeHtml(shortPath(path, 50))}</code>
      <button class="icon-btn" data-act="open" data-target="${target}" title="เปิดโฟลเดอร์">${icon('folder')}</button>
    </span>
  </div>`;
}

function tile(iconName, name, desc, act, extra = '') {
  return `<button class="action" data-act="${act}" ${extra}>
    <span class="action-icon">${icon(iconName)}</span>
    <span class="action-text"><span class="action-name">${escapeHtml(name)}</span>
      <span class="action-desc">${escapeHtml(desc)}</span></span>
    ${icon('chevron', 'action-chev')}
  </button>`;
}

function specRow(iconName, label, value) {
  return `<div class="spec-row">
    <span class="sr-icon">${icon(iconName)}</span>
    <span class="sr-text"><span class="sr-k">${escapeHtml(label)}</span>
    <span class="sr-v">${escapeHtml(value || '—')}</span></span>
  </div>`;
}

export default function mount(root, ctx) {
  const s = state.status || {};
  const cache = s.cache || {};
  const specs = state.specs || {};
  const qos = state.qos || {};
  const preset = PRESETS.find((p) => p.id === currentPresetId()) || PRESETS[0];
  const fivemOk = !!(s.fivem && s.fivem.installed);
  const activity = state.activity.slice(0, 6);
  const tweaksOn = (state.tweaks || []).filter((t) => t.enabled === true).length;

  root.innerHTML = `
    <div class="stack">
      ${state.demo ? `<div class="callout warn">
        ${icon('info')}
        <div><strong>โหมดตัวอย่าง</strong> — ยังไม่เชื่อมต่อ backend ของแอป ข้อมูลที่เห็นเป็นข้อมูลจำลอง
        กด <b>รีเฟรช</b> หลังเปิดผ่าน <code>run.bat</code> เพื่อดึงข้อมูลจริง</div>
      </div>` : ''}

      ${!state.demo && !fivemOk ? `<div class="callout info">
        ${icon('info')}
        <div><strong>ยังไม่พบ FiveM บนเครื่องนี้</strong> — ถ้าเพิ่งติดตั้ง FiveM หรืออยู่ในโฟลเดอร์อื่น
        ให้ไปที่ <a href="#/settings">Settings</a> เพื่อระบุตำแหน่งโฟลเดอร์เกม ส่วนหน้ากราฟิก/โปรไฟล์ยังใช้ได้ตามปกติ</div>
      </div>` : ''}

      <div class="grid-2">
        <section class="hero-card">
          <div class="hero-echo"></div>
          <div class="hero-art" aria-hidden="true"></div>
          <div class="hero-horizon" aria-hidden="true"></div>
          <div class="hero-orbit" aria-hidden="true"><img src="./assets/aki-orbit.svg" alt="" /></div>
          <span class="hero-scan" aria-hidden="true"></span>
          <div class="hero-top">
            <span class="hero-mark"><span class="hero-diamond"></span></span>
            <div class="hero-id">
              <div class="hero-kicker">FIVEM OPTIMIZER</div>
              <h2 class="hero-name">Aki Lxst Boss <b>Optimize</b></h2>
              <p class="hero-sub">ปรับภาพและ Windows ให้ FiveM ลื่นขึ้น พร้อมเครื่องมือเน็ตที่อธิบายตามจริง</p>
            </div>
            <span class="status-pill ${fivemOk ? 'ok' : 'warn'}">
              <span class="dot"></span>${fivemOk ? 'READY' : 'NO GAME'}
            </span>
          </div>

          <div class="stats-row">
            <div class="stat-mini">
              <span class="v">${escapeHtml(preset.name)}</span>
              <span class="l">โปรไฟล์ภาพ</span>
            </div>
            <div class="stat-mini">
              <span class="v">${tweaksOn}</span>
              <span class="l">Optimize เปิดอยู่</span>
            </div>
            <div class="stat-mini">
              <span class="v">${qos.active ? `${qos.rateMbps || '?'} Mbps` : '—'}</span>
              <span class="l">Bandwidth Cap</span>
            </div>
            <div class="stat-mini">
              <span class="v">${fmtMB(cache.totalMB)}</span>
              <span class="l">แคชบนดิสก์</span>
            </div>
          </div>

          <div class="hero-actions">
            <button class="btn btn-primary" data-act="launch" ${fivemOk ? '' : 'disabled'}>
              ${icon('play')} เปิด FiveM
            </button>
            <button class="btn btn-outline" data-act="goto" data-to="profiles">
              ${icon('layers')} เปลี่ยนโปรไฟล์
            </button>
            <button class="btn btn-ghost" data-act="open" data-target="settings">
              ${icon('folder')} ไฟล์ตั้งค่า
            </button>
          </div>
        </section>

        <section class="card spec-card">
          <div class="card-head">
            <div>
              <h2 class="card-title">สเปกเครื่องนี้</h2>
              <p class="card-desc">ตรวจพบอัตโนมัติจากระบบ</p>
            </div>
            <span class="chip info">${icon('cpu')} HARDWARE</span>
          </div>
          <div class="card-body tight">
            ${specRow('cpu', 'CPU', specs.cpu)}
            ${specRow('sparkles', 'GPU', specs.gpu)}
            ${specRow('layers', 'RAM', specs.ram)}
            ${specRow('monitor', 'Windows', specs.os || s.os)}
          </div>
          <div class="card-foot">
            <span class="hint mono">${escapeHtml(s.machine || '—')}</span>
            <span class="chip ${s.admin ? 'ok' : 'warn'}">${icon('shield')} ${s.admin ? 'ADMIN' : 'USER'}</span>
          </div>
        </section>
      </div>

      <div class="grid-3">
        <div class="card kpi-card">
          <div class="kpi-head">
            <span class="kpi-label">สถานะ FiveM</span>
            <span class="chip ${fivemOk ? 'ok' : 'warn'}"><span class="dot"></span>${fivemOk ? 'ติดตั้งแล้ว' : 'ไม่พบ'}</span>
          </div>
          <div class="kpi-value">${fivemOk ? 'พร้อมเล่น' : 'ยังไม่ติดตั้ง'}</div>
          <div class="kpi-sub mono" title="${escapeHtml(s.fivem?.exe || '')}">${escapeHtml(shortPath(s.fivem?.exe || s.fivem?.dir || '—', 40))}</div>
          <div class="kpi-actions">
            <button class="btn btn-sm btn-outline" data-act="open" data-target="fivem">${icon('folder')} โฟลเดอร์</button>
            <button class="btn btn-sm btn-primary" data-act="launch" ${fivemOk ? '' : 'disabled'}>${icon('play')} เปิดเกม</button>
          </div>
        </div>

        <div class="card kpi-card">
          <div class="kpi-head">
            <span class="kpi-label">พื้นที่แคช</span>
            <span class="chip">${icon('harddrive')} บนดิสก์</span>
          </div>
          <div class="kpi-value">${fmtMB(cache.totalMB)}</div>
          <div class="kpi-sub">cache ${fmtMB(cache.cacheMB)} · server ${fmtMB(cache.serverCacheMB)} · log ${fmtMB(cache.logsMB)}</div>
          <div class="kpi-actions">
            <button class="btn btn-sm btn-outline" data-act="clean-cache">${icon('broom')} ล้างแคช</button>
            <button class="btn btn-sm btn-ghost" data-act="goto" data-to="performance">ดูทั้งหมด ${icon('chevron')}</button>
          </div>
        </div>

        <div class="card kpi-card">
          <div class="kpi-head">
            <span class="kpi-label">Bandwidth Cap (QoS)</span>
            <span class="chip ${qos.active ? 'ok' : ''}"><span class="dot"></span>${qos.active ? 'ACTIVE' : 'DEFAULT'}</span>
          </div>
          <div class="kpi-value">${qos.active ? `${qos.rateMbps || '?'} Mbps` : 'ยังไม่เปิด'}</div>
            <div class="kpi-sub">${qos.active ? `จำกัดทราฟฟิก FiveM · ${qos.count || 0} policy` : 'ใช้เฉพาะตอน upload เต็ม / bufferbloat'}</div>
          <div class="kpi-actions">
            <button class="btn btn-sm btn-primary" data-act="goto" data-to="network">${icon('wifi')} ตั้งค่าเน็ต</button>
            <button class="btn btn-sm btn-ghost" data-act="goto" data-to="tweaks">Optimize ${icon('chevron')}</button>
          </div>
        </div>
      </div>

      <div class="grid-2">
        <section class="card">
          <div class="card-head">
            <div>
              <h2 class="card-title">ทางลัด</h2>
              <p class="card-desc">งานที่ใช้บ่อย กดครั้งเดียวจบ</p>
            </div>
          </div>
          <div class="card-body">
            <div class="actions">
              ${tile('play', 'เปิด FiveM', 'เริ่มเกมทันที', 'launch')}
              ${tile('globe', 'เชื่อมต่อเซิร์ฟเวอร์', 'ต่อไปยังเซิร์ฟเวอร์ที่บันทึกไว้', 'goto', 'data-to="network"')}
              ${tile('broom', 'ล้างแคช', 'คืนพื้นที่และแก้บั๊กโหลดช้า', 'clean-cache')}
              ${tile('sliders', 'ปรับกราฟิก', 'ตั้งค่าคุณภาพภาพทีละตัว', 'goto', 'data-to="graphics"')}
              ${tile('zap', 'Optimize (Safe)', 'เปิด tweak ระดับปลอดภัยทั้งหมด', 'goto', 'data-to="tweaks"')}
              ${tile('save', 'สำรองค่า', 'บันทึกสำรองก่อนแก้ไข', 'backup')}
            </div>
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <div>
              <h2 class="card-title">กิจกรรมล่าสุด</h2>
              <p class="card-desc">ประวัติการทำงานในแอปนี้</p>
            </div>
            ${activity.length ? `<button class="btn btn-sm btn-ghost" data-act="clear-activity">ล้างประวัติ</button>` : ''}
          </div>
          <div class="card-body ${activity.length ? '' : 'flush'}">
            ${activity.length ? `<div class="list">${activity.map((item) => `
              <div class="list-row">
                <span class="act-ico ${item.kind}">${icon(item.icon || 'check')}</span>
                <span class="act-text">${escapeHtml(item.text)}</span>
                <span class="act-time">${timeAgo(item.at)}</span>
              </div>`).join('')}</div>` : `<div class="empty">
                ${icon('clock', 'empty-ico')}
                <div class="empty-title">ยังไม่มีกิจกรรม</div>
                <div class="empty-text">ลองกดล้างแคชหรือบันทึกค่ากราฟิก แล้วรายการจะขึ้นที่นี่</div>
              </div>`}
          </div>
        </section>
      </div>

      <section class="card">
        <div class="card-head">
          <div>
            <h2 class="card-title">ข้อมูลระบบ</h2>
            <p class="card-desc">ตรวจพบอัตโนมัติจากเครื่องนี้</p>
          </div>
          <span class="chip ${s.admin ? 'ok' : 'warn'}">${icon('shield')} ${s.admin ? 'สิทธิ์ผู้ดูแล' : 'ไม่มีสิทธิ์ผู้ดูแล'}</span>
        </div>
        <div class="card-body">
          <div class="kv-grid">
            ${kv('ระบบปฏิบัติการ', s.os)}
            ${kv('ชื่อเครื่อง', s.machine)}
            ${kv('ผู้ใช้', s.user)}
            ${kv('พอร์ตเซิร์ฟเวอร์', String(s.port || 5180))}
          </div>
          <div class="divider"></div>
          ${pathRow('โฟลเดอร์ FiveM', s.paths?.fivemApp, 'fivem')}
          ${pathRow('โฟลเดอร์ GTA V', s.paths?.gta, 'gta')}
          ${pathRow('ไฟล์ตั้งค่า', s.paths?.settings, 'settings')}
        </div>
      </section>
    </div>`;

  root.querySelectorAll('[data-act]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const act = btn.dataset.act;

      if (act === 'goto') {
        location.hash = `#/${btn.dataset.to}`;
        return;
      }
      if (act === 'clear-activity') {
        clearActivity();
        ctx.rerender();
        return;
      }
      if (act === 'launch') {
        btn.disabled = true;
        await doAction('launch', { label: 'กำลังเปิด FiveM…', icon: 'play' });
        btn.disabled = false;
        return;
      }
      if (act === 'open') {
        await doAction('open', { silent: true, extra: { target: btn.dataset.target }, icon: 'folder' });
        return;
      }
      if (act === 'backup') {
        btn.disabled = true;
        await doAction('backup', { label: 'สำรองไฟล์ตั้งค่าแล้ว', icon: 'save' });
        btn.disabled = false;
        return;
      }
      if (act === 'clean-cache') {
        btn.disabled = true;
        await doAction('clean-cache', { label: 'ล้างแคช FiveM แล้ว', icon: 'broom' });
        ctx.refresh();
      }
    });
  });
}
