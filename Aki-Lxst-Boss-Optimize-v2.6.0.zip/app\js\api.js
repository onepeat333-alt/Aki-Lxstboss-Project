// API client. If the PowerShell backend is not reachable (for example when
// the page is opened as a plain file) the app falls back to demo data so the
// UI stays fully explorable.
import {
  ALL_FIELDS, DEFAULT_VALUES, FIELD_BY_KEY, MOCK_BACKUPS, MOCK_QOS, MOCK_REG_BACKUPS,
  MOCK_INI_BACKUPS, MOCK_SPECS, MOCK_STATUS, TWEAK_CATALOG,
} from './data.js';

const demoState = {
  enabled: false,
  values: { ...DEFAULT_VALUES },
  tweaks: Object.fromEntries(TWEAK_CATALOG.map((t) => [t.id, null])),
  qos: { ...MOCK_QOS, active: false, count: 0, rateMbps: null, policies: [] },
};

export function isDemo() {
  return demoState.enabled;
}

async function request(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function mockSettings() {
  const sections = {};
  for (const [k, v] of Object.entries(demoState.values)) {
    if (k === 'resolution') continue;
    const field = FIELD_BY_KEY[k];
    const section = field ? field.section : 'video';
    if (!sections[section]) sections[section] = {};
    sections[section][k] = String(v);
  }
  return { ok: true, path: MOCK_STATUS.paths.settings, exists: true, sections };
}

export async function getStatus() {
  try {
    const data = await request('/api/status');
    demoState.enabled = false;
    return data;
  } catch {
    demoState.enabled = true;
    return MOCK_STATUS;
  }
}

export async function getSpecs() {
  try {
    const data = await request('/api/specs');
    demoState.enabled = false;
    return { ...MOCK_SPECS, ...data };
  } catch {
    demoState.enabled = true;
    return MOCK_SPECS;
  }
}

export async function getSettings() {
  try {
    const data = await request('/api/settings');
    demoState.enabled = false;
    return data;
  } catch {
    demoState.enabled = true;
    return mockSettings();
  }
}

export async function saveSettings(payload) {
  if (demoState.enabled) {
    for (const bag of Object.values(payload.sections || {})) {
      Object.assign(demoState.values, bag);
    }
    await new Promise((r) => setTimeout(r, 350));
    return { ok: true, message: 'บันทึกแล้ว (โหมดตัวอย่าง)', path: MOCK_STATUS.paths.settings, backup: 'settings-demo.xml' };
  }
  return request('/api/settings', { method: 'POST', body: JSON.stringify(payload) });
}

export async function runAction(action, extra = {}) {
  if (demoState.enabled) {
    await new Promise((r) => setTimeout(r, 420));
    const freed = { 'clean-cache': 1206.7, 'clean-browser-cache': 380.5, 'clean-logs': 18.4 }[action] || 0;
    return { ok: true, action, message: `${action} (โหมดตัวอย่าง)`, freedMB: freed };
  }
  return request('/api/action', { method: 'POST', body: JSON.stringify({ action, ...extra }) });
}

export async function getBackups() {
  try {
    const data = await request('/api/backups');
    demoState.enabled = false;
    return data;
  } catch {
    demoState.enabled = true;
    return { ok: true, items: MOCK_BACKUPS };
  }
}

export async function getRegBackups() {
  try {
    const data = await request('/api/regbackups');
    demoState.enabled = false;
    return data;
  } catch {
    demoState.enabled = true;
    return { ok: true, items: MOCK_REG_BACKUPS };
  }
}

export async function getIniBackups() {
  try {
    const data = await request('/api/inibackups');
    demoState.enabled = false;
    return data;
  } catch {
    demoState.enabled = true;
    return { ok: true, items: MOCK_INI_BACKUPS };
  }
}

export async function getTweaks() {
  try {
    const data = await request('/api/tweaks');
    demoState.enabled = false;
    return data;
  } catch {
    demoState.enabled = true;
    return {
      ok: true,
      admin: true,
      items: TWEAK_CATALOG.map((t) => ({ ...t, enabled: demoState.tweaks[t.id], usable: true })),
    };
  }
}

export async function setTweak(id, enabled) {
  if (demoState.enabled) {
    await new Promise((r) => setTimeout(r, 380));
    demoState.tweaks[id] = enabled;
    const t = TWEAK_CATALOG.find((x) => x.id === id);
    return { ok: true, id, enabled, message: `${enabled ? 'เปิด' : 'ปิด'} ${t ? t.label : id} แล้ว (โหมดตัวอย่าง)` };
  }
  return request('/api/tweak', { method: 'POST', body: JSON.stringify({ id, enabled }) });
}

export async function applySafeTweaks() {
  if (demoState.enabled) {
    await new Promise((r) => setTimeout(r, 900));
    for (const t of TWEAK_CATALOG) {
      if (t.tier === 'safe') demoState.tweaks[t.id] = true;
    }
    return { ok: true, applied: TWEAK_CATALOG.filter((t) => t.tier === 'safe').length, failed: 0, message: 'เปิด tweak ระดับปลอดภัยแล้ว (โหมดตัวอย่าง)' };
  }
  return request('/api/tweaks/apply-safe', { method: 'POST', body: '{}' });
}

export async function getQos() {
  try {
    const data = await request('/api/qos');
    demoState.enabled = false;
    return data;
  } catch {
    demoState.enabled = true;
    return demoState.qos;
  }
}

export async function setQos(action, rateMbps) {
  if (demoState.enabled) {
    await new Promise((r) => setTimeout(r, 600));
    if (action === 'reset') {
      demoState.qos = { ...demoState.qos, active: false, count: 0, rateMbps: null, nlaEnabled: false, policies: [] };
      return { ok: true, message: 'รีเซ็ต QoS แล้ว (โหมดตัวอย่าง)' };
    }
    demoState.qos = {
      ...demoState.qos,
      active: true,
      count: 17,
      rateMbps,
      nlaEnabled: true,
      policies: [{ name: 'GameOpt_FiveM_exe' }, { name: 'GameOpt_Port_30120' }],
    };
    return { ok: true, message: `จำกัดทราฟฟิก FiveM ที่ ${rateMbps} Mbps (โหมดตัวอย่าง)`, created: 17 };
  }
  return request('/api/qos', { method: 'POST', body: JSON.stringify({ action, rateMbps }) });
}

export { ALL_FIELDS };
