#requires -version 5
# ---------------------------------------------------------------
#  Makes the app feel like a normal installed app:
#  Desktop + Start Menu shortcuts to the built EXE.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File .\install-app.ps1
#    powershell -ExecutionPolicy Bypass -File .\install-app.ps1 -Uninstall
#    powershell -ExecutionPolicy Bypass -File .\install-app.ps1 -NoDesktop
# ---------------------------------------------------------------
[CmdletBinding()]
param(
    [switch]$Uninstall,
    [switch]$NoDesktop
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (-not $root) { $root = Split-Path -Parent $MyInvocation.MyCommand.Path }

$exe      = Join-Path $root 'dist\Aki-Lxstboss-optimize.exe'
$launcher = Join-Path $root 'AkiBossMap.ps1'
$appName  = 'Aki Lxstboss optimize'
$desktop  = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')

function Say([string]$text, [string]$color = 'Gray') { Write-Host "  $text" -ForegroundColor $color }

# --- uninstall ---------------------------------------------------
if ($Uninstall) {
    $targets = @(
        (Join-Path $desktop "$appName.lnk"),
        (Join-Path $desktop "$appName (Admin).lnk"),
        (Join-Path $programs "$appName.lnk"),
        (Join-Path $programs "$appName (Admin).lnk")
    )
    $removed = 0
    foreach ($t in $targets) {
        if (Test-Path -LiteralPath $t) {
            Remove-Item -LiteralPath $t -Force
            Say "- $t" 'Yellow'
            $removed++
        }
    }
    Write-Host ''
    if ($removed -gt 0) { Say "removed $removed shortcut(s)" 'Green' } else { Say 'no shortcuts found' 'Gray' }
    Write-Host ''
    exit 0
}

# --- what should the shortcut point at? --------------------------
$useExe = Test-Path -LiteralPath $exe
if ($useExe) {
    $target   = $exe
    $workDir  = Split-Path -Parent $exe
    $iconFile = $exe
    $baseArgs = ''
} elseif (Test-Path -LiteralPath $launcher) {
    $target   = (Get-Command powershell.exe).Source
    $workDir  = $root
    $iconFile = Join-Path $root 'app\assets\aki-logo.png'
    $baseArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$launcher`""
    Say 'EXE not found - shortcuts will point at AkiBossMap.ps1 (run build-all.ps1 for the EXE)' 'Yellow'
} else {
    Say 'neither Aki-Lxstboss-optimize.exe nor AkiBossMap.ps1 found in this folder' 'Red'
    exit 1
}

$shell = New-Object -ComObject WScript.Shell

function New-Shortcut([string]$path, [string]$arguments, [string]$description) {
    $lnk = $shell.CreateShortcut($path)
    $lnk.TargetPath       = $target
    $lnk.Arguments        = $arguments
    $lnk.WorkingDirectory = $workDir
    if (Test-Path -LiteralPath $iconFile) { $lnk.IconLocation = "$iconFile,0" }
    $lnk.Description      = $description
    $lnk.WindowStyle      = 7   # start minimised so the console does not cover the UI
    $lnk.Save()
    Say "+ $path" 'Green'
}

Write-Host ''
Say "installing '$appName' shortcuts" 'Cyan'
Write-Host ''

if (-not $NoDesktop) {
    New-Shortcut (Join-Path $desktop "$appName.lnk") $baseArgs 'Open Aki Lxst Boss Optimize'
    New-Shortcut (Join-Path $desktop "$appName (Admin).lnk") ($baseArgs + ' -Admin') 'Open Aki Lxst Boss Optimize as Administrator'
}
New-Shortcut (Join-Path $programs "$appName.lnk") $baseArgs 'Open Aki Lxst Boss Optimize'
New-Shortcut (Join-Path $programs "$appName (Admin).lnk") ($baseArgs + ' -Admin') 'Open Aki Lxst Boss Optimize as Administrator'

Write-Host ''
Say 'done - launch it from the Desktop icon or the Start Menu' 'Green'
Say 'remove them later: powershell -ExecutionPolicy Bypass -File .\install-app.ps1 -Uninstall' 'DarkGray'
Write-Host ''
