// Tiny observable store + persisted app preferences.
import { ALL_FIELDS, DEFAULT_VALUES, FIELD_BY_KEY, PRESETS, fromXml } from './data.js';

const listeners = new Set();
const LS = {
  activity: 'aki.activity',
  favorites: 'aki.favorites',
  paths: 'aki.paths',
};

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore quota errors */
  }
}

export const state = {
  ready: false,
  demo: false,
  status: null,
  specs: null,
  values: { ...DEFAULT_VALUES },
  saved: { ...DEFAULT_VALUES },
  tweaks: [],
  tweaksAdmin: false,
  qos: null,
  activity: read(LS.activity, []),
  favorites: read(LS.favorites, []),
  paths: read(LS.paths, { gtaDir: '' }),
};

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function setState(patch) {
  Object.assign(state, patch);
  listeners.forEach((fn) => fn(state));
}

export function isDirty() {
  return JSON.stringify(state.values) !== JSON.stringify(state.saved);
}

export function resetValues() {
  setState({ values: { ...state.saved } });
}

export function applyLocalPreset(id) {
  const preset = PRESETS.find((p) => p.id === id) || PRESETS[0];
  setState({ values: { ...state.values, ...preset.values } });
}

// Keys the app reads/writes even though they are not UI fields. Everything
// else in the XML is left completely untouched (the server only sets the
// keys it receives, so unknown keys keep their original section/value).
const EXTRA_KEYS = new Set(['ScreenWidth', 'ScreenHeight']);

export function valuesFromSettings(res) {
  const flat = { ...DEFAULT_VALUES };
  const sections = (res && res.sections) || {};
  for (const bag of Object.values(sections)) {
    if (!bag) continue;
    for (const [k, v] of Object.entries(bag)) {
      const field = FIELD_BY_KEY[k];
      if (field) flat[k] = fromXml(field, v);
      else if (EXTRA_KEYS.has(k)) flat[k] = Number(v);
    }
  }
  return flat;
}

export function payloadFrom(values) {
  const sections = {};
  for (const [key, value] of Object.entries(values)) {
    if (key === 'resolution') continue;
    const field = FIELD_BY_KEY[key];
    const section = field ? field.section : (EXTRA_KEYS.has(key) ? 'video' : null);
    if (!section) continue;
    if (!sections[section]) sections[section] = {};
    sections[section][key] = value;
  }
  return {
    sections,
    paths: state.paths.gtaDir ? { gtaDir: state.paths.gtaDir } : {},
  };
}

export function settingsPayload() {
  return payloadFrom(state.values);
}

export function currentPresetId() {
  for (const preset of PRESETS) {
    const keys = Object.keys(preset.values);
    const same = keys.every((k) => String(state.values[k]) === String(preset.values[k]));
    if (same) return preset.id;
  }
  return 'custom';
}

export function missingPresetKeys(preset) {
  return Object.keys(preset.values).filter((k) => k in state.values && String(state.values[k]) !== String(preset.values[k])).length;
}

export function pushActivity(text, kind = 'info', icon = 'check') {
  const entry = { id: Date.now() + Math.random().toString(16).slice(2), text, kind, icon, at: new Date().toISOString() };
  const activity = [entry, ...state.activity].slice(0, 30);
  state.activity = activity;
  write(LS.activity, activity);
  listeners.forEach((fn) => fn(state));
}

export function clearActivity() {
  state.activity = [];
  write(LS.activity, []);
  listeners.forEach((fn) => fn(state));
}

export function savePaths(paths) {
  state.paths = { ...state.paths, ...paths };
  write(LS.paths, state.paths);
}

export function addFavorite(entry) {
  const list = state.favorites.filter((f) => f.url !== entry.url);
  list.unshift(entry);
  state.favorites = list.slice(0, 12);
  write(LS.favorites, state.favorites);
  listeners.forEach((fn) => fn(state));
}

export function removeFavorite(url) {
  state.favorites = state.favorites.filter((f) => f.url !== url);
  write(LS.favorites, state.favorites);
  listeners.forEach((fn) => fn(state));
}

export function allFields() {
  return ALL_FIELDS;
}

export function setTweakState(id, enabled) {
  state.tweaks = state.tweaks.map((t) => (t.id === id ? { ...t, enabled } : t));
  listeners.forEach((fn) => fn(state));
}

export function enabledTweakCount() {
  return state.tweaks.filter((t) => t.enabled === true).length;
}

export function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return 'เมื่อสักครู่';
  if (diff < 3600) return `${Math.floor(diff / 60)} นาทีที่แล้ว`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} ชั่วโมงที่แล้ว`;
  return new Date(iso).toLocaleDateString('th-TH', { day: 'numeric', month: 'short' });
}
