import { saveSettings } from '../api.js';
import { PRESETS } from '../data.js';
import { icon } from '../icons.js';
import { currentPresetId, payloadFrom, pushActivity, setState, state } from '../store.js';
import { confirmDialog, escapeHtml, toast } from '../ui.js';

function presetCard(preset, activeId) {
  const active = activeId === preset.id;
  return `<article class="preset ${preset.featured ? 'featured' : ''} ${active ? 'current' : ''}">
    <div class="preset-head">
      <span class="preset-ico">${icon(preset.icon)}</span>
      <div class="preset-titles">
        <div class="preset-name">${escapeHtml(preset.name)}</div>
        <div class="preset-tag">${escapeHtml(preset.tagline)}</div>
      </div>
      ${active ? `<span class="chip ok"><span class="dot"></span>ใช้งานอยู่</span>` : ''}
    </div>
    <p class="preset-desc">${escapeHtml(preset.desc)}</p>
    <ul class="preset-list">
      ${preset.bullets.map((b) => `<li>${icon('check')}<span>${escapeHtml(b)}</span></li>`).join('')}
    </ul>
    <div class="preset-foot">
      <span class="mono muted">${Object.keys(preset.values).length} ค่า</span>
      <button class="btn ${preset.featured ? 'btn-primary' : 'btn-outline'}" data-apply-preset="${preset.id}">
        ${active ? icon('check') + ' ใช้งานแล้ว' : icon('zap') + ' ใช้โปรไฟล์นี้'}
      </button>
    </div>
  </article>`;
}

export default function mount(root, ctx) {
  const activeId = currentPresetId();

  root.innerHTML = `
    <div class="stack">
      <div class="profiles-banner">
        <div class="banner-text">
          <span class="eyebrow">Aki Lxst Boss — Profiles</span>
          <h2 class="banner-title">Choose Your <b>Setup</b></h2>
          <p class="banner-sub">สี่โปรไฟล์ที่จูนมาแล้วสำหรับ FiveM — กดครั้งเดียวจบ เลือกตามสเปกเครื่องของคุณ</p>
        </div>
        <img class="banner-art" src="./assets/aki-logo.png" alt="" />
        <span class="banner-sheen" aria-hidden="true"></span>
      </div>

      <div class="callout info">
        ${icon('shield')}
        <div><strong>ปลอดภัยทุกครั้งที่ใช้งาน</strong> — ก่อนเขียนทับ ระบบจะสำรอง
        <code>gta5_settings.xml</code> เดิมไว้ให้เสมอ และย้อนกลับได้จากหน้า
        <a href="#/settings">ตั้งค่า</a></div>
      </div>

      <div class="presets">
        ${PRESETS.map((p) => presetCard(p, activeId)).join('')}
      </div>

      <section class="card">
        <div class="card-head">
          <div class="card-heading">
            <span class="head-ico">${icon('sliders')}</span>
            <div>
              <h2 class="card-title">อยากปรับเองทีละค่า?</h2>
              <p class="card-desc">ไปที่หน้ากราฟิกเพื่อตั้งค่าแต่ละตัว ตั้งแต่เงาไปจนถึงระยะโหลดวัตถุ</p>
            </div>
          </div>
          <a class="btn btn-outline" href="#/graphics">${icon('sliders')} เปิดหน้ากราฟิก</a>
        </div>
      </section>
    </div>`;

  root.querySelectorAll('[data-apply-preset]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const preset = PRESETS.find((p) => p.id === btn.dataset.applyPreset);
      if (!preset) return;

      const ok = await confirmDialog({
        title: `ใช้โปรไฟล์ ${preset.name}?`,
        text: 'ระบบจะเขียนค่าลง gta5_settings.xml และสำรองไฟล์เดิมไว้ก่อนทุกครั้ง',
        confirmText: 'ใช้โปรไฟล์นี้',
      });
      if (!ok) return;

      btn.disabled = true;
      const values = { ...state.values, ...preset.values };
      try {
        let res = await saveSettings(payloadFrom(values));
        if (!res.ok && res.fivemRunning) {
          const force = await confirmDialog({
            title: 'FiveM กำลังทำงานอยู่',
            text: 'เกมจะเขียนทับไฟล์นี้เมื่อปิด แนะนำให้ปิดเกมก่อน',
            confirmText: 'เขียนทับเลย',
            danger: true,
          });
          if (!force) {
            btn.disabled = false;
            return;
          }
          res = await saveSettings({ ...payloadFrom(values), force: true });
        }
        if (res.ok) {
          setState({ values, saved: { ...values } });
          pushActivity(`ใช้โปรไฟล์ ${preset.name}`, 'success', 'layers');
          toast(`ใช้โปรไฟล์ ${preset.name} เรียบร้อย`, 'success');
          ctx.rerender();
        } else {
          toast(res.message || 'ใช้งานโปรไฟล์ไม่สำเร็จ', 'error');
          btn.disabled = false;
        }
      } catch (err) {
        toast('ใช้งานโปรไฟล์ไม่สำเร็จ: ' + (err.message || err), 'error');
        btn.disabled = false;
      }
    });
  });
}
