import { applySafeTweaks, getTweaks, setTweak } from '../api.js';
import { icon } from '../icons.js';
import { pushActivity, setState, state, setTweakState } from '../store.js';
import { confirmDialog, escapeHtml, toast } from '../ui.js';

const CAT_INFO = {
  network: { label: 'Network & Internet', th: 'เน็ตและเครือข่าย', icon: 'wifi', desc: 'TCP/การ์ดเน็ต/QoS — ใช้แก้อาการเน็ตตัน ไม่ใช่ยาวิเศษสำหรับ ping' },
  system:  { label: 'Windows & System', th: 'ระบบ Windows', icon: 'cpu', desc: 'MMCSS / Game Mode / Power / HAGS — ผลจริงขึ้นกับสเปกและเวอร์ชัน Windows' },
  input:   { label: 'Mouse / Keyboard / UI', th: 'เมาส์ คีย์บอร์ด หน้าตา', icon: 'sliders', desc: 'การตอบสนองของเมาส์ คีย์บอร์ด และ UI — เรื่องความรู้สึก ไม่ใช่ FPS' },
  fivem:   { label: 'FiveM / GTA Engine', th: 'ตัวเกม FiveM', icon: 'play', desc: 'เขียนลง CitizenFX.ini โดยตรง — ปิดเกมก่อนตั้งค่า แล้วเปิดใหม่' },
};

const TIER_INFO = {
  safe: {
    title: 'Quick Safe Setup',
    badge: 'SAFE',
    desc: 'ผลชัด เสี่ยงต่ำ ปิดกลับได้ทุกเมื่อ — กดปุ่มด้านขวาเพื่อเปิดทั้งหมดทีเดียว',
  },
  caution: {
    title: 'Advanced — แตะเมื่อเข้าใจ',
    badge: 'CAUTION',
    desc: 'ผลไม่แน่นอน มีผลข้างเคียง หรือเฉพาะบางเครื่อง — อ่านคำอธิบาย เปิดทีละตัวแล้วทดสอบ',
  },
};

const CAT_ORDER = ['fivem', 'system', 'network', 'input'];

function pills(t) {
  let html = '';
  if (t.admin) html += `<span class="pill admin">ADMIN</span>`;
  if (t.reboot) html += `<span class="pill reboot">RESTART</span>`;
  return html;
}

function row(t) {
  const unknown = t.enabled === null || t.enabled === undefined;
  const on = t.enabled === true;
  const disabled = t.usable === false ? 'disabled' : '';
  return `<div class="tweak-row">
    <div class="tweak-body">
      <div class="tweak-title">${escapeHtml(t.label)} ${pills(t)}</div>
      <div class="tweak-desc">${escapeHtml(t.desc || '')}</div>
    </div>
    <button class="toggle ${on ? 'on' : ''} ${unknown ? 'unknown' : ''}" type="button" role="switch"
      aria-checked="${on}" data-tweak="${escapeHtml(t.id)}" data-usable="${t.usable === false ? '0' : '1'}"
      title="${t.usable === false ? 'ต้องรันแอปแบบ Run as administrator' : unknown ? 'ตรวจสอบสถานะไม่ได้ — กดเพื่อตั้งค่า' : 'เปิด/ปิด'}"
      ${disabled}></button>
  </div>`;
}

function groupBlock(cat, items) {
  const info = CAT_INFO[cat];
  const onCount = items.filter((t) => t.enabled === true).length;
  const iconName = info ? info.icon : 'zap';
  return `<div class="tweak-group" data-cat="${escapeHtml(cat)}">
    <div class="group-head">
      <span class="group-ico">${icon(iconName)}</span>
      <div class="group-titles">
        <span class="group-title">${escapeHtml(info ? info.label : cat)} <span class="group-th">${escapeHtml(info ? info.th : '')}</span></span>
        <span class="group-desc">${escapeHtml(info ? info.desc : '')}</span>
      </div>
      <span class="group-count">${onCount}/${items.length} เปิด</span>
    </div>
    <div class="tweak-list">
      ${items.map(row).join('')}
    </div>
  </div>`;
}

function tierBlock(tier, items) {
  const info = TIER_INFO[tier];
  const tierItems = items.filter((t) => t.tier === tier);
  if (!tierItems.length) return '';
  const groups = CAT_ORDER
    .map((cat) => [cat, tierItems.filter((t) => t.cat === cat)])
    .filter(([, list]) => list.length)
    .map(([cat, list]) => groupBlock(cat, list))
    .join('');
  const unknownCats = [...new Set(tierItems.map((t) => t.cat))].filter((c) => !CAT_ORDER.includes(c));
  const extra = unknownCats.map((cat) => groupBlock(cat, tierItems.filter((t) => t.cat === cat))).join('');
  const onCount = tierItems.filter((t) => t.enabled === true).length;
  return `<section class="tweak-tier tier-${tier}">
    <div class="tier-head">
      <div class="tier-headtext">
        <h3 class="tier-title"><span class="tier-badge ${tier}">${info.badge}</span>${escapeHtml(info.title)}</h3>
        <p class="tier-desc">${escapeHtml(info.desc)}</p>
      </div>
      <span class="status-pill small${tier === 'safe' ? ' ok' : ''}"><span class="dot"></span>${onCount}/${tierItems.length} เปิด</span>
    </div>
    <div class="tier-groups">${groups}${extra}</div>
  </section>`;
}

// Category rail: one click narrows the page to a single topic so a long list
// of tweaks stops feeling like a wall of switches.
function filterRail(items) {
  const totals = { all: items.length };
  CAT_ORDER.forEach((cat) => { totals[cat] = items.filter((t) => t.cat === cat).length; });
  const onCounts = { all: items.filter((t) => t.enabled === true).length };
  CAT_ORDER.forEach((cat) => { onCounts[cat] = items.filter((t) => t.cat === cat && t.enabled === true).length; });
  const chips = [['all', 'ทั้งหมด', 'grid'], ...CAT_ORDER.map((cat) => [cat, CAT_INFO[cat].th, CAT_INFO[cat].icon])];
  return `<div class="cat-rail" role="tablist" aria-label="หมวดของ tweak">
    ${chips.map(([id, label, ico], index) => `
      <button type="button" role="tab" class="cat-chip ${index === 0 ? 'active' : ''}" data-filter="${id}"
        aria-selected="${index === 0}">
        ${icon(ico)}<span>${escapeHtml(label)}</span>
        <i class="cat-count">${onCounts[id]}/${totals[id] || 0}</i>
      </button>`).join('')}
  </div>`;
}

export default function mount(root, ctx) {
  const admin = state.tweaksAdmin;
  const items = state.tweaks || [];
  const onCount = items.filter((t) => t.enabled === true).length;
  const safeCount = items.filter((t) => t.tier === 'safe').length;

  root.innerHTML = `
    <div class="stack">
      ${!admin ? `<div class="callout warn">${icon('alert')}
        <div><strong>ยังไม่ได้รันแบบ Administrator</strong> — tweak ที่มีป้าย ADMIN จะกดไม่ได้
        ให้ปิดแอปแล้วเปิด <code>run.bat</code> ด้วย Right-click → Run as administrator</div>
      </div>` : ''}

      <div class="tweak-shell">
        <div class="tweak-toolbar">
          <div class="toolbar-art" aria-hidden="true"></div>
          <div class="toolbar-note">
            ${icon('info')}
            <span>${items.length} tweaks แบ่งเป็น <b>Safe ${safeCount}</b> ตัว กับ <b>Advanced</b> ตัว — ทุกการเปลี่ยนแปลงสำรองไว้ก่อนเสมอ</span>
          </div>
          <div class="toolbar-actions">
            <span class="status-pill small"><span class="dot"></span>${onCount} ACTIVE</span>
            <button class="btn btn-sm btn-outline" data-refresh-tweaks>${icon('refresh')} รีเฟรช</button>
            <button class="btn btn-sm btn-primary" data-apply-safe ${admin ? '' : 'disabled'}>${icon('zap')} Quick Safe Setup</button>
          </div>
        </div>

        ${filterRail(items)}

        <div class="tweak-tiers">
          ${items.length ? `${tierBlock('safe', items)}${tierBlock('caution', items)}` : `<div class="empty">${icon('alert', 'empty-ico')}
            <div class="empty-title">ยังไม่มีข้อมูล tweak</div>
            <div class="empty-text">กดรีเฟรช หรือตรวจสอบว่า backend ทำงานอยู่</div></div>`}
        </div>
      </div>

      <section class="card card-pad">
        <div class="tip">
          ${icon('info')}
          <div><strong>ทุกการเปลี่ยนแปลงถูกสำรองไว้</strong> — แก้ registry จะ export ค่าเดิมเป็น <code>.reg</code> ไว้ที่ <code>regbackups</code>,
          แก้ <code>CitizenFX.ini</code> จะสำรองไว้ที่ <code>citizenfx-backups</code>, แก้ settings จะสำรองเป็น <code>.xml</code> ที่ <code>backups</code>
          — กู้คืนได้จากหน้า Settings ทุกตัว และค่าที่มีป้าย RESTART ต้องปิดเกม/รีสตาร์ทเครื่องก่อนจึงจะมีผล</div>
        </div>
      </section>
    </div>`;

  root.querySelectorAll('[data-tweak]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (btn.dataset.usable === '0') {
        toast('ต้องรันแอปแบบ Run as administrator ก่อน', 'warn');
        return;
      }
      const id = btn.dataset.tweak;
      const next = !btn.classList.contains('on');
      btn.classList.add('busy');
      btn.disabled = true;
      try {
        const res = await setTweak(id, next);
        if (res.ok) {
          const enabled = res.enabled === null || res.enabled === undefined ? next : res.enabled;
          btn.classList.toggle('on', enabled);
          btn.classList.remove('unknown');
          btn.setAttribute('aria-checked', String(enabled));
          setTweakState(id, enabled);
          toast(res.message || 'บันทึกแล้ว', 'success');
          pushActivity(res.message || `Tweak ${id}`, 'success', 'zap');
          if (res.backup) toast(`สำรองไว้แล้ว: ${res.backup}`, 'info', 4000);
          const active = (state.tweaks || []).filter((t) => t.enabled === true).length;
          const pill = root.querySelector('.status-pill.small');
          if (pill) pill.innerHTML = `<span class="dot"></span>${active} ACTIVE`;
        } else {
          toast(res.message || 'ทำรายการไม่สำเร็จ', res.fivemRunning ? 'warn' : 'error');
        }
      } catch (err) {
        toast('ทำรายการไม่สำเร็จ: ' + (err.message || err), 'error');
      } finally {
        btn.classList.remove('busy');
        btn.disabled = false;
      }
    });
  });

  root.querySelectorAll('[data-filter]').forEach((chip) => {
    chip.addEventListener('click', () => {
      const cat = chip.dataset.filter;
      root.querySelectorAll('[data-filter]').forEach((other) => {
        other.classList.toggle('active', other === chip);
        other.setAttribute('aria-selected', String(other === chip));
      });
      root.querySelectorAll('.tweak-group').forEach((group) => {
        group.classList.toggle('hide', cat !== 'all' && group.dataset.cat !== cat);
      });
      root.querySelectorAll('.tweak-tier').forEach((tier) => {
        const visible = tier.querySelector('.tweak-group:not(.hide)');
        tier.classList.toggle('hide', !visible);
      });
    });
  });

  root.querySelector('[data-refresh-tweaks]')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    const data = await getTweaks();
    setState({ tweaks: data.items || [], tweaksAdmin: !!data.admin });
    toast('อัปเดตสถานะ tweak แล้ว', 'info', 1600);
    ctx.rerender();
  });

  root.querySelector('[data-apply-safe]')?.addEventListener('click', async () => {
    const safe = (state.tweaks || []).filter((t) => t.tier === 'safe').length;
    const ok = await confirmDialog({
      title: 'ใช้ Quick Safe Setup?',
      text: `ระบบจะเปิดเฉพาะค่าระดับปลอดภัย ${safe} รายการ (ข้าม Advanced ทั้งหมด) และสำรอง registry ก่อนทุกตัว`,
      confirmText: 'เปิดค่าปลอดภัย',
    });
    if (!ok) return;
    const res = await applySafeTweaks();
    toast(res.message || (res.ok ? 'เปิด tweak แล้ว' : 'ทำรายการไม่สำเร็จ'), res.ok ? 'success' : 'error');
    if (res.applied) pushActivity(res.message, 'success', 'zap');
    const data = await getTweaks();
    setState({ tweaks: data.items || [], tweaksAdmin: !!data.admin });
    ctx.rerender();
  });
}
