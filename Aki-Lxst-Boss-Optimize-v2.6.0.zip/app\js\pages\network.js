import { getQos, setQos } from '../api.js';
import { icon } from '../icons.js';
import { doAction } from '../actions.js';
import { addFavorite, pushActivity, removeFavorite, setState, state } from '../store.js';
import { QOS_RATES } from '../data.js';
import { confirmDialog, escapeHtml, toast } from '../ui.js';

const DNS_PRESETS = [
  { name: 'Cloudflare', primary: '1.1.1.1', secondary: '1.0.0.1', note: 'เร็วที่สุดโดยทั่วไป' },
  { name: 'Google', primary: '8.8.8.8', secondary: '8.8.4.4', note: 'เสถียรและครอบคลุม' },
];

function cleanAddress(raw) {
  return String(raw || '')
    .trim()
    .replace(/^fivem:\/\/connect\//i, '')
    .replace(/^https?:\/\//i, '')
    .replace(/\/+$/, '');
}

function favoriteRow(fav, index) {
  return `<div class="list-row fav-row">
    <span class="act-ico info">${icon('server')}</span>
    <span class="fav-main">
      <span class="fav-name">${escapeHtml(fav.name || fav.url)}</span>
      <span class="fav-url mono">${escapeHtml(fav.url)}</span>
    </span>
    <button class="btn btn-sm btn-outline" data-connect="${escapeHtml(fav.url)}">${icon('play')} เชื่อมต่อ</button>
    <button class="icon-btn" data-remove="${index}" title="ลบออกจากรายการ">${icon('x')}</button>
  </div>`;
}

function qosPolicies(qos) {
  const list = (qos && qos.policies) || [];
  if (!list.length) return '';
  const shown = list.slice(0, 4);
  return `<div class="policy-list">
    ${shown.map((p) => `<span class="policy-chip">${escapeHtml(p.name)}</span>`).join('')}
    ${list.length > shown.length ? `<span class="policy-chip more">+${list.length - shown.length}</span>` : ''}
  </div>`;
}

export default function mount(root, ctx) {
  const favorites = state.favorites;
  const qos = state.qos || {};
  const admin = state.status?.admin;
  const selected = qos.rateMbps || 5;

  root.innerHTML = `
    <div class="grid-2">
      <div class="stack">
        <section class="card qos-card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('wifi')}</span>
              <div>
                <h2 class="card-title">Bandwidth Cap (QoS)</h2>
                <p class="card-desc">จำกัดความเร็ว FiveM/GTA เท่านั้น — ใช้เมื่อ upload เต็มจนเกมกระตุก ไม่ใช่ปุ่มเพิ่ม ping หรือ FPS</p>
              </div>
            </div>
            <span class="status-pill small ${qos.active ? 'ok' : ''}">
              <span class="dot"></span>${qos.active ? `${qos.rateMbps || '?'} Mbps` : 'DEFAULT'}
            </span>
          </div>
          <div class="card-body">
            <div class="section-label plain">ขีดจำกัดความเร็ว (ต่อโปรเซส)</div>
            <div class="rate-row">
              ${QOS_RATES.map((r) => `<button type="button" class="rate-chip ${Number(selected) === r.value ? 'active' : ''}" data-rate="${r.value}">${r.label}</button>`).join('')}
              <label class="rate-custom">
                <span>กำหนดเอง</span>
                <input class="input number" type="number" min="0.25" max="100" step="0.25" value="${Number(selected)}" data-rate-custom />
                <span>Mbps</span>
              </label>
            </div>

            <div class="divider"></div>

            <div class="qos-meta">
              <div class="meta-row">
                <span class="meta-label">สถานะ</span>
                <span class="meta-value ${qos.active ? 'ok' : ''}">${qos.active ? `ใช้งาน ${qos.count} policy` : 'ยังไม่เปิดใช้'}</span>
              </div>
            </div>
            ${qosPolicies(qos)}

            <div class="row-between mt12">
                <span class="hint">${qos.active ? 'กด Reset เพื่อลบ bandwidth cap ทั้งหมดของแอป' : 'ปกติไม่ต้องเปิด — ถ้าต้องใช้ ให้ตั้งใกล้ 85–90% ของ upload จริง (เช่น upload 10 Mbps ใช้ 8–9)'}</span>
              <div class="row-gap">
                <button class="btn btn-outline" data-qos-reset ${qos.active ? '' : 'disabled'}>${icon('rotate')} Reset</button>
                <button class="btn btn-primary" data-qos-apply>${icon('zap')} เปิด Bandwidth Cap</button>
              </div>
            </div>
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('globe')}</span>
              <div>
                <h2 class="card-title">เชื่อมต่อเซิร์ฟเวอร์</h2>
                <p class="card-desc">ใส่รหัส join หรือ IP:PORT แล้วแอปจะเปิด FiveM ให้ทันที</p>
              </div>
            </div>
          </div>
          <div class="card-body">
            <label class="input-label" for="addr">ที่อยู่เซิร์ฟเวอร์</label>
            <div class="input-row">
              <input class="input" id="addr" type="text" placeholder="cfx.re/join/xxxxxx หรือ 103.10.20.30:30120" autocomplete="off" />
              <button class="btn btn-primary" data-connect-input>${icon('play')} เชื่อมต่อ</button>
            </div>
            <div class="row-between mt12">
              <span class="hint">รองรับทั้งลิงก์ cfx.re และ IP โดยตรง</span>
              <button class="btn btn-sm btn-ghost" data-add-favorite>${icon('plus')} บันทึกเป็นรายการโปรด</button>
            </div>
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <div>
              <h2 class="card-title">เซิร์ฟเวอร์ที่บันทึกไว้</h2>
              <p class="card-desc">${favorites.length ? `มี ${favorites.length} รายการ` : 'ยังไม่มีเซิร์ฟเวอร์ที่บันทึก'}</p>
            </div>
          </div>
          <div class="card-body ${favorites.length ? '' : 'flush'}">
            ${favorites.length
              ? `<div class="list">${favorites.map(favoriteRow).join('')}</div>`
              : `<div class="empty">
                  ${icon('server', 'empty-ico')}
                  <div class="empty-title">ยังไม่มีรายการโปรด</div>
                  <div class="empty-text">ใส่ที่อยู่เซิร์ฟเวอร์ด้านบน แล้วกด “บันทึกเป็นรายการโปรด”</div>
                </div>`}
          </div>
        </section>
      </div>

      <aside class="stack">
        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('shield')}</span>
              <div>
                <h2 class="card-title">DNS แนะนำ</h2>
                <p class="card-desc">DNS ช่วยเรื่องค้นหาชื่อเซิร์ฟเวอร์ ไม่ได้ลด ping ไปยังเซิร์ฟเวอร์เกมโดยตรง</p>
              </div>
            </div>
          </div>
          <div class="card-body tight">
            ${DNS_PRESETS.map((dns) => `<div class="field">
              <div class="field-info">
                <div class="field-label">${escapeHtml(dns.name)} <span class="mono muted">${dns.primary}</span></div>
                <div class="field-hint">${escapeHtml(dns.note)}</div>
              </div>
              <div class="field-control">
                <button class="btn btn-sm btn-outline" data-dns="${dns.primary}|${dns.secondary}">ใช้ค่านี้</button>
              </div>
            </div>`).join('')}
            <div class="field">
              <div class="field-info">
                <div class="field-label">ล้าง DNS cache</div>
                <div class="field-hint">แนะนำให้ทำหลังเปลี่ยน DNS ทุกครั้ง</div>
              </div>
              <div class="field-control">
                <button class="btn btn-sm btn-outline" data-act="flush-dns">${icon('refresh')} ล้าง</button>
              </div>
            </div>
          </div>
        </section>

        <section class="card card-pad">
          <div class="callout warn flush">
            ${icon('alert')}
            <div><strong>ต้องใช้สิทธิ์ผู้ดูแล</strong> ${admin ? 'แอปรันแบบ admin อยู่แล้ว' : 'เปิด run.bat ด้วย Right-click → Run as administrator'} เพื่อเปลี่ยน QoS/DNS</div>
          </div>
        </section>
      </aside>
    </div>`;

  const input = root.querySelector('#addr');
  let selectedRate = Number(selected);

  function paintRates() {
    root.querySelectorAll('[data-rate]').forEach((b) => {
      b.classList.toggle('active', Number(b.dataset.rate) === selectedRate);
    });
    const custom = root.querySelector('[data-rate-custom]');
    if (custom) custom.value = selectedRate;
  }

  root.querySelectorAll('[data-rate]').forEach((btn) => {
    btn.addEventListener('click', () => {
      selectedRate = Number(btn.dataset.rate);
      paintRates();
    });
  });
  root.querySelector('[data-rate-custom]')?.addEventListener('change', (e) => {
    let v = Number(e.target.value);
    if (!Number.isFinite(v)) v = 2;
    v = Math.max(0.25, Math.min(100, v));
    selectedRate = v;
    paintRates();
  });

  root.querySelector('[data-qos-apply]')?.addEventListener('click', async (e) => {
    const confirmed = await confirmDialog({
      title: `จำกัด FiveM ที่ ${selectedRate} Mbps?`,
      text: 'ค่านี้เป็น bandwidth cap จริง ๆ ไม่ได้เพิ่มความเร็วหรือ FPS ใช้เฉพาะตอนมีอาการเน็ต upload เต็ม / bufferbloat และกด Reset ได้ทุกเมื่อ',
      confirmText: 'จำกัดความเร็ว',
      danger: true,
    });
    if (!confirmed) return;
    const btn = e.currentTarget;
    btn.disabled = true;
    const old = btn.innerHTML;
    btn.innerHTML = `<span class="spinner sm"></span> กำลังตั้งค่า…`;
    let res;
    try {
      res = await setQos('apply', selectedRate);
    } catch (err) {
      res = { ok: false, message: err.message || 'ตั้งค่า QoS ไม่สำเร็จ' };
    }
    toast(res.message || (res.ok ? 'ตั้งค่า bandwidth cap แล้ว' : 'ตั้งค่าไม่สำเร็จ'), res.ok ? 'success' : 'error');
    if (res.ok) pushActivity(res.message, 'success', 'wifi');
    const fresh = await getQos();
    setState({ qos: fresh });
    ctx.rerender();
    btn.innerHTML = old;
  });

  root.querySelector('[data-qos-reset]')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    let res;
    try {
      res = await setQos('reset');
    } catch (err) {
      res = { ok: false, message: err.message || 'รีเซ็ต QoS ไม่สำเร็จ' };
    }
    toast(res.message || (res.ok ? 'รีเซ็ต QoS แล้ว' : 'รีเซ็ตไม่สำเร็จ'), res.ok ? 'success' : 'error');
    if (res.ok) pushActivity(res.message, 'success', 'rotate');
    const fresh = await getQos();
    setState({ qos: fresh });
    ctx.rerender();
  });

  async function connect(raw) {
    const url = cleanAddress(raw);
    if (!url) {
      toast('กรุณาใส่ที่อยู่เซิร์ฟเวอร์ก่อน', 'warn');
      input && input.focus();
      return;
    }
    await doAction('connect', { label: `กำลังเชื่อมต่อ ${url}`, icon: 'play', extra: { url } });
  }

  root.querySelector('[data-connect-input]')?.addEventListener('click', () => connect(input.value));
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') connect(input.value);
  });

  root.querySelector('[data-add-favorite]')?.addEventListener('click', () => {
    const url = cleanAddress(input.value);
    if (!url) {
      toast('ใส่ที่อยู่เซิร์ฟเวอร์ก่อนบันทึก', 'warn');
      return;
    }
    addFavorite({ url, name: url });
    toast('บันทึกเป็นรายการโปรดแล้ว', 'success');
    ctx.rerender();
  });

  root.querySelectorAll('[data-connect]').forEach((btn) => {
    btn.addEventListener('click', () => connect(btn.dataset.connect));
  });

  root.querySelectorAll('[data-remove]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const fav = state.favorites[Number(btn.dataset.remove)];
      if (!fav) return;
      removeFavorite(fav.url);
      ctx.rerender();
    });
  });

  root.querySelectorAll('[data-dns]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const [primary, secondary] = btn.dataset.dns.split('|');
      btn.disabled = true;
      const res = await doAction('set-dns', {
        label: `ตั้ง DNS เป็น ${primary} แล้ว`,
        icon: 'wifi',
        extra: { primary, secondary },
      });
      btn.disabled = false;
      if (res.ok) await doAction('flush-dns', { silent: true, extra: {}, icon: 'refresh' });
    });
  });

  root.querySelector('[data-act="flush-dns"]')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    await doAction('flush-dns', { label: 'ล้าง DNS cache แล้ว', icon: 'refresh' });
    btn.disabled = false;
  });
}
