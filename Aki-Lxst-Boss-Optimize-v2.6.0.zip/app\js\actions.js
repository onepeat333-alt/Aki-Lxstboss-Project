import { runAction } from './api.js';
import { pushActivity } from './store.js';
import { fmtMB, toast } from './ui.js';

/**
 * Runs a backend action, reports it with a toast and records it in the
 * activity feed. Returns the API response so callers can react to it.
 */
export async function doAction(action, { label = '', extra = {}, icon = 'check', silent = false } = {}) {
  let res;
  try {
    res = await runAction(action, extra);
  } catch (err) {
    res = { ok: false, message: err.message || 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้' };
  }

  if (res.ok) {
    const msg = label || res.message || 'สำเร็จ';
    const withFreed = res.freedMB ? `${msg} · คืนพื้นที่ ${fmtMB(res.freedMB)}` : msg;
    if (!silent) toast(withFreed, 'success');
    pushActivity(withFreed, 'success', icon);
  } else {
    const msg = res.message || 'ทำรายการไม่สำเร็จ';
    if (!silent) toast(msg, 'error');
    pushActivity(msg, 'error', 'alert');
  }
  return res;
}
