import { icon } from '../icons.js';
import { doAction } from '../actions.js';
import { state } from '../store.js';
import { escapeHtml, fmtMB } from '../ui.js';

const pad = (n) => String(n).padStart(2, '0');

function stamp() {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export default function mount(root, ctx) {
  const cache = state.status?.cache || {};
  const serverMB = cache.serverCacheMB || 0;
  const nuiMB = cache.nuiMB || 0;
  let gameSize = (cache.cacheMB || 0) + serverMB + nuiMB;
  let logSize = cache.logsMB || 0;

  root.innerHTML = `
    <div class="grid-2">
      <div class="stack">
        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('harddrive')}</span>
              <div>
                <h2 class="card-title">พื้นที่เก็บข้อมูล FiveM</h2>
                <p class="card-desc">ล้างแล้วเกมจะโหลดแคชใหม่ในรอบถัดไป — ไม่กระทบเซฟหรือตัวละคร</p>
              </div>
            </div>
            <button class="btn btn-sm btn-ghost" data-act="recheck">${icon('refresh')} ตรวจสอบใหม่</button>
          </div>
          <div class="card-body">
            <div class="field">
              <div class="field-info">
                <div class="field-label">แคชเกม (cache / server-cache / nui)</div>
                <div class="field-hint">ล้างเมื่อโหลดเข้าเซิร์ฟเวอร์ช้า หรือเจอ texture ขาด</div>
              </div>
              <div class="field-control">
                <span class="size-pill" data-size="game">${fmtMB(gameSize)}</span>
                <button class="btn btn-sm btn-outline" data-act="clean-cache">${icon('broom')} ล้าง</button>
              </div>
            </div>
            <div class="field">
              <div class="field-info">
                <div class="field-label">แคช browser / subprocess</div>
                <div class="field-hint">ตัวเลือกปลอดภัย — เกมสร้าง NUI cache ใหม่เอง ไม่ต้องโหลด asset ใหม่ทั้งหมด</div>
              </div>
              <div class="field-control">
                <span class="size-pill">ไม่ทราบขนาด</span>
                <button class="btn btn-sm btn-outline" data-act="clean-browser-cache">${icon('broom')} ล้าง</button>
              </div>
            </div>
            <div class="field">
              <div class="field-info">
                <div class="field-label">ไฟล์ log และ crash dump</div>
                <div class="field-hint">เก็บไว้ได้แต่จะกินพื้นที่มากขึ้นเรื่อย ๆ</div>
              </div>
              <div class="field-control">
                <span class="size-pill" data-size="logs">${fmtMB(logSize)}</span>
                <button class="btn btn-sm btn-outline" data-act="clean-logs">${icon('trash')} ล้าง</button>
              </div>
            </div>
            <div class="field">
              <div class="field-info">
                <div class="field-label">รวมทั้งหมดที่กู้คืนได้</div>
                <div class="field-hint">ตัวเลขนี้คือพื้นที่ที่ยังใช้อยู่จริงบนดิสก์</div>
              </div>
              <div class="field-control">
                <span class="size-pill strong" data-size="total">${fmtMB(gameSize + logSize)}</span>
              </div>
            </div>
          </div>
          <div class="card-foot">
            <button class="btn btn-outline" data-act="clean-logs">${icon('trash')} ล้าง log</button>
            <button class="btn btn-primary" data-act="clean-all">${icon('zap')} ล้างทั้งหมด</button>
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <div class="card-heading">
              <span class="head-ico">${icon('wifi')}</span>
              <div>
                <h2 class="card-title">เครื่องมือเครือข่าย</h2>
                <p class="card-desc">แก้ปัญหาเข้าเซิร์ฟเวอร์ไม่ได้หรือ ping สูงผิดปกติ</p>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="field">
              <div class="field-info">
                <div class="field-label">ล้าง DNS cache</div>
                <div class="field-hint">ช่วยเมื่อเชื่อมต่อเซิร์ฟเวอร์เดิมไม่ได้หลังเปลี่ยนเครือข่าย</div>
              </div>
              <div class="field-control">
                <button class="btn btn-sm btn-outline" data-act="flush-dns">${icon('refresh')} ล้าง DNS</button>
              </div>
            </div>
            <div class="field">
              <div class="field-info">
                <div class="field-label">เปิดโฟลเดอร์ข้อมูล FiveM</div>
                <div class="field-hint">ดู log, cache และไฟล์ config ด้วยตัวเอง</div>
              </div>
              <div class="field-control">
                <button class="btn btn-sm btn-outline" data-act="open-data">${icon('folder')} เปิด</button>
              </div>
            </div>
          </div>
        </section>
      </div>

      <aside class="stack sticky">
        <section class="card console-card">
          <div class="card-head">
            <div>
              <h2 class="card-title">ผลการทำงาน</h2>
              <p class="card-desc">บันทึกทุกคำสั่งที่ส่งไปยังระบบ</p>
            </div>
            <span class="chip">${icon('terminal')} local</span>
          </div>
          <div class="console" id="term" aria-live="polite"></div>
        </section>

        <section class="card card-pad">
          <div class="tip">
            ${icon('info')}
            <div>
              <strong>เคล็ดลับ:</strong> ล้างแคชก่อนเข้าเซิร์ฟเวอร์ครั้งแรกของวัน จะช่วยลดอาการ
              โหลดค้างที่ 0% และ texture หาย
            </div>
          </div>
        </section>
      </aside>
    </div>`;

  const term = root.querySelector('#term');
  const sizeGame = root.querySelector('[data-size="game"]');
  const sizeLogs = root.querySelector('[data-size="logs"]');
  const sizeTotal = root.querySelector('[data-size="total"]');

  function paintSizes() {
    if (sizeGame) sizeGame.textContent = fmtMB(gameSize);
    if (sizeLogs) sizeLogs.textContent = fmtMB(logSize);
    if (sizeTotal) sizeTotal.textContent = fmtMB(gameSize + logSize);
  }

  function log(text, kind = '') {
    const row = document.createElement('div');
    row.className = `console-line ${kind}`;
    row.innerHTML = `<span class="console-time">${stamp()}</span><span>${escapeHtml(text)}</span>`;
    term.appendChild(row);
    term.scrollTop = term.scrollHeight;
  }

  log('เชื่อมต่อกับระบบท้องถิ่นแล้ว');
  log(`พื้นที่ที่ตรวจพบ: ${fmtMB(gameSize + logSize)}`, 'ok');

  async function clean(kind) {
    const buttons = root.querySelectorAll('[data-act="clean-cache"],[data-act="clean-logs"],[data-act="clean-all"],[data-act="clean-browser-cache"]');
    buttons.forEach((b) => (b.disabled = true));

    if (kind === 'cache' || kind === 'all') {
      log('กำลังล้างแคช FiveM…');
      const res = await doAction('clean-cache', { silent: true, icon: 'broom' });
      if (res.ok) {
        const freed = res.freedMB || gameSize;
        gameSize = Math.max(0, gameSize - freed);
        log(`ล้างแคชสำเร็จ · คืนพื้นที่ ${fmtMB(freed)}`, 'ok');
      } else {
        log(res.message || 'ล้างแคชไม่สำเร็จ', 'err');
      }
      paintSizes();
    }

    if (kind === 'browser') {
      log('กำลังล้างแคช browser / subprocess…');
      const res = await doAction('clean-browser-cache', { silent: true, icon: 'broom' });
      log(res.ok ? 'ล้างแคช browser/subprocess สำเร็จ' : res.message || 'ล้างแคชไม่สำเร็จ', res.ok ? 'ok' : 'err');
    }

    if (kind === 'logs' || kind === 'all') {
      log('กำลังล้างไฟล์ log…');
      const res = await doAction('clean-logs', { silent: true, icon: 'trash' });
      if (res.ok) {
        const freed = res.freedMB || logSize;
        logSize = Math.max(0, logSize - freed);
        log(`ล้าง log สำเร็จ · คืนพื้นที่ ${fmtMB(freed)}`, 'ok');
      } else {
        log(res.message || 'ล้าง log ไม่สำเร็จ', 'err');
      }
      paintSizes();
    }

    buttons.forEach((b) => (b.disabled = false));
  }

  root.querySelectorAll('[data-act]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const act = btn.dataset.act;

      if (act === 'recheck') {
        log('กำลังตรวจสอบขนาดไฟล์ใหม่…');
        ctx.refresh();
        return;
      }
      if (act === 'clean-cache') return clean('cache');
      if (act === 'clean-browser-cache') return clean('browser');
      if (act === 'clean-logs') return clean('logs');
      if (act === 'clean-all') return clean('all');
      if (act === 'flush-dns') {
        btn.disabled = true;
        log('กำลังล้าง DNS cache…');
        const res = await doAction('flush-dns', { silent: true, icon: 'refresh' });
        log(res.ok ? 'ล้าง DNS cache สำเร็จ' : res.message || 'ล้าง DNS ไม่สำเร็จ', res.ok ? 'ok' : 'err');
        btn.disabled = false;
        return;
      }
      if (act === 'open-data') {
        const res = await doAction('open', { silent: true, extra: { target: 'fivem' }, icon: 'folder' });
        log(res.ok ? 'เปิดโฟลเดอร์ FiveM แล้ว' : res.message || 'เปิดโฟลเดอร์ไม่สำเร็จ', res.ok ? 'ok' : 'err');
      }
    });
  });
}
