import { saveSettings } from '../api.js';
import { ALL_FIELDS, GROUPS, PRESETS, RESOLUTIONS, parseResolution, resolutionOf } from '../data.js';
import { icon } from '../icons.js';
import {
  applyLocalPreset,
  currentPresetId,
  isDirty,
  pushActivity,
  resetValues,
  setState,
  settingsPayload,
  state,
} from '../store.js';
import { confirmDialog, escapeHtml, rangeFill, shortPath, toast } from '../ui.js';

function isOn(value) {
  if (value === true || value === 'true') return true;
  if (value === false || value === 'false' || value === undefined || value === null) return false;
  return Number(value) === 1;
}

function valueLabel(field, value) {
  if (field.percent) return `${Math.round(Number(value) * 100)}%`;
  if (field.labels) return field.labels[Number(value)] ?? String(value);
  return String(value);
}

function control(field) {
  const value = field.key === 'resolution' ? resolutionOf(state.values) : state.values[field.key];

  if (field.type === 'resolution') {
    const list = RESOLUTIONS.includes(value) ? RESOLUTIONS : [value, ...RESOLUTIONS];
    return `<select class="input select" data-resolution>
      ${list.map((r) => `<option value="${r}" ${r === value ? 'selected' : ''}>${r}</option>`).join('')}
    </select>`;
  }
  if (field.type === 'switch') {
    const on = field.valueType === 'bool' ? isOn(value) : Number(value) === 1;
    return `<button class="switch ${on ? 'on' : ''}" type="button" role="switch"
      aria-checked="${on}" data-switch="${field.key}" data-kind="${field.valueType}"></button>`;
  }
  if (field.type === 'select') {
    return `<select class="input select" data-select="${field.key}">
      ${field.options.map((o) => `<option value="${o.value}" ${Number(o.value) === Number(value) ? 'selected' : ''}>${escapeHtml(o.label)}</option>`).join('')}
    </select>`;
  }
  if (field.type === 'number') {
    const v = Number(value);
    return `<input class="input number" type="number" data-number="${field.key}"
      min="${field.min}" max="${field.max}" step="${field.step}" value="${Number.isFinite(v) ? v : ''}" />`;
  }
  const num = Number(value);
  const pct = ((num - field.min) / (field.max - field.min)) * 100;
  return `<input class="range" type="range" data-range="${field.key}"
      min="${field.min}" max="${field.max}" step="${field.step}" value="${num}"
      style="--fill:${Math.max(0, Math.min(100, pct))}%"
      aria-label="${escapeHtml(field.label)}" />
    <span class="range-value" data-value="${field.key}">${escapeHtml(valueLabel(field, num))}</span>`;
}

function fieldRow(field) {
  return `<div class="field">
    <div class="field-info">
      <div class="field-label">${escapeHtml(field.label)}</div>
      ${field.hint ? `<div class="field-hint">${escapeHtml(field.hint)}</div>` : ''}
    </div>
    <div class="field-control">${control(field)}</div>
  </div>`;
}

function groupCard(group) {
  return `<section class="card" id="g-${group.id}">
    <div class="card-head">
      <div class="card-heading">
        <span class="head-ico">${icon(group.icon)}</span>
        <div>
          <h2 class="card-title">${escapeHtml(group.title)}</h2>
          <p class="card-desc">${escapeHtml(group.desc)}</p>
        </div>
      </div>
      <span class="chip">${group.fields.length} ค่า</span>
    </div>
    <div class="card-body tight">${group.fields.map(fieldRow).join('')}</div>
  </section>`;
}

// Jump rail: lets you reach a topic without scrolling through every card.
function jumpRail() {
  return `<nav class="cat-rail" aria-label="หมวดของค่ากราฟิก">
    ${GROUPS.map((group) => `<button type="button" class="cat-chip" data-jump="g-${group.id}">
      ${icon(group.icon)}<span>${escapeHtml(group.title)}</span><i class="cat-count">${group.fields.length}</i>
    </button>`).join('')}
  </nav>`;
}

function changedCount() {
  const keys = new Set([...Object.keys(state.values), ...Object.keys(state.saved)]);
  let n = 0;
  for (const key of keys) {
    if (String(state.values[key]) !== String(state.saved[key])) n++;
  }
  return n;
}

export default function mount(root, ctx) {
  const presetId = currentPresetId();
  const preset = PRESETS.find((p) => p.id === presetId);
  const setPath = state.settingsPath || state.status?.paths?.settings;

  root.innerHTML = `
    <div class="grid-2">
      <div class="stack">
        ${!setPath ? `<div class="callout info">${icon('info')}
          <div><strong>ยังไม่พบ gta5_settings.xml</strong> — เมื่อกดบันทึก ระบบจะสร้างไฟล์ใหม่ที่
          <code>%APPDATA%\\CitizenFX</code> ให้อัตโนมัติ</div>
        </div>` : ''}
        ${state.status?.fivemRunning ? `<div class="callout warn">${icon('alert')}
          <div><strong>FiveM กำลังทำงาน</strong> — เกมจะเขียนทับไฟล์ตอนปิด ปิดเกมก่อนกดบันทึกเพื่อให้ค่าอยู่จริง</div>
        </div>` : ''}
        ${jumpRail()}
        ${GROUPS.map(groupCard).join('')}
      </div>

      <aside class="stack sticky">
        <section class="card">
          <div class="card-head">
            <div>
              <h2 class="card-title">สรุปการเปลี่ยนแปลง</h2>
              <p class="card-desc">ตรวจสอบก่อนเขียนลงไฟล์จริง</p>
            </div>
            <span class="chip ${isDirty() ? 'warn' : 'ok'}" id="dirty-chip">
              ${isDirty() ? 'ยังไม่บันทึก' : 'บันทึกแล้ว'}
            </span>
          </div>
          <div class="card-body">
            <div class="meta-row">
              <span class="meta-label">โปรไฟล์ที่ตรงกัน</span>
              <span class="meta-value" id="preset-name">${preset ? escapeHtml(preset.name) : 'กำหนดเอง'}</span>
            </div>
            <div class="meta-row">
              <span class="meta-label">ค่าที่เปลี่ยน</span>
              <span class="meta-value" id="change-count">${changedCount()} รายการ</span>
            </div>
            <div class="meta-row">
              <span class="meta-label">ค่าที่จัดการทั้งหมด</span>
              <span class="meta-value">${ALL_FIELDS.length} ค่า</span>
            </div>
            <div class="meta-row">
              <span class="meta-label">ความละเอียด</span>
              <span class="meta-value" id="meta-res">${resolutionOf(state.values)}</span>
            </div>

            <div class="divider"></div>

            <div class="section-label plain">ใช้โปรไฟล์สำเร็จรูป</div>
            <div class="seg seg-block">
              ${PRESETS.map((p) => `<button type="button" data-preset="${p.id}" class="${p.id === presetId ? 'active' : ''}">${escapeHtml(p.name)}</button>`).join('')}
            </div>

            <div class="divider"></div>

            <button class="btn btn-primary btn-block" data-apply ${isDirty() ? '' : 'disabled'}>
              ${icon('save')} บันทึกลง gta5_settings.xml
            </button>
            <button class="btn btn-ghost btn-block mt8" data-reset ${isDirty() ? '' : 'disabled'}>
              ${icon('rotate')} ย้อนกลับการแก้ไข
            </button>

            <div class="file-path" title="${escapeHtml(setPath || '')}">
              ${icon('folder')}<code>${escapeHtml(shortPath(setPath || 'ยังไม่พบไฟล์', 38))}</code>
            </div>
          </div>
        </section>

        <section class="card card-pad">
          <div class="tip">
            ${icon('info')}
            <div>
              <strong>สำรองอัตโนมัติ</strong> ทุกครั้งที่บันทึก ไฟล์เดิมจะถูกเก็บไว้ที่
              <code>AkiLxstboss\\backups</code> และกู้คืนได้จากหน้าตั้งค่า
            </div>
          </div>
        </section>
      </aside>
    </div>`;

  const dirtyChip = root.querySelector('#dirty-chip');
  const applyBtn = root.querySelector('[data-apply]');
  const resetBtn = root.querySelector('[data-reset]');
  const countEl = root.querySelector('#change-count');
  const presetEl = root.querySelector('#preset-name');
  const resEl = root.querySelector('#meta-res');

  function syncMeta() {
    const count = changedCount();
    const dirty = count > 0;
    if (countEl) countEl.textContent = `${count} รายการ`;
    if (dirtyChip) {
      dirtyChip.className = `chip ${dirty ? 'warn' : 'ok'}`;
      dirtyChip.textContent = dirty ? 'ยังไม่บันทึก' : 'บันทึกแล้ว';
    }
    if (applyBtn) applyBtn.disabled = !dirty;
    if (resetBtn) resetBtn.disabled = !dirty;
    if (presetEl) {
      const id = currentPresetId();
      const p = PRESETS.find((x) => x.id === id);
      presetEl.textContent = p ? p.name : 'กำหนดเอง';
    }
    if (resEl) resEl.textContent = resolutionOf(state.values);
    root.querySelectorAll('[data-preset]').forEach((b) => {
      b.classList.toggle('active', b.dataset.preset === currentPresetId());
    });
  }

  root.querySelectorAll('[data-jump]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.jump);
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      root.querySelectorAll('[data-jump]').forEach((other) => other.classList.toggle('active', other === btn));
    });
  });

  root.querySelectorAll('[data-switch]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.switch;
      const bool = btn.dataset.kind === 'bool';
      const next = isOn(state.values[key]) ? (bool ? 'false' : 0) : (bool ? 'true' : 1);
      setState({ values: { ...state.values, [key]: next } });
      btn.classList.toggle('on', isOn(next));
      btn.setAttribute('aria-checked', String(isOn(next)));
      syncMeta();
    });
  });

  root.querySelectorAll('[data-range]').forEach((input) => {
    const key = input.dataset.range;
    const field = ALL_FIELDS.find((f) => f.key === key);
    rangeFill(input);
    const label = root.querySelector(`[data-value="${key}"]`);
    input.addEventListener('input', () => {
      const value = Number(input.value);
      setState({ values: { ...state.values, [key]: value } });
      rangeFill(input);
      if (label) label.textContent = valueLabel(field, value);
      syncMeta();
    });
  });

  root.querySelectorAll('[data-select]').forEach((sel) => {
    sel.addEventListener('change', () => {
      const key = sel.dataset.select;
      setState({ values: { ...state.values, [key]: Number(sel.value) } });
      syncMeta();
    });
  });

  root.querySelectorAll('[data-number]').forEach((input) => {
    input.addEventListener('change', () => {
      const key = input.dataset.number;
      let value = Number(input.value);
      const field = ALL_FIELDS.find((f) => f.key === key);
      if (Number.isFinite(value)) {
        value = Math.max(field.min, Math.min(field.max, value));
        input.value = value;
      }
      setState({ values: { ...state.values, [key]: value } });
      syncMeta();
    });
  });

  const resSelect = root.querySelector('[data-resolution]');
  if (resSelect) {
    resSelect.addEventListener('change', () => {
      const { ScreenWidth, ScreenHeight } = parseResolution(resSelect.value);
      setState({ values: { ...state.values, ScreenWidth, ScreenHeight } });
      syncMeta();
    });
  }

  root.querySelectorAll('[data-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      applyLocalPreset(btn.dataset.preset);
      ctx.rerender();
    });
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      resetValues();
      ctx.rerender();
    });
  }

  if (applyBtn) {
    const label = `${icon('save')} บันทึกลง gta5_settings.xml`;
    applyBtn.addEventListener('click', async () => {
      applyBtn.disabled = true;
      applyBtn.innerHTML = `<span class="spinner sm"></span> กำลังบันทึก…`;
      try {
        const count = changedCount();
        let res = await saveSettings(settingsPayload());

        if (!res.ok && res.fivemRunning) {
          const ok = await confirmDialog({
            title: 'FiveM กำลังทำงานอยู่',
            text: 'เกมจะเขียนทับไฟล์นี้เมื่อปิด หากบันทึกตอนนี้ค่าอาจหายหมด แนะนำให้ปิดเกมก่อน',
            confirmText: 'บันทึกทับเลย',
            danger: true,
          });
          if (!ok) {
            applyBtn.disabled = false;
            applyBtn.innerHTML = label;
            return;
          }
          res = await saveSettings({ ...settingsPayload(), force: true });
        }

        if (res.ok) {
          setState({ saved: { ...state.values } });
          pushActivity(`บันทึกค่ากราฟิก ${count} รายการ`, 'success', 'save');
          toast('บันทึกค่าลง gta5_settings.xml แล้ว', 'success');
          if (res.backup) toast(`สำรองไฟล์เดิม: ${res.backup}`, 'info', 4200);
          ctx.rerender();
        } else {
          toast(res.message || 'บันทึกไม่สำเร็จ', 'error');
          applyBtn.disabled = false;
          applyBtn.innerHTML = label;
        }
      } catch (err) {
        toast('บันทึกไม่สำเร็จ: ' + (err.message || err), 'error');
        applyBtn.disabled = false;
        applyBtn.innerHTML = label;
      }
    });
  }

  syncMeta();
}
