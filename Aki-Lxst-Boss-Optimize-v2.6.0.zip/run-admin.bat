@echo off
title Aki Lxst Boss Optimize - Administrator
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo   Requesting Administrator permission...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

echo.
echo   ============================================================
echo     Aki Lxst Boss Optimize  -  Administrator mode
echo   ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"

echo.
echo   Server stopped. You can close this window.
pause
